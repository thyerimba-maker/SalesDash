import mysql from 'mysql2/promise';

async function deleteAllOrders() {
  const connection = await mysql.createConnection({
    host: process.env.DATABASE_URL?.split('@')[1]?.split('/')[0] || 'localhost',
    user: process.env.DATABASE_URL?.split('://')[1]?.split(':')[0] || 'root',
    password: process.env.DATABASE_URL?.split(':')[2]?.split('@')[0] || '',
    database: process.env.DATABASE_URL?.split('/').pop() || 'test',
  });

  try {
    // Delete all orders
    const [result] = await connection.execute('DELETE FROM orders');
    console.log(`✅ ${result.affectedRows} pedidos deletados com sucesso!`);
  } catch (error) {
    console.error('❌ Erro ao deletar pedidos:', error);
  } finally {
    await connection.end();
  }
}

deleteAllOrders();
