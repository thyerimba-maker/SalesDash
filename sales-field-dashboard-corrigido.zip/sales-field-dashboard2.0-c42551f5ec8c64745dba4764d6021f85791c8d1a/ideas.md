# Brainstorming de Design: Sales Field Dashboard

## Conceito Geral
Um dashboard mobile para vendedores em campo que prioriza **velocidade de acesso**, **clareza de dados** e **ações diretas**. O design deve refletir profissionalismo, confiança e eficiência operacional, com foco em usabilidade táctil e legibilidade em condições de luz solar.

---

## Resposta 1: Modern Minimalist (Probabilidade: 0.08)

### Design Movement
**Neo-Brutalism Digital** com influências de design suíço. Foco em tipografia forte, espaçamento generoso e uso estratégico de cores vibrantes contra fundos neutros.

### Core Principles
1. **Hierarquia Tipográfica Agressiva:** Títulos em sans-serif bold (Poppins), corpo em Roboto regular. Contraste visual extremo para guiar atenção.
2. **Espaçamento Generoso:** Padding e margens amplas criam "respiro" visual, reduzindo fadiga cognitiva em uso prolongado.
3. **Cores Vibrantes Estratégicas:** Verde-limão (#00D084) para ações primárias, cinza-escuro (#1A1A1A) para fundo, branco puro para cards.
4. **Sem Decoração Desnecessária:** Apenas bordas retas, sem gradientes ou efeitos visuais excessivos.

### Color Philosophy
- **Primária:** Verde-limão (#00D084) — energia, crescimento, ação imediata
- **Fundo:** Cinza muito escuro (#0F0F0F) — reduz fadiga ocular em ambientes externos
- **Cards:** Branco puro (#FFFFFF) — contraste máximo, legibilidade em qualquer luz
- **Texto Secundário:** Cinza médio (#666666) — hierarquia clara sem distração

**Intenção Emocional:** Profissional, direto, sem frivolidades. Transmite confiança e eficiência.

### Layout Paradigm
- **Sidebar Fixa (Desktop) / Off-canvas (Mobile):** Navegação sempre acessível sem ocupar espaço crítico.
- **Grid de 2 Colunas em Desktop:** Cards de métrica lado a lado. Em mobile, coluna única com full-width.
- **Seções Empilhadas Verticalmente:** Funil de vendas, lista de leads, histórico — cada um em seu próprio "bloco" com separação clara.

### Signature Elements
1. **Badges Coloridas por Status:** Verde para "Confirmado", amarelo para "Aguardando", laranja para "Atendimento". Cada status tem cor única e ícone.
2. **Botões Circulares de Ação Rápida:** WhatsApp, Chamada, Editar — botões flutuantes ou inline com ícones claros.
3. **Linhas Divisórias Sutis:** Separadores em cinza-claro (#E8E8E8) entre seções, criando ordem visual sem poluição.

### Interaction Philosophy
- **Tap Targets de 48px+:** Todos os botões e áreas clicáveis respeitam o mínimo recomendado pela Apple/Google.
- **Feedback Imediato:** Ripple effect em cliques, toast notifications para confirmações.
- **Transições Suaves:** Slide-in do sidebar, fade-in de modais, sem saltos abruptos.

### Animation
- **Entrada de Cards:** Fade-in com slight scale-up (0.95 → 1) em 300ms.
- **Hover em Botões:** Mudança de cor + slight lift (transform: translateY(-2px)).
- **Sidebar Toggle:** Slide-in da esquerda em 250ms com easing ease-out.
- **Loading States:** Skeleton screens em cinza-claro, pulsando suavemente.

### Typography System
- **Display (Títulos Principais):** Poppins Bold 28px, line-height 1.2
- **Heading (Seções):** Poppins SemiBold 18px, line-height 1.3
- **Body (Texto Principal):** Roboto Regular 16px, line-height 1.6
- **Caption (Dados Secundários):** Roboto Regular 12px, color: #666

---

## Resposta 2: Data-Driven Elegance (Probabilidade: 0.07)

### Design Movement
**Dashboard Moderno Corporativo** inspirado em plataformas de analytics premium (Figma, Notion). Uso de gradientes sutis, ícones sofisticados e tipografia refinada.

### Core Principles
1. **Dados como Protagonista:** Números grandes e claros, contexto visual através de gráficos minimalistas.
2. **Gradientes Sutis:** Não cores sólidas — transições suaves entre tons para profundidade.
3. **Ícones Customizados:** Cada ação tem ícone único, reforçando identidade visual.
4. **Modo Escuro Premium:** Fundo em cinza muito escuro (#0D1117), cards em #161B22, criando contraste elegante.

### Color Philosophy
- **Primária:** Azul-ciano (#00B4D8) — confiança, tecnologia, modernidade
- **Secundária:** Laranja-coral (#FF6B35) — urgência, atenção
- **Fundo:** Cinza escuro (#0D1117) — premium, reduz fadiga
- **Gradiente Accent:** Azul-ciano → Roxo (#7209B7) para elementos destacados

**Intenção Emocional:** Sofisticado, confiável, tech-forward. Transmite inovação e competência.

### Layout Paradigm
- **Cards com Sombra Elevada:** Cada métrica em card com shadow suave (0 8px 24px rgba(0,0,0,0.15)).
- **Grid Responsivo 3 Colunas (Desktop):** Métricas lado a lado, reorganiza para 1 coluna em mobile.
- **Gráficos Minimalistas:** Sparklines (mini-gráficos) ao lado de números para contexto visual rápido.

### Signature Elements
1. **Badges com Ícones Animados:** Status com ícone + cor + animação de pulsação para urgência.
2. **Botões com Ícone + Texto:** Ações sempre acompanhadas de ícone e label claro.
3. **Indicadores de Progresso:** Barras de progresso coloridas para funil de vendas (ex: 3/10 leads convertidos).

### Interaction Philosophy
- **Hover Reveals:** Botões de ação aparecem ao passar o mouse (desktop) ou ao tocar (mobile).
- **Modais com Backdrop Blur:** Fundo desfocado ao abrir modal, criando foco.
- **Drag-and-Drop:** Leads podem ser arrastados entre estágios do funil (em desktop).

### Animation
- **Números Contadores:** Animação de contagem ao carregar (ex: 0 → 1.240 em 1s).
- **Gráficos Animados:** Barras crescem ao carregar em 500ms.
- **Hover em Cards:** Elevação (box-shadow aumenta) + slight scale (1.02).
- **Transição de Status:** Mudança de cor com fade suave em 200ms.

### Typography System
- **Display:** Inter Bold 32px, letter-spacing -0.5px
- **Heading:** Inter SemiBold 20px
- **Body:** Inter Regular 15px, line-height 1.5
- **Mono (Números):** IBM Plex Mono 18px (para dados críticos)

---

## Resposta 3: Field-First Practical (Probabilidade: 0.06)

### Design Movement
**Utilitarista Moderno** com foco em legibilidade em condições adversas (luz solar, telas pequenas, uso com uma mão). Inspirado em apps de campo (Uber, iFood, Loggi).

### Core Principles
1. **Otimizado para Uma Mão:** Todos os controles principais na metade inferior da tela.
2. **Alto Contraste:** Cores vibrantes contra fundos escuros para legibilidade em luz solar.
3. **Ícones Universais:** Cada ação representada por ícone reconhecível globalmente.
4. **Feedback Tátil:** Vibrações (haptic feedback) em cliques importantes.

### Color Philosophy
- **Primária:** Verde-esmeralda (#00C45A) — ação, sucesso, crescimento
- **Secundária:** Vermelho-alarme (#FF4444) — urgência, follow-up necessário
- **Fundo:** Preto puro (#000000) — máximo contraste, economia de bateria em OLED
- **Neutro:** Cinza-claro (#F5F5F5) para texto sobre fundo escuro

**Intenção Emocional:** Prático, direto, confiável. Transmite ação e resultado.

### Layout Paradigm
- **Bottom Navigation:** Abas na parte inferior (Home, Leads, Vendas, Perfil) — fácil acesso com polegar.
- **Floating Action Button (FAB):** Botão flutuante verde no canto inferior direito para "Novo Lead".
- **Cards Empilhados Verticalmente:** Scroll infinito, sem paginação — sensação de fluidez.

### Signature Elements
1. **Status Pills Coloridas:** Badges ovais com cor e ícone, ocupam pouco espaço.
2. **Contador Visual:** Números grandes com unidade (ex: "12 Leads" em 24px).
3. **Ícones Inline:** Cada lead tem ícone de status + ícone de ação (WhatsApp, chamada).

### Interaction Philosophy
- **Swipe Gestures:** Deslizar para esquerda = marcar como concluído, para direita = adiar.
- **Long Press:** Pressionar por 2s abre menu de contexto (editar, deletar, arquivar).
- **Quick Actions:** Botões de ação sempre visíveis, não em menus ocultos.

### Animation
- **Swipe Feedback:** Card desliza suavemente ao swipe, deixando rastro de cor.
- **FAB Pulse:** Botão flutuante pulsa levemente para atrair atenção.
- **Toast Notifications:** Aparecem na parte inferior, deslizam para cima em 200ms.
- **Loading Shimmer:** Efeito de brilho deslizando sobre cards enquanto carregam.

### Typography System
- **Display:** Poppins Bold 26px
- **Heading:** Poppins SemiBold 16px
- **Body:** Roboto Regular 14px, line-height 1.5
- **Label (Ações):** Roboto Medium 12px

---

## Decisão Final

Após análise, escolho a **Resposta 1: Modern Minimalist** como base de design. Razões:

1. **Clareza Máxima:** Verde-limão vibrante contra cinza escuro cria contraste extremo, ideal para ambientes externos.
2. **Eficiência Operacional:** Layout sem distrações visuais permite que vendedores localizem informações rapidamente.
3. **Profissionalismo:** Tipografia forte (Poppins + Roboto) transmite confiança e competência.
4. **Escalabilidade:** Design simples e limpo adapta-se bem a diferentes tamanhos de tela.
5. **Alinhamento com sales-mobile-optimizer:** Respeita touch targets de 44px+, fontes de 16px, e layout mobile-first.

### Aplicação Prática
- **Cores:** Verde-limão (#00D084), Cinza escuro (#1A1A1A), Branco (#FFFFFF), Cinza médio (#666666)
- **Tipografia:** Poppins para títulos, Roboto para corpo
- **Espaçamento:** Padding 16px em mobile, 24px em desktop
- **Componentes:** Badges por status, botões circulares de ação, separadores sutis
- **Animações:** Fade-in suave, transições de 250-300ms, sem efeitos excessivos
