import { useEffect } from 'react';
import { trpc } from '@/lib/trpc';

/**
 * Custom hook for real-time lead synchronization
 * Automatically refetches leads at regular intervals
 */
export function useLeadSync(intervalMs: number = 30000) {
  const utils = trpc.useUtils();

  useEffect(() => {
    // Set up interval for periodic sync
    const interval = setInterval(() => {
      utils.leads.list.invalidate();
    }, intervalMs);

    return () => clearInterval(interval);
  }, [intervalMs, utils]);
}

/**
 * Hook to track lead status changes
 */
export function useLeadStatusTracking() {
  const utils = trpc.useUtils();
  const updateLeadMutation = trpc.leads.update.useMutation();

  const updateLeadStatus = async (leadId: number, newStatus: string) => {
    try {
      await updateLeadMutation.mutateAsync({
        id: leadId,
        status: newStatus as any,
      });

      // Invalidate cache to trigger refetch
      utils.leads.list.invalidate();
    } catch (error) {
      console.error('Error updating lead status:', error);
      throw error;
    }
  };

  return { updateLeadStatus, isLoading: updateLeadMutation.isPending };
}

/**
 * Hook to track contact history
 */
export function useContactHistory(leadId: number) {
  const { data: history } = trpc.contactHistory.getByLead.useQuery({ leadId });
  const createHistoryMutation = trpc.contactHistory.create.useMutation();

  const addContactRecord = async (type: 'call' | 'whatsapp' | 'email' | 'meeting' | 'note', description?: string) => {
    try {
      await createHistoryMutation.mutateAsync({
        leadId,
        type,
        description,
      });
    } catch (error) {
      console.error('Error adding contact record:', error);
      throw error;
    }
  };

  return { history, addContactRecord, isLoading: createHistoryMutation.isPending };
}
