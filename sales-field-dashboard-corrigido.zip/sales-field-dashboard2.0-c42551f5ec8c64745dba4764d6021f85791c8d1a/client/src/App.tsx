import { Toaster } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import NotFound from "@/pages/NotFound";
import { Route, Switch } from "wouter";
import ErrorBoundary from "./components/ErrorBoundary";
import { ThemeProvider } from "./contexts/ThemeContext";
import Dashboard from "./pages/Dashboard";
import History from "./pages/History";
import MonthlySales from "./pages/MonthlySales";
import Orders from "./pages/Orders";
import Inventory from "./pages/Inventory";
import CashRegister from "./pages/CashRegister";
import Leads from "./pages/Leads";
import Sales from "./pages/Sales";
import Suppliers from "./pages/Suppliers";
import Settings from "./pages/Settings";
import AppLogin from "./pages/AppLogin";
import { useState, useEffect } from "react";

function ProtectedRouter() {
  const [isAuthenticated, setIsAuthenticated] = useState(false);

  useEffect(() => {
    const stored = sessionStorage.getItem('appAuth');
    setIsAuthenticated(stored === 'true');
  }, []);

  if (!isAuthenticated) {
    return <AppLogin onLoginSuccess={() => {
      setIsAuthenticated(true);
      // Ensure sessionStorage is set
      sessionStorage.setItem('appAuth', 'true');
    }} />;
  }

  return (
    <Switch>
      <Route path={"/"} component={Dashboard} />
      <Route path={"/leads"} component={Leads} />
      <Route path={"/sales"} component={Sales} />
      <Route path={"/inventory"} component={Inventory} />
      <Route path={"/suppliers"} component={Suppliers} />
      <Route path={"/cash-register"} component={CashRegister} />
      <Route path={"/history"} component={History} />
      <Route path={"/settings"} component={Settings} />
      <Route path={"/404"} component={NotFound} />
      {/* Final fallback route */}
      <Route component={NotFound} />
    </Switch>
  );
}

// NOTE: About Theme
// - First choose a default theme according to your design style (dark or light bg), than change color palette in index.css
//   to keep consistent foreground/background color across components
// - If you want to make theme switchable, pass `switchable` ThemeProvider and use `useTheme` hook

function App() {
  return (
    <ErrorBoundary>
      <ThemeProvider
        defaultTheme="dark"
        // switchable
      >
        <TooltipProvider>
          <Toaster />
          <ProtectedRouter />
        </TooltipProvider>
      </ThemeProvider>
    </ErrorBoundary>
  );
}

export default App;
