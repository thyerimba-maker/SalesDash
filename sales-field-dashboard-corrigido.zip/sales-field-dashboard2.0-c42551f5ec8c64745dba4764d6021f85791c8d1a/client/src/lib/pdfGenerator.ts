import jsPDF from 'jspdf';
import html2canvas from 'html2canvas';
import { ReportConfig } from '@/components/ReportModal';

export interface SalesData {
  metrics: {
    salestoday: number;
    newLeads: number;
    conversionRate: number;
    activeLeads: number;
    weeklyTarget: number;
    monthlyTarget: number;
  };
  funnel: Array<{
    stage: string;
    count: number;
    percentage: number;
  }>;
  leads: Array<{
    id: string;
    name: string;
    phone: string;
    status: string;
    product: string;
    lastContact: string;
  }>;
}

export async function generateSalesReport(
  data: SalesData,
  config: ReportConfig
): Promise<void> {
  const pdf = new jsPDF({
    orientation: 'portrait',
    unit: 'mm',
    format: 'a4',
  });

  const pageWidth = pdf.internal.pageSize.getWidth();
  const pageHeight = pdf.internal.pageSize.getHeight();
  let yPosition = 20;
  const margin = 15;
  const contentWidth = pageWidth - 2 * margin;

  // Helper function to add text
  const addText = (text: string, fontSize: number, fontWeight: 'normal' | 'bold' = 'normal', color = '#1A1A1A') => {
    pdf.setFontSize(fontSize);
    pdf.setFont('helvetica', fontWeight);
    pdf.setTextColor(color);
    return text;
  };

  // Helper function to check page break
  const checkPageBreak = (spaceNeeded: number) => {
    if (yPosition + spaceNeeded > pageHeight - 10) {
      pdf.addPage();
      yPosition = 20;
    }
  };

  // Header
  pdf.setFillColor(26, 26, 26); // Dark background
  pdf.rect(0, 0, pageWidth, 35, 'F');
  
  pdf.setFontSize(24);
  pdf.setFont('helvetica', 'bold');
  pdf.setTextColor(0, 208, 132); // Primary green
  pdf.text('SalesField', margin, 20);
  
  pdf.setFontSize(10);
  pdf.setFont('helvetica', 'normal');
  pdf.setTextColor(100, 100, 100);
  pdf.text('Relatório de Vendas', margin, 28);

  yPosition = 45;

  // Report Title and Date
  const reportDate = new Date().toLocaleDateString('pt-BR', {
    year: 'numeric',
    month: 'long',
    day: 'numeric',
  });

  pdf.setFontSize(16);
  pdf.setFont('helvetica', 'bold');
  pdf.setTextColor(26, 26, 26);
  pdf.text(`Relatório ${config.format === 'summary' ? 'Resumido' : 'Detalhado'}`, margin, yPosition);
  
  pdf.setFontSize(10);
  pdf.setFont('helvetica', 'normal');
  pdf.setTextColor(100, 100, 100);
  pdf.text(`Gerado em ${reportDate}`, margin, yPosition + 8);

  yPosition += 18;

  // Metrics Section
  if (config.includeMetrics) {
    checkPageBreak(40);
    
    pdf.setFontSize(14);
    pdf.setFont('helvetica', 'bold');
    pdf.setTextColor(26, 26, 26);
    pdf.text('Métricas de Desempenho', margin, yPosition);
    yPosition += 10;

    // Metrics Grid
    const metricsData = [
      { label: 'Vendas Hoje', value: `R$ ${data.metrics.salestoday.toLocaleString('pt-BR')}` },
      { label: 'Novos Leads', value: data.metrics.newLeads.toString() },
      { label: 'Taxa de Conversão', value: `${data.metrics.conversionRate.toFixed(1)}%` },
      { label: 'Leads Ativos', value: data.metrics.activeLeads.toString() },
    ];

    pdf.setFontSize(9);
    pdf.setFont('helvetica', 'normal');
    
    metricsData.forEach((metric, index) => {
      const col = index % 2;
      const row = Math.floor(index / 2);
      const xPos = margin + col * (contentWidth / 2);
      const yPos = yPosition + row * 12;

      pdf.setTextColor(100, 100, 100);
      pdf.text(metric.label, xPos, yPos);
      
      pdf.setFontSize(11);
      pdf.setFont('helvetica', 'bold');
      pdf.setTextColor(0, 208, 132);
      pdf.text(metric.value, xPos, yPos + 6);
      
      pdf.setFontSize(9);
      pdf.setFont('helvetica', 'normal');
    });

    yPosition += 30;
  }

  // Funnel Section
  if (config.includeFunnel) {
    checkPageBreak(50);
    
    pdf.setFontSize(14);
    pdf.setFont('helvetica', 'bold');
    pdf.setTextColor(26, 26, 26);
    pdf.text('Funil de Vendas', margin, yPosition);
    yPosition += 10;

    pdf.setFontSize(9);
    pdf.setFont('helvetica', 'normal');

    data.funnel.forEach((stage) => {
      checkPageBreak(8);
      
      // Stage name and count
      pdf.setTextColor(26, 26, 26);
      pdf.text(`${stage.stage}: ${stage.count} leads (${stage.percentage.toFixed(1)}%)`, margin, yPosition);
      
      // Progress bar
      const barWidth = (contentWidth * stage.percentage) / 100;
      pdf.setFillColor(230, 230, 230); // Light gray background
      pdf.rect(margin, yPosition + 2, contentWidth, 4, 'F');
      
      pdf.setFillColor(0, 208, 132); // Primary green
      pdf.rect(margin, yPosition + 2, barWidth, 4, 'F');
      
      yPosition += 10;
    });

    yPosition += 5;
  }

  // Leads Section
  if (config.includeLeads && config.format === 'detailed') {
    checkPageBreak(40);
    
    pdf.setFontSize(14);
    pdf.setFont('helvetica', 'bold');
    pdf.setTextColor(26, 26, 26);
    pdf.text('Lista de Leads', margin, yPosition);
    yPosition += 10;

    // Table header
    pdf.setFillColor(26, 26, 26);
    pdf.setTextColor(255, 255, 255);
    pdf.setFontSize(9);
    pdf.setFont('helvetica', 'bold');
    
    const colWidths = [40, 30, 35, 30];
    const headers = ['Nome', 'Telefone', 'Produto', 'Status'];
    let xPos = margin;
    
    headers.forEach((header, i) => {
      pdf.text(header, xPos, yPosition);
      xPos += colWidths[i];
    });

    yPosition += 8;

    // Table rows
    pdf.setTextColor(26, 26, 26);
    pdf.setFont('helvetica', 'normal');
    pdf.setFontSize(8);

    data.leads.slice(0, 15).forEach((lead) => {
      checkPageBreak(6);
      
      xPos = margin;
      pdf.text(lead.name.substring(0, 15), xPos, yPosition);
      xPos += colWidths[0];
      
      pdf.text(lead.phone.substring(0, 12), xPos, yPosition);
      xPos += colWidths[1];
      
      pdf.text(lead.product.substring(0, 15), xPos, yPosition);
      xPos += colWidths[2];
      
      pdf.text(lead.status, xPos, yPosition);
      
      yPosition += 6;
    });

    if (data.leads.length > 15) {
      yPosition += 3;
      pdf.setFontSize(8);
      pdf.setTextColor(100, 100, 100);
      pdf.text(`... e mais ${data.leads.length - 15} leads`, margin, yPosition);
    }
  }

  // Footer
  const totalPages = pdf.getNumberOfPages();
  for (let i = 1; i <= totalPages; i++) {
    pdf.setPage(i);
    pdf.setFontSize(8);
    pdf.setTextColor(150, 150, 150);
    pdf.text(
      `Página ${i} de ${totalPages}`,
      pageWidth / 2,
      pageHeight - 10,
      { align: 'center' }
    );
  }

  // Generate filename
  const dateStr = new Date().toISOString().split('T')[0];
  const filename = `relatorio_vendas_${dateStr}.pdf`;

  // Save PDF
  pdf.save(filename);
}

export async function generatePDFFromHTML(
  elementId: string,
  filename: string
): Promise<void> {
  const element = document.getElementById(elementId);
  if (!element) {
    throw new Error(`Element with id "${elementId}" not found`);
  }

  try {
    const canvas = await html2canvas(element, {
      scale: 2,
      useCORS: true,
      logging: false,
    });

    const imgData = canvas.toDataURL('image/png');
    const pdf = new jsPDF({
      orientation: canvas.width > canvas.height ? 'landscape' : 'portrait',
      unit: 'mm',
      format: 'a4',
    });

    const imgWidth = pdf.internal.pageSize.getWidth();
    const imgHeight = (canvas.height * imgWidth) / canvas.width;
    let heightLeft = imgHeight;
    let position = 0;

    pdf.addImage(imgData, 'PNG', 0, position, imgWidth, imgHeight);
    heightLeft -= pdf.internal.pageSize.getHeight();

    while (heightLeft >= 0) {
      position = heightLeft - imgHeight;
      pdf.addPage();
      pdf.addImage(imgData, 'PNG', 0, position, imgWidth, imgHeight);
      heightLeft -= pdf.internal.pageSize.getHeight();
    }

    pdf.save(filename);
  } catch (error) {
    console.error('Error generating PDF:', error);
    throw error;
  }
}
