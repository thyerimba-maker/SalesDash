import { AlertCircle, Clock, CheckCircle2, Truck, CheckCircle } from 'lucide-react';

type LeadStatus = 'leads' | 'atendimento' | 'aguardando' | 'confirmado' | 'em_rota' | 'concluido' | 'venda_feita' | 'venda_perdida';

interface StatusBadgeProps {
  status: LeadStatus;
  size?: 'sm' | 'md' | 'lg';
}

const statusConfig: Record<LeadStatus, { label: string; color: string; icon: React.ReactNode }> = {
  leads: {
    label: 'Leads',
    color: 'bg-slate-500',
    icon: <AlertCircle className="w-3 h-3" />,
  },
  atendimento: {
    label: 'Atendimento',
    color: 'bg-blue-500',
    icon: <Clock className="w-3 h-3" />,
  },
  aguardando: {
    label: 'Aguardando',
    color: 'bg-yellow-500',
    icon: <Clock className="w-3 h-3" />,
  },
  confirmado: {
    label: 'Confirmado',
    color: 'bg-primary',
    icon: <CheckCircle2 className="w-3 h-3" />,
  },
  em_rota: {
    label: 'Em Rota',
    color: 'bg-purple-500',
    icon: <Truck className="w-3 h-3" />,
  },
  concluido: {
    label: 'Concluído',
    color: 'bg-green-600',
    icon: <CheckCircle className="w-3 h-3" />,
  },
  venda_feita: {
    label: 'Venda Feita',
    color: 'bg-emerald-500',
    icon: <CheckCircle className="w-3 h-3" />,
  },
  venda_perdida: {
    label: 'Venda Perdida',
    color: 'bg-red-500',
    icon: <AlertCircle className="w-3 h-3" />,
  },
};

export default function StatusBadge({ status, size = 'md' }: StatusBadgeProps) {
  const config = statusConfig[status];
  const sizeClasses = {
    sm: 'px-2 py-1 text-xs',
    md: 'px-3 py-1.5 text-sm',
    lg: 'px-4 py-2 text-base',
  };

  return (
    <div
      className={`inline-flex items-center gap-1.5 rounded-full ${config.color} text-white font-semibold ${sizeClasses[size]}`}
    >
      {config.icon}
      {config.label}
    </div>
  );
}
