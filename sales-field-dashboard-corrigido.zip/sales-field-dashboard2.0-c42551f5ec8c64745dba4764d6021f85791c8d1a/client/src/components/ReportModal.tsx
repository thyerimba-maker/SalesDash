import { useState } from 'react';
import { X, Download } from 'lucide-react';
import { Button } from '@/components/ui/button';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogClose,
} from '@/components/ui/dialog';

interface ReportModalProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  onExport: (config: ReportConfig) => void;
  isLoading?: boolean;
}

export interface ReportConfig {
  period: 'today' | 'week' | 'month' | 'custom';
  startDate?: string;
  endDate?: string;
  includeMetrics: boolean;
  includeFunnel: boolean;
  includeLeads: boolean;
  includeCharts: boolean;
  format: 'detailed' | 'summary';
}

export default function ReportModal({ open, onOpenChange, onExport, isLoading }: ReportModalProps) {
  const [config, setConfig] = useState<ReportConfig>({
    period: 'month',
    includeMetrics: true,
    includeFunnel: true,
    includeLeads: true,
    includeCharts: true,
    format: 'detailed',
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onExport(config);
  };

  const handleChange = (field: keyof ReportConfig, value: any) => {
    setConfig((prev) => ({ ...prev, [field]: value }));
  };

  const today = new Date().toISOString().split('T')[0];
  const lastMonth = new Date(Date.now() - 30 * 24 * 60 * 60 * 1000).toISOString().split('T')[0];

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle>Exportar Relatório</DialogTitle>
          <DialogClose asChild>
            <Button variant="ghost" size="icon" className="absolute right-4 top-4">
              <X className="w-4 h-4" />
            </Button>
          </DialogClose>
        </DialogHeader>

        <form onSubmit={handleSubmit} className="space-y-4">
          {/* Period Selection */}
          <div>
            <label className="block text-sm font-medium text-foreground mb-2">
              Período
            </label>
            <select
              value={config.period}
              onChange={(e) => handleChange('period', e.target.value)}
              className="w-full px-4 py-2 rounded-lg border border-border bg-input text-foreground focus:outline-none focus:ring-2 focus:ring-primary min-h-[44px]"
            >
              <option value="today">Hoje</option>
              <option value="week">Esta Semana</option>
              <option value="month">Este Mês</option>
              <option value="custom">Personalizado</option>
            </select>
          </div>

          {/* Custom Date Range */}
          {config.period === 'custom' && (
            <div className="space-y-3 p-3 bg-secondary/30 rounded-lg">
              <div>
                <label className="block text-sm font-medium text-foreground mb-2">
                  Data Inicial
                </label>
                <input
                  type="date"
                  value={config.startDate || lastMonth}
                  onChange={(e) => handleChange('startDate', e.target.value)}
                  className="w-full px-4 py-2 rounded-lg border border-border bg-input text-foreground focus:outline-none focus:ring-2 focus:ring-primary min-h-[44px]"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-foreground mb-2">
                  Data Final
                </label>
                <input
                  type="date"
                  value={config.endDate || today}
                  onChange={(e) => handleChange('endDate', e.target.value)}
                  className="w-full px-4 py-2 rounded-lg border border-border bg-input text-foreground focus:outline-none focus:ring-2 focus:ring-primary min-h-[44px]"
                />
              </div>
            </div>
          )}

          {/* Format Selection */}
          <div>
            <label className="block text-sm font-medium text-foreground mb-2">
              Formato
            </label>
            <select
              value={config.format}
              onChange={(e) => handleChange('format', e.target.value)}
              className="w-full px-4 py-2 rounded-lg border border-border bg-input text-foreground focus:outline-none focus:ring-2 focus:ring-primary min-h-[44px]"
            >
              <option value="summary">Resumido (1 página)</option>
              <option value="detailed">Detalhado (múltiplas páginas)</option>
            </select>
          </div>

          {/* Sections to Include */}
          <div className="space-y-3">
            <p className="text-sm font-medium text-foreground">Incluir Seções</p>
            
            <label className="flex items-center gap-3 p-2 rounded-lg hover:bg-secondary/30 cursor-pointer">
              <input
                type="checkbox"
                checked={config.includeMetrics}
                onChange={(e) => handleChange('includeMetrics', e.target.checked)}
                className="w-5 h-5 rounded border-border cursor-pointer"
              />
              <span className="text-sm text-foreground">Métricas de Desempenho</span>
            </label>

            <label className="flex items-center gap-3 p-2 rounded-lg hover:bg-secondary/30 cursor-pointer">
              <input
                type="checkbox"
                checked={config.includeFunnel}
                onChange={(e) => handleChange('includeFunnel', e.target.checked)}
                className="w-5 h-5 rounded border-border cursor-pointer"
              />
              <span className="text-sm text-foreground">Funil de Vendas</span>
            </label>

            <label className="flex items-center gap-3 p-2 rounded-lg hover:bg-secondary/30 cursor-pointer">
              <input
                type="checkbox"
                checked={config.includeLeads}
                onChange={(e) => handleChange('includeLeads', e.target.checked)}
                className="w-5 h-5 rounded border-border cursor-pointer"
              />
              <span className="text-sm text-foreground">Lista de Leads</span>
            </label>

            <label className="flex items-center gap-3 p-2 rounded-lg hover:bg-secondary/30 cursor-pointer">
              <input
                type="checkbox"
                checked={config.includeCharts}
                onChange={(e) => handleChange('includeCharts', e.target.checked)}
                className="w-5 h-5 rounded border-border cursor-pointer"
              />
              <span className="text-sm text-foreground">Gráficos e Análises</span>
            </label>
          </div>

          {/* Action Buttons */}
          <div className="flex gap-3 pt-4">
            <Button
              type="button"
              variant="outline"
              className="flex-1 h-10"
              onClick={() => onOpenChange(false)}
              disabled={isLoading}
            >
              Cancelar
            </Button>
            <Button
              type="submit"
              className="flex-1 h-10 bg-primary hover:bg-primary/90 text-white font-semibold flex items-center justify-center gap-2"
              disabled={isLoading}
            >
              <Download className="w-4 h-4" />
              {isLoading ? 'Gerando...' : 'Exportar PDF'}
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
}
