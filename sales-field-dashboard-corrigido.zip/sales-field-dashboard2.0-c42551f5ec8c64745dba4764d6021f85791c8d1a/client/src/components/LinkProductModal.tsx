import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
import { toast } from 'sonner';
import { trpc } from '@/lib/trpc';

interface LinkProductModalProps {
  isOpen: boolean;
  leadId: number;
  onClose: () => void;
  onSuccess: () => void;
}

interface InventoryItem {
  id: number;
  productName: string;
  description?: string;
  sizeP: number;
  sizeM: number;
  sizeG: number;
  sizeGG: number;
  totalQuantity: number;
  unitPrice?: number;
  imageUrl?: string;
}

export default function LinkProductModal({ isOpen, leadId, onClose, onSuccess }: LinkProductModalProps) {
  const [selectedProductId, setSelectedProductId] = useState<number | null>(null);
  const [quantities, setQuantities] = useState({
    sizeP: 0,
    sizeM: 0,
    sizeG: 0,
    sizeGG: 0,
  });
  const [notes, setNotes] = useState('');

  const { data: inventory = [] } = trpc.inventory.list.useQuery();
  const utils = trpc.useUtils();
  const linkProductMutation = trpc.leads.linkProduct.useMutation({
    onSuccess: () => {
      toast.success('Produto vinculado ao lead!');
      setSelectedProductId(null);
      setQuantities({ sizeP: 0, sizeM: 0, sizeG: 0, sizeGG: 0 });
      setNotes('');
      // Invalidate the linked products query to force real-time update
      utils.leads.getLinkedProducts.invalidate({ leadId });
      onSuccess();
      onClose();
    },
    onError: (error) => {
      toast.error(`Erro: ${error.message}`);
    },
  });

  const selectedProduct = inventory.find((p: InventoryItem) => p.id === selectedProductId);

  const handleLinkProduct = async () => {
    if (!selectedProduct) {
      toast.error('Selecione um produto');
      return;
    }

    // Ensure all quantities are valid numbers (not NaN)
    const sizeP = isNaN(quantities.sizeP) ? 0 : quantities.sizeP;
    const sizeM = isNaN(quantities.sizeM) ? 0 : quantities.sizeM;
    const sizeG = isNaN(quantities.sizeG) ? 0 : quantities.sizeG;
    const sizeGG = isNaN(quantities.sizeGG) ? 0 : quantities.sizeGG;
    const totalQuantity = sizeP + sizeM + sizeG + sizeGG;

    if (totalQuantity === 0) {
      toast.error('Selecione pelo menos uma quantidade');
      return;
    }

    await linkProductMutation.mutateAsync({
      leadId,
      productName: selectedProduct.productName,
      description: selectedProduct.description || undefined,
      sizeP,
      sizeM,
      sizeG,
      sizeGG,
      totalQuantity,
      unitPrice: selectedProduct.unitPrice || undefined,
      imageUrl: selectedProduct.imageUrl || undefined,
      notes: notes || undefined,
    });
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-2xl">
        <DialogHeader>
          <DialogTitle>Vincular Produto ao Lead</DialogTitle>
        </DialogHeader>

        <div className="space-y-4">
          {/* Product Selection */}
          <div>
            <label className="text-sm font-medium text-foreground mb-2 block">Selecione um Produto *</label>
            <div className="space-y-2 max-h-48 overflow-y-auto border border-border rounded-lg p-2">
              {inventory.length === 0 ? (
                <p className="text-sm text-muted-foreground p-2">Nenhum produto no estoque</p>
              ) : (
                inventory.map((product: InventoryItem) => (
                  <button
                    key={product.id}
                    onClick={() => setSelectedProductId(product.id)}
                    className={`w-full text-left p-3 rounded border-2 transition-colors ${
                      selectedProductId === product.id
                        ? 'border-primary bg-primary/10'
                        : 'border-border hover:border-primary/50'
                    }`}
                  >
                    <div className="flex justify-between items-start">
                      <div>
                        <p className="font-medium text-foreground">{product.productName}</p>
                        {product.description && (
                          <p className="text-xs text-muted-foreground">{product.description}</p>
                        )}
                        <p className="text-xs text-muted-foreground mt-1">
                          Total: {product.totalQuantity} | P: {product.sizeP} | M: {product.sizeM} | G: {product.sizeG} | GG: {product.sizeGG}
                        </p>
                      </div>
                      {product.unitPrice && (
                        <p className="text-sm font-semibold text-primary">R$ {(product.unitPrice / 100).toFixed(2)}</p>
                      )}
                    </div>
                  </button>
                ))
              )}
            </div>
          </div>

          {/* Quantity Selection */}
          {selectedProduct && (
            <>
              <div className="grid grid-cols-4 gap-2">
                {(['sizeP', 'sizeM', 'sizeG', 'sizeGG'] as const).map((size) => {
                  const sizeLabel = size.replace('size', '');
                  const available = selectedProduct[size as keyof typeof selectedProduct] as number || 0;
                  return (
                    <div key={size}>
                      <label className="text-xs font-medium text-foreground mb-1 block">Tamanho {sizeLabel}</label>
                      <div className="flex items-center gap-1">
                        <button
                          onClick={() => setQuantities({ ...quantities, [size]: Math.max(0, quantities[size] - 1) })}
                          disabled={quantities[size] === 0}
                          className="p-1 hover:bg-secondary rounded disabled:opacity-50"
                        >
                          −
                        </button>
                        <Input
                          type="number"
                          value={quantities[size] || 0}
                          onChange={(e) => {
                            const parsed = parseInt(e.target.value);
                            const val = isNaN(parsed) ? 0 : Math.min(available, Math.max(0, parsed));
                            setQuantities({ ...quantities, [size]: val });
                          }}
                          max={available}
                          min="0"
                          className="w-12 text-center h-8"
                        />
                        <button
                          onClick={() => setQuantities({ ...quantities, [size]: Math.min(available, quantities[size] + 1) })}
                          disabled={quantities[size] >= available}
                          className="p-1 hover:bg-secondary rounded disabled:opacity-50"
                        >
                          +
                        </button>
                      </div>
                      <p className="text-xs text-muted-foreground mt-1">Disponível: {available}</p>
                    </div>
                  );
                })}
              </div>

              <div>
                <label className="text-sm font-medium text-foreground mb-2 block">Observações</label>
                <Input
                  value={notes}
                  onChange={(e) => setNotes(e.target.value)}
                  placeholder="Notas adicionais sobre este produto"
                />
              </div>
            </>
          )}
        </div>

        <DialogFooter>
          <Button variant="outline" onClick={onClose}>
            Cancelar
          </Button>
          <Button
            onClick={handleLinkProduct}
            disabled={linkProductMutation.isPending || !selectedProduct}
            className="bg-primary hover:bg-primary/90 text-white"
          >
            {linkProductMutation.isPending ? 'Vinculando...' : 'Vincular Produto'}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
