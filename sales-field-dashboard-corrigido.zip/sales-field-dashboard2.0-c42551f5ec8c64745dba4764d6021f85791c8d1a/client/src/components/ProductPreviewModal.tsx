import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Trash2 } from 'lucide-react';

interface ProductPreviewModalProps {
  isOpen: boolean;
  onClose: () => void;
  product: {
    id: number;
    productName: string;
    description?: string;
    imageUrl?: string;
    unitPrice?: number;
    sizeP: number;
    sizeM: number;
    sizeG: number;
    sizeGG: number;
    totalQuantity: number;
    notes?: string;
    status?: string;
  } | null;
  onDelete?: (productId: number) => void;
  isDeleting?: boolean;
}

export default function ProductPreviewModal({
  isOpen,
  onClose,
  product,
  onDelete,
  isDeleting = false,
}: ProductPreviewModalProps) {
  if (!product) return null;

  const handleDelete = () => {
    if (onDelete && window.confirm('Tem certeza que deseja remover este produto?')) {
      onDelete(product.id);
      onClose();
    }
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-2xl">
        <DialogHeader>
          <DialogTitle>{product.productName}</DialogTitle>
        </DialogHeader>

        <div className="space-y-4">
          {/* Product Image */}
          {product.imageUrl && (
            <div className="flex justify-center">
              <img
                src={product.imageUrl}
                alt={product.productName}
                className="max-h-64 object-contain rounded-lg"
              />
            </div>
          )}

          {/* Product Description */}
          {product.description && (
            <div>
              <p className="text-sm text-muted-foreground mb-1">Descrição</p>
              <p className="text-sm text-foreground">{product.description}</p>
            </div>
          )}

          {/* Price */}
          {product.unitPrice && (
            <div>
              <p className="text-sm text-muted-foreground mb-1">Preço Unitário</p>
              <p className="text-lg font-semibold text-primary">
                R$ {(product.unitPrice / 100).toFixed(2)}
              </p>
            </div>
          )}

          {/* Sizes Grid */}
          <div>
            <p className="text-sm text-muted-foreground mb-3">Tamanhos e Quantidades</p>
            <div className="grid grid-cols-4 gap-3">
              {[
                { label: 'P', value: product.sizeP },
                { label: 'M', value: product.sizeM },
                { label: 'G', value: product.sizeG },
                { label: 'GG', value: product.sizeGG },
              ].map((size) => (
                <div
                  key={size.label}
                  className="bg-secondary rounded-lg p-3 text-center"
                >
                  <p className="text-xs font-medium text-muted-foreground mb-1">
                    Tamanho {size.label}
                  </p>
                  <p className="text-lg font-semibold text-foreground">
                    {size.value}
                  </p>
                </div>
              ))}
            </div>
          </div>

          {/* Total Quantity */}
          <div className="bg-primary/10 border border-primary/20 rounded-lg p-3">
            <p className="text-sm text-muted-foreground mb-1">Quantidade Total</p>
            <p className="text-2xl font-bold text-primary">{product.totalQuantity}</p>
          </div>

          {/* Status */}
          {product.status && (
            <div>
              <p className="text-sm text-muted-foreground mb-1">Status</p>
              <p className="text-sm font-medium text-foreground capitalize">
                {product.status === 'pendente' && '⏳ Pendente'}
                {product.status === 'confirmado' && '✓ Confirmado'}
                {product.status === 'em_producao' && '🔄 Em Produção'}
                {product.status === 'pronto' && '📦 Pronto'}
                {product.status === 'entregue' && '✓ Entregue'}
              </p>
            </div>
          )}

          {/* Notes */}
          {product.notes && (
            <div>
              <p className="text-sm text-muted-foreground mb-1">Observações</p>
              <p className="text-sm text-foreground bg-secondary/50 rounded p-2">
                {product.notes}
              </p>
            </div>
          )}
        </div>

        <DialogFooter className="flex gap-2 justify-between">
          {onDelete && (
            <Button
              variant="destructive"
              onClick={handleDelete}
              disabled={isDeleting}
              className="gap-2"
            >
              <Trash2 size={16} />
              Remover Produto
            </Button>
          )}
          <Button variant="outline" onClick={onClose}>
            Fechar
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
