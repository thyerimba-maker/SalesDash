import { MoreVertical, Edit, Trash2, Package, CheckCircle } from 'lucide-react';
import { useState } from 'react';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import { Button } from '@/components/ui/button';

interface LeadActionsMenuProps {
  onEdit?: () => void;
  onDelete?: () => void;
  onLinkProduct?: () => void;
  onCloseLead?: () => void;
}

export default function LeadActionsMenu({
  onEdit,
  onDelete,
  onLinkProduct,
  onCloseLead,
}: LeadActionsMenuProps) {
  const [open, setOpen] = useState(false);

  return (
    <DropdownMenu open={open} onOpenChange={setOpen}>
      <DropdownMenuTrigger asChild>
        <Button variant="ghost" size="icon" className="h-8 w-8">
          <MoreVertical className="w-4 h-4" />
        </Button>
      </DropdownMenuTrigger>
      <DropdownMenuContent align="end" className="w-48">
        <DropdownMenuItem onClick={() => {
          onLinkProduct?.();
          setOpen(false);
        }}>
          <Package className="w-4 h-4 mr-2" />
          Vincular Produto
        </DropdownMenuItem>
        <DropdownMenuItem onClick={() => {
          onCloseLead?.();
          setOpen(false);
        }} className="text-green-600 focus:text-green-600">
          <CheckCircle className="w-4 h-4 mr-2" />
          Finalizar Venda
        </DropdownMenuItem>
        <DropdownMenuItem onClick={() => {
          onEdit?.();
          setOpen(false);
        }}>
          <Edit className="w-4 h-4 mr-2" />
          Editar Informações
        </DropdownMenuItem>
        <DropdownMenuItem
          onClick={() => {
            onDelete?.();
            setOpen(false);
          }}
          className="text-red-600 focus:text-red-600"
        >
          <Trash2 className="w-4 h-4 mr-2" />
          Deletar Lead
        </DropdownMenuItem>
      </DropdownMenuContent>
    </DropdownMenu>
  );
}
