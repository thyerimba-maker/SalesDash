import { useState } from 'react';
import { X } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { toast } from 'sonner';
import ProductImageUpload from '@/components/ProductImageUpload';

interface EditInventoryModalProps {
  product: {
    id: number;
    productName: string;
    description?: string;
    sizeP: number;
    sizeM: number;
    sizeG: number;
    sizeGG: number;
    unitPrice?: number;
    imageUrl?: string;
  };
  isOpen: boolean;
  onClose: () => void;
  onSave: (data: any) => Promise<void>;
  onDelete?: (id: number) => Promise<void>;
  isSaving?: boolean;
}

export default function EditInventoryModal({
  product,
  isOpen,
  onClose,
  onSave,
  onDelete,
  isSaving = false,
}: EditInventoryModalProps) {
  const [formData, setFormData] = useState({
    productName: product.productName,
    description: product.description || '',
    sizeP: product.sizeP,
    sizeM: product.sizeM,
    sizeG: product.sizeG,
    sizeGG: product.sizeGG,
    unitPrice: product.unitPrice || 0,
    imageUrl: product.imageUrl || '',
  });

  const handleSave = async () => {
    if (!formData.productName.trim()) {
      toast.error('Nome do produto é obrigatório');
      return;
    }

    try {
      await onSave({
        id: product.id,
        ...formData,
        unitPrice: formData.unitPrice || undefined,
        imageUrl: formData.imageUrl || undefined,
      });
      toast.success('Produto atualizado com sucesso!');
      onClose();
    } catch (error) {
      toast.error('Erro ao atualizar produto');
    }
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
      <div className="bg-card border border-border rounded-lg max-w-2xl w-full max-h-[90vh] overflow-y-auto">
        {/* Header */}
        <div className="flex items-center justify-between p-6 border-b border-border sticky top-0 bg-card">
          <h2 className="text-xl font-semibold text-foreground">Editar Produto</h2>
          <button
            onClick={onClose}
            className="p-1 hover:bg-secondary rounded transition-colors"
          >
            <X size={20} className="text-foreground" />
          </button>
        </div>

        {/* Content */}
        <div className="p-6 space-y-6">
          {/* Product Name and Price */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="text-sm font-medium text-foreground mb-2 block">Nome do Produto *</label>
              <Input
                value={formData.productName}
                onChange={(e) => setFormData({ ...formData, productName: e.target.value })}
                placeholder="Ex: Camiseta Básica"
              />
            </div>
            <div>
              <label className="text-sm font-medium text-foreground mb-2 block">Preço Unitário (R$)</label>
              <Input
                type="number"
                value={formData.unitPrice}
                onChange={(e) => setFormData({ ...formData, unitPrice: parseFloat(e.target.value) || 0 })}
                placeholder="0.00"
                step="0.01"
              />
            </div>
          </div>

          {/* Description */}
          <div>
            <label className="text-sm font-medium text-foreground mb-2 block">Descrição</label>
            <Input
              value={formData.description}
              onChange={(e) => setFormData({ ...formData, description: e.target.value })}
              placeholder="Descrição do produto"
            />
          </div>

          {/* Image Upload */}
          <div>
            <label className="text-sm font-medium text-foreground mb-2 block">Foto do Produto</label>
            <ProductImageUpload
              productId={product.id}
              currentImageUrl={formData.imageUrl}
              onImageUpload={(url) => setFormData({ ...formData, imageUrl: url })}
              isLoading={isSaving}
            />
          </div>

          {/* Sizes */}
          <div>
            <label className="text-sm font-medium text-foreground mb-3 block">Quantidades por Tamanho</label>
            <div className="grid grid-cols-4 gap-4">
              {(['P', 'M', 'G', 'GG'] as const).map((size) => (
                <div key={size}>
                  <label className="text-sm text-muted-foreground mb-2 block">Tamanho {size}</label>
                  <Input
                    type="number"
                    value={formData[`size${size}`]}
                    onChange={(e) => setFormData({ ...formData, [`size${size}`]: parseInt(e.target.value) || 0 })}
                    min="0"
                  />
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="flex gap-2 justify-between p-6 border-t border-border sticky bottom-0 bg-card">
          <div className="flex gap-2">
            <Button
              variant="outline"
              onClick={onClose}
              disabled={isSaving}
            >
              Cancelar
            </Button>
            {onDelete && (
              <Button
                onClick={async () => {
                  if (window.confirm('Tem certeza que deseja remover este produto?')) {
                    await onDelete(product.id);
                    onClose();
                  }
                }}
                disabled={isSaving}
                className="bg-red-600 hover:bg-red-700 text-white"
              >
                Remover
              </Button>
            )}
          </div>
          <Button
            onClick={handleSave}
            disabled={isSaving}
            className="bg-primary hover:bg-primary/90 text-white"
          >
            {isSaving ? 'Salvando...' : 'Salvar'}
          </Button>
        </div>
      </div>
    </div>
  );
}
