import { Search, Filter } from 'lucide-react';
import { Button } from '@/components/ui/button';

interface FilterBarProps {
  searchValue: string;
  onSearchChange: (value: string) => void;
  selectedStatus: string;
  onStatusChange: (status: string) => void;
  onFilterOpen?: () => void;
}

export default function FilterBar({
  searchValue,
  onSearchChange,
  selectedStatus,
  onStatusChange,
  onFilterOpen,
}: FilterBarProps) {
  return (
    <div className="flex flex-col sm:flex-row gap-3 mb-6">
      <div className="flex-1 relative">
        <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-muted-foreground" />
        <input
          type="text"
          placeholder="Buscar por nome ou telefone..."
          value={searchValue}
          onChange={(e) => onSearchChange(e.target.value)}
          className="w-full pl-10 pr-4 py-2 rounded-lg border border-border bg-input text-foreground placeholder-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary min-h-[44px]"
        />
      </div>

      <select
        value={selectedStatus}
        onChange={(e) => onStatusChange(e.target.value)}
        className="px-4 py-2 rounded-lg border border-border bg-input text-foreground focus:outline-none focus:ring-2 focus:ring-primary min-h-[44px]"
      >
        <option value="">Todos os Status</option>
        <option value="leads">Leads</option>
        <option value="atendimento">Atendimento</option>
        <option value="aguardando">Aguardando</option>
        <option value="confirmado">Confirmado</option>
        <option value="em_rota">Em Rota</option>
        <option value="concluido">Concluído</option>
      </select>

      <Button
        onClick={onFilterOpen}
        variant="outline"
        className="h-11 border-border hover:bg-secondary rounded-lg flex items-center justify-center gap-2 min-w-[44px]"
      >
        <Filter className="w-5 h-5" />
        <span className="hidden sm:inline">Filtros</span>
      </Button>
    </div>
  );
}
