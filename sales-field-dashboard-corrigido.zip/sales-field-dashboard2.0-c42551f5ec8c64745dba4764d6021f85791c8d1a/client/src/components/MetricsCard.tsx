import { LucideIcon } from 'lucide-react';

interface MetricsCardProps {
  icon: LucideIcon;
  label: string;
  value: string | number;
  subtext?: string;
  trend?: 'up' | 'down' | 'neutral';
  trendValue?: string;
}

export default function MetricsCard({
  icon: Icon,
  label,
  value,
  subtext,
  trend,
  trendValue,
}: MetricsCardProps) {
  const trendColor = {
    up: 'text-primary',
    down: 'text-destructive',
    neutral: 'text-muted-foreground',
  };

  return (
    <div className="bg-card border border-border rounded-lg p-6 hover:shadow-lg transition-shadow">
      <div className="flex items-start justify-between mb-4">
        <div className="p-3 bg-primary/10 rounded-lg">
          <Icon className="w-6 h-6 text-primary" />
        </div>
        {trend && trendValue && (
          <span className={`text-sm font-semibold ${trendColor[trend]}`}>
            {trend === 'up' ? '↑' : trend === 'down' ? '↓' : '→'} {trendValue}
          </span>
        )}
      </div>
      
      <p className="text-sm text-muted-foreground mb-1">{label}</p>
      <h3 className="text-3xl font-bold text-foreground mb-2">{value}</h3>
      
      {subtext && (
        <p className="text-xs text-muted-foreground">{subtext}</p>
      )}
    </div>
  );
}
