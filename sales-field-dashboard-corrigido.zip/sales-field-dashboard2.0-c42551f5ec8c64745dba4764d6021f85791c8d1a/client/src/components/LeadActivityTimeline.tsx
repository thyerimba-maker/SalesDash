import { useEffect, useState } from 'react';
import { trpc } from '@/lib/trpc';
import { Package, Plus, Trash2, MessageSquare, CheckCircle } from 'lucide-react';

interface LeadActivityTimelineProps {
  leadId: number;
}

interface TimelineEvent {
  id: number;
  action: string;
  description: string;
  timestamp: Date;
  oldValue?: string | null;
  newValue?: string | null;
}

const actionIcons: Record<string, React.ReactNode> = {
  created: <CheckCircle className="w-4 h-4 text-green-600" />,
  status_changed: <CheckCircle className="w-4 h-4 text-blue-600" />,
  product_added: <Plus className="w-4 h-4 text-purple-600" />,
  product_removed: <Trash2 className="w-4 h-4 text-red-600" />,
  note_added: <MessageSquare className="w-4 h-4 text-yellow-600" />,
  contact_made: <Package className="w-4 h-4 text-orange-600" />,
};

export default function LeadActivityTimeline({ leadId }: LeadActivityTimelineProps) {
  const { data: history = [] } = trpc.leads.getHistory.useQuery({ leadId });

  if (history.length === 0) {
    return (
      <div className="p-6 text-center text-muted-foreground">
        <p>Nenhuma atividade registrada ainda.</p>
      </div>
    );
  }

  return (
    <div className="space-y-4">
      <h3 className="font-semibold text-foreground mb-4">Histórico de Movimentações</h3>
      <div className="space-y-4">
        {history.map((event: TimelineEvent, index: number) => (
          <div key={event.id} className="flex gap-4">
            {/* Timeline line */}
            <div className="flex flex-col items-center">
              <div className="w-8 h-8 rounded-full bg-secondary border-2 border-primary flex items-center justify-center">
                {actionIcons[event.action] || <CheckCircle className="w-4 h-4" />}
              </div>
              {index < history.length - 1 && (
                <div className="w-0.5 h-12 bg-border mt-2" />
              )}
            </div>

            {/* Content */}
            <div className="flex-1 pt-1">
              <p className="font-medium text-foreground">{event.description}</p>
              <p className="text-xs text-muted-foreground mt-1">
                {new Date(event.timestamp).toLocaleString('pt-BR')}
              </p>
              {event.oldValue && event.newValue && (
                <p className="text-xs text-muted-foreground mt-1">
                  De: <span className="text-foreground font-mono">{event.oldValue}</span> → Para: <span className="text-foreground font-mono">{event.newValue}</span>
                </p>
              )}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
