import { useState } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { toast } from 'sonner';
import { trpc } from '@/lib/trpc';

interface CloseLeadModalProps {
  isOpen: boolean;
  onClose: () => void;
  leadId: number;
  leadName: string;
  onSuccess?: () => void;
}

export default function CloseLeadModal({
  isOpen,
  onClose,
  leadId,
  leadName,
  onSuccess,
}: CloseLeadModalProps) {
  const [status, setStatus] = useState<'venda_feita' | 'venda_perdida'>('venda_feita');
  const [saleAmount, setSaleAmount] = useState('');
  const [reason, setReason] = useState('');
  const [followUpDate, setFollowUpDate] = useState('');

  const closeLeadMutation = trpc.leads.close.useMutation({
    onSuccess: () => {
      toast.success(status === 'venda_feita' ? 'Venda finalizada e contabilizada!' : 'Lead marcado como venda perdida');
      handleReset();
      onClose();
      onSuccess?.();
    },
    onError: (error) => {
      toast.error(error.message || 'Erro ao finalizar lead');
    },
  });

  const handleReset = () => {
    setStatus('venda_feita');
    setSaleAmount('');
    setReason('');
    setFollowUpDate('');
  };

  const handleClose = () => {
    if (!reason.trim()) {
      toast.error('Motivo é obrigatório');
      return;
    }

    if (status === 'venda_feita' && !saleAmount.trim()) {
      toast.error('Valor da venda é obrigatório');
      return;
    }

    const saleAmountValue = status === 'venda_feita' ? parseFloat(saleAmount) : undefined;

    closeLeadMutation.mutate({
      id: leadId,
      status,
      reason,
      followUpDate: followUpDate ? new Date(followUpDate) : undefined,
      saleAmount: saleAmountValue,
    });
  };

  return (
    <Dialog open={isOpen} onOpenChange={(open) => { if (!open) onClose(); }}>
      <DialogContent className="max-w-md">
        <DialogHeader>
          <DialogTitle>Finalizar Lead - {leadName}</DialogTitle>
        </DialogHeader>

        <div className="space-y-4">
          {/* Status Selection */}
          <div>
            <label className="text-sm font-medium text-foreground mb-2 block">Status Final</label>
            <select
              value={status}
              onChange={(e) => setStatus(e.target.value as 'venda_feita' | 'venda_perdida')}
              className="w-full px-3 py-2 bg-secondary border border-border rounded-md text-foreground"
            >
              <option value="venda_feita">✓ Venda Realizada</option>
              <option value="venda_perdida">✗ Venda Perdida</option>
            </select>
          </div>

          {/* Sale Amount (only for venda_feita) */}
          {status === 'venda_feita' && (
            <div>
              <label className="text-sm font-medium text-foreground mb-2 block">
                Valor da Venda (R$) *
              </label>
              <Input
                type="number"
                value={saleAmount}
                onChange={(e) => setSaleAmount(e.target.value)}
                placeholder="Ex: 500.00"
                step="0.01"
                min="0"
              />
              <p className="text-xs text-muted-foreground mt-1">
                Este valor será automaticamente contabilizado no Caixa
              </p>
            </div>
          )}

          {/* Reason */}
          <div>
            <label className="text-sm font-medium text-foreground mb-2 block">
              Motivo *
            </label>
            <Input
              value={reason}
              onChange={(e) => setReason(e.target.value)}
              placeholder={
                status === 'venda_feita'
                  ? 'Ex: Cliente confirmou a compra'
                  : 'Ex: Cliente não respondeu'
              }
            />
          </div>

          {/* Follow-up Date */}
          <div>
            <label className="text-sm font-medium text-foreground mb-2 block">
              Data de Follow-up (opcional)
            </label>
            <Input
              type="date"
              value={followUpDate}
              onChange={(e) => setFollowUpDate(e.target.value)}
            />
          </div>

          {/* Info Box */}
          {status === 'venda_feita' && (
            <div className="bg-green-500/10 border border-green-500/20 rounded-lg p-3">
              <p className="text-sm text-green-700">
                ✓ Uma entrada será criada automaticamente no Caixa com o valor informado
              </p>
            </div>
          )}
        </div>

        <DialogFooter>
          <Button variant="outline" onClick={onClose}>
            Cancelar
          </Button>
          <Button
            onClick={handleClose}
            disabled={closeLeadMutation.isPending}
            className={status === 'venda_feita' ? 'bg-green-600 hover:bg-green-700' : 'bg-red-600 hover:bg-red-700'}
          >
            {closeLeadMutation.isPending ? 'Finalizando...' : 'Finalizar'}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
