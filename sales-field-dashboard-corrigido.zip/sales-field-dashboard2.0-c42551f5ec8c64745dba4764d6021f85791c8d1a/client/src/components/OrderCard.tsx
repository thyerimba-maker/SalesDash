import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Edit2, Trash2, MessageSquare } from "lucide-react";
import OrderActionsMenu from "./OrderActionsMenu";

interface OrderCardProps {
  id: number;
  orderNumber: string;
  customerName: string;
  customerPhone: string;
  description: string;
  totalAmount: number;
  status: string;
  customizationName?: string;
  customizationNumber?: string;
  notes?: string;
  onEdit: (id: number) => void;
  onStatusChange: (id: number, status: string) => void;
  onDelete: (id: number) => void;
}

const statusColors: Record<string, string> = {
  pendente: "bg-gray-500",
  confirmado: "bg-blue-500",
  preparando: "bg-yellow-500",
  pronto: "bg-green-500",
  saiu_entrega: "bg-purple-500",
  entregue: "bg-green-600",
  cancelado: "bg-red-500",
  devolvido: "bg-orange-500",
};

const statusLabels: Record<string, string> = {
  pendente: "Pendente",
  confirmado: "Confirmado",
  preparando: "Preparando",
  pronto: "Pronto",
  saiu_entrega: "Saiu p/ Entrega",
  entregue: "Entregue",
  cancelado: "Cancelado",
  devolvido: "Devolvido",
};

export default function OrderCard({
  id,
  orderNumber,
  customerName,
  customerPhone,
  description,
  totalAmount,
  status,
  customizationName,
  customizationNumber,
  notes,
  onEdit,
  onStatusChange,
  onDelete,
}: OrderCardProps) {
  const statusColor = statusColors[status] || "bg-gray-500";
  const statusLabel = statusLabels[status] || status;

  const nextStatus: Record<string, string> = {
    pendente: "confirmado",
    confirmado: "preparando",
    preparando: "pronto",
    pronto: "saiu_entrega",
    saiu_entrega: "entregue",
    entregue: "entregue",
    cancelado: "cancelado",
    devolvido: "devolvido",
  };

  return (
    <Card className="p-4 bg-gray-900 border-gray-700 hover:border-green-500 transition">
      <div className="flex justify-between items-start mb-3">
        <div>
          <h3 className="font-bold text-white text-lg">#{orderNumber}</h3>
          <p className="text-gray-400 text-sm">{customerName}</p>
        </div>
        <Badge className={`${statusColor} text-white`}>{statusLabel}</Badge>
      </div>

      <div className="space-y-2 mb-3 text-sm">
        <p className="text-gray-300">
          <span className="text-gray-500">Telefone:</span> {customerPhone}
        </p>
        <p className="text-gray-300">
          <span className="text-gray-500">Produto:</span> {description}
        </p>
        <p className="text-green-400 font-semibold">
          R$ {(totalAmount / 100).toFixed(2)}
        </p>

        {(customizationName || customizationNumber) && (
          <div className="bg-gray-800 p-2 rounded text-xs">
            <p className="text-gray-400">
              <span className="text-gray-500">Personalização:</span>
            </p>
            {customizationName && (
              <p className="text-gray-300">{customizationName}</p>
            )}
            {customizationNumber && (
              <p className="text-gray-300">{customizationNumber}</p>
            )}
          </div>
        )}

        {notes && (
          <div className="bg-blue-900 bg-opacity-30 p-2 rounded text-xs">
            <p className="text-blue-300 flex items-center gap-1">
              <MessageSquare size={12} /> {notes}
            </p>
          </div>
        )}
      </div>

      <div className="flex gap-2 items-center">
        <Button
          size="sm"
          variant="outline"
          className="flex-1 text-xs"
          onClick={() => onStatusChange(id, nextStatus[status] || status)}
        >
          Próximo Status
        </Button>
        <OrderActionsMenu
          orderId={id}
          currentStatus={status}
          onStatusChange={onStatusChange}
          onEdit={onEdit}
          onDelete={onDelete}
        />
      </div>
    </Card>
  );
}
