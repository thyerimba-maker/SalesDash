import { useState } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group';
import { CheckCircle2, XCircle, Calendar } from 'lucide-react';

interface AttendanceModalProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  leadName: string;
  onClose: (data: { status: 'venda_feita' | 'venda_perdida'; reason: string; followUpDate?: Date; saleAmount?: number }) => void;
  isLoading?: boolean;
}

export default function AttendanceModal({
  open,
  onOpenChange,
  leadName,
  onClose,
  isLoading = false,
}: AttendanceModalProps) {
  const [step, setStep] = useState<'outcome' | 'reason' | 'saleAmount' | 'followup'>('outcome');
  const [outcome, setOutcome] = useState<'venda_feita' | 'venda_perdida' | ''>('');
  const [reason, setReason] = useState('');
  const [saleAmount, setSaleAmount] = useState('');
  const [followUpDate, setFollowUpDate] = useState('');

  const handleNext = () => {
    if (step === 'outcome' && outcome) {
      setStep('reason');
    } else if (step === 'reason' && reason) {
      if (outcome === 'venda_feita') {
        setStep('saleAmount');
      } else {
        setStep('followup');
      }
    } else if (step === 'saleAmount' && saleAmount) {
      handleSubmit();
    } else if (step === 'followup') {
      handleSubmit();
    }
  };

  const handleSubmit = () => {
    if (outcome && reason) {
      onClose({
        status: outcome as 'venda_feita' | 'venda_perdida',
        reason,
        saleAmount: saleAmount ? Math.round(parseFloat(saleAmount) * 100) : undefined,
        followUpDate: followUpDate ? new Date(followUpDate) : undefined,
      });
      resetForm();
    }
  };

  const resetForm = () => {
    setStep('outcome');
    setOutcome('');
    setReason('');
    setSaleAmount('');
    setFollowUpDate('');
  };

  const handleClose = () => {
    onOpenChange(false);
    resetForm();
  };

  return (
    <Dialog open={open} onOpenChange={handleClose}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle>Finalizar Atendimento</DialogTitle>
        </DialogHeader>

        <div className="space-y-6 py-4">
          {/* Step 1: Outcome */}
          {step === 'outcome' && (
            <div className="space-y-4">
              <p className="text-sm text-muted-foreground">
                Qual foi o resultado do atendimento com <strong>{leadName}</strong>?
              </p>

              <RadioGroup value={outcome} onValueChange={(value) => setOutcome(value as any)}>
                <div className="flex items-center space-x-3 p-4 border border-border rounded-lg hover:bg-secondary/50 cursor-pointer transition">
                  <RadioGroupItem value="venda_feita" id="venda_feita" />
                  <Label htmlFor="venda_feita" className="flex-1 cursor-pointer">
                    <div className="flex items-center gap-2">
                      <CheckCircle2 className="w-5 h-5 text-primary" />
                      <div>
                        <p className="font-semibold">Venda Feita ✓</p>
                        <p className="text-xs text-muted-foreground">Cliente confirmou a compra</p>
                      </div>
                    </div>
                  </Label>
                </div>

                <div className="flex items-center space-x-3 p-4 border border-border rounded-lg hover:bg-secondary/50 cursor-pointer transition">
                  <RadioGroupItem value="venda_perdida" id="venda_perdida" />
                  <Label htmlFor="venda_perdida" className="flex-1 cursor-pointer">
                    <div className="flex items-center gap-2">
                      <XCircle className="w-5 h-5 text-destructive" />
                      <div>
                        <p className="font-semibold">Venda Perdida ✗</p>
                        <p className="text-xs text-muted-foreground">Cliente recusou ou desistiu</p>
                      </div>
                    </div>
                  </Label>
                </div>
              </RadioGroup>
            </div>
          )}

          {/* Step 2: Reason */}
          {step === 'reason' && (
            <div className="space-y-4">
              <div>
                <Label className="text-base font-semibold mb-2 block">
                  {outcome === 'venda_feita' ? 'Qual produto foi vendido?' : 'Qual foi o motivo da recusa?'}
                </Label>
                <Textarea
                  placeholder={
                    outcome === 'venda_feita'
                      ? 'Ex: Combo Premium - R$ 2.500,00'
                      : 'Ex: Cliente disse que precisa pensar melhor, vai retornar em 2 semanas'
                  }
                  value={reason}
                  onChange={(e) => setReason(e.target.value)}
                  className="min-h-24"
                />
              </div>
            </div>
          )}

          {/* Step 3: Sale Amount (only for completed sales) */}
          {step === 'saleAmount' && (
            <div className="space-y-4">
              <div>
                <Label className="text-base font-semibold mb-2 block">
                  Qual foi o valor da venda?
                </Label>
                <p className="text-sm text-muted-foreground mb-3">
                  Digite o valor em reais (ex: 2500.00)
                </p>
                <div className="flex items-center gap-2">
                  <span className="text-lg font-semibold text-muted-foreground">R$</span>
                  <Input
                    type="number"
                    step="0.01"
                    min="0"
                    placeholder="0.00"
                    value={saleAmount}
                    onChange={(e) => setSaleAmount(e.target.value)}
                    className="text-lg font-semibold"
                  />
                </div>
              </div>
            </div>
          )}

          {/* Step 4: Follow-up (only for lost sales) */}
          {step === 'followup' && (
            <div className="space-y-4">
              <div>
                <Label className="text-base font-semibold mb-2 block flex items-center gap-2">
                  <Calendar className="w-4 h-4" />
                  Agendar Follow-up
                </Label>
                <p className="text-sm text-muted-foreground mb-3">
                  Quando você gostaria de fazer contato novamente?
                </p>
                <Input
                  type="datetime-local"
                  value={followUpDate}
                  onChange={(e) => setFollowUpDate(e.target.value)}
                  className="w-full"
                />
                <p className="text-xs text-muted-foreground mt-2">
                  Deixe em branco para não agendar follow-up agora
                </p>
              </div>
            </div>
          )}
        </div>

        <DialogFooter className="flex gap-2 justify-between">
          <Button
            variant="outline"
            onClick={handleClose}
            disabled={isLoading}
          >
            Cancelar
          </Button>

          <div className="flex gap-2">
            {step !== 'outcome' && (
              <Button
                variant="outline"
                onClick={() => {
                  if (step === 'reason') setStep('outcome');
                  if (step === 'saleAmount') setStep('reason');
                  if (step === 'followup') setStep(outcome === 'venda_feita' ? 'saleAmount' : 'reason');
                }}
                disabled={isLoading}
              >
                Voltar
              </Button>
            )}

            <Button
              onClick={handleNext}
              disabled={
                isLoading ||
                (step === 'outcome' && !outcome) ||
                (step === 'reason' && !reason)
              }
              className="bg-primary hover:bg-primary/90"
            >
              {step === 'followup' ? 'Finalizar' : 'Próximo'}
            </Button>
          </div>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
