import { useState } from 'react';
import { Menu, X, BarChart3, Users, TrendingUp, HelpCircle, History, Calendar, Package, Wallet, Settings, Truck } from 'lucide-react';
import { Button } from '@/components/ui/button';

interface DashboardLayoutProps {
  children: React.ReactNode;
  title: string;
}

export default function DashboardLayout({ children, title }: DashboardLayoutProps) {
  const [sidebarOpen, setSidebarOpen] = useState(false);

  const navItems = [
    { icon: BarChart3, label: 'Dashboard', href: '/' },
    { icon: Users, label: 'Leads', href: '/leads' },
    { icon: TrendingUp, label: 'Vendas', href: '/sales' },
    { icon: Package, label: 'Estoque', href: '/inventory' },
    { icon: Truck, label: 'Fornecedores', href: '/suppliers' },
    { icon: Wallet, label: 'Caixa', href: '/cash-register' },
    { icon: History, label: 'Histórico', href: '/history' },
    { icon: Settings, label: 'Configurações', href: '/settings' },
    { icon: HelpCircle, label: 'Suporte', href: 'tel:69999742271' },
  ];

  return (
    <div className="flex h-screen bg-background">
      {/* Sidebar */}
      <aside className={`
        fixed inset-y-0 left-0 z-50 w-64 bg-card border-r border-border
        transform transition-transform duration-300 ease-out
        ${sidebarOpen ? 'translate-x-0' : '-translate-x-full'}
        lg:static lg:translate-x-0
      `}>
        <div className="p-6 border-b border-border">
          <h1 className="text-2xl font-bold text-primary">SalesField</h1>
          <p className="text-xs text-muted-foreground mt-1">Dashboard de Vendas</p>
        </div>
        
        <nav className="p-4 space-y-2">
          {navItems.map((item) => {
            const isSupport = item.label === 'Suporte';
            return (
              <a
                key={item.label}
                href={item.href}
                target={isSupport ? '_blank' : undefined}
                rel={isSupport ? 'noopener noreferrer' : undefined}
                className={`flex items-center gap-3 px-4 py-3 rounded-lg text-foreground hover:bg-secondary transition-colors min-h-[44px] ${
                  isSupport ? 'bg-primary/10 text-primary font-semibold' : ''
                }`}
                title={isSupport ? 'Clique para ligar: 69999742271' : ''}
              >
                <item.icon className="w-5 h-5" />
                <span className="font-medium text-sm">{item.label}</span>
              </a>
            );
          })}
        </nav>
      </aside>

      {/* Overlay para mobile */}
      {sidebarOpen && (
        <div
          className="fixed inset-0 z-40 bg-black/50 lg:hidden"
          onClick={() => setSidebarOpen(false)}
        />
      )}

      {/* Main Content */}
      <div className="flex-1 flex flex-col overflow-hidden">
        {/* Topbar */}
        <header className="sticky top-0 z-30 bg-card border-b border-border">
          <div className="flex items-center justify-between h-16 px-4 md:px-6">
            <div className="flex items-center gap-4">
              <Button
                variant="ghost"
                size="icon"
                className="lg:hidden"
                onClick={() => setSidebarOpen(!sidebarOpen)}
              >
                {sidebarOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
              </Button>
              <h2 className="text-lg font-bold text-foreground hidden sm:block">{title}</h2>
            </div>
            
            <div className="flex items-center gap-2">
              <div className="w-10 h-10 rounded-full bg-primary/20 flex items-center justify-center">
                <span className="text-sm font-bold text-primary">JD</span>
              </div>
            </div>
          </div>
        </header>

        {/* Page Content */}
        <main className="flex-1 overflow-auto">
          <div className="p-4 md:p-6 max-w-7xl mx-auto">
            {children}
          </div>
        </main>
      </div>
    </div>
  );
}
