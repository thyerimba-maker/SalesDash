import { useState } from "react";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";

interface OrderModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSubmit: (data: any) => void;
  initialData?: any;
  isLoading?: boolean;
}

export default function OrderModal({
  isOpen,
  onClose,
  onSubmit,
  initialData,
  isLoading,
}: OrderModalProps) {
  const [step, setStep] = useState(1);
  const [formData, setFormData] = useState(
    initialData || {
      customerName: "",
      customerPhone: "",
      customerEmail: "",
      orderNumber: "",
      description: "",
      totalAmount: "",
      customizationName: "",
      customizationNumber: "",
      customizationDetails: "",
      notes: "",
    }
  );

  const handleChange = (e: any) => {
    const { name, value } = e.target;
    setFormData((prev: any) => ({
      ...prev,
      [name]: value,
    }));
  };

  const handleSubmit = () => {
    const submitData = {
      ...formData,
      totalAmount: Math.round(parseFloat(formData.totalAmount) * 100) || 0,
    };
    onSubmit(submitData);
    setStep(1);
    setFormData({
      customerName: "",
      customerPhone: "",
      customerEmail: "",
      orderNumber: "",
      description: "",
      totalAmount: "",
      customizationName: "",
      customizationNumber: "",
      customizationDetails: "",
      notes: "",
    });
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="bg-gray-900 border-gray-700 max-w-md">
        <DialogHeader>
          <DialogTitle className="text-white">
            {initialData ? "Editar Pedido" : "Novo Pedido"}
          </DialogTitle>
        </DialogHeader>

        <div className="space-y-4">
          {step === 1 && (
            <>
              <div>
                <Label className="text-gray-300">Nome do Cliente *</Label>
                <Input
                  name="customerName"
                  value={formData.customerName}
                  onChange={handleChange}
                  placeholder="João Silva"
                  className="bg-gray-800 border-gray-700 text-white"
                />
              </div>

              <div>
                <Label className="text-gray-300">Telefone *</Label>
                <Input
                  name="customerPhone"
                  value={formData.customerPhone}
                  onChange={handleChange}
                  placeholder="(69) 99999-7427"
                  className="bg-gray-800 border-gray-700 text-white"
                />
              </div>

              <div>
                <Label className="text-gray-300">Email</Label>
                <Input
                  name="customerEmail"
                  type="email"
                  value={formData.customerEmail}
                  onChange={handleChange}
                  placeholder="joao@example.com"
                  className="bg-gray-800 border-gray-700 text-white"
                />
              </div>

              <div>
                <Label className="text-gray-300">Número do Pedido *</Label>
                <Input
                  name="orderNumber"
                  value={formData.orderNumber}
                  onChange={handleChange}
                  placeholder="PED-001"
                  className="bg-gray-800 border-gray-700 text-white"
                />
              </div>
            </>
          )}

          {step === 2 && (
            <>
              <div>
                <Label className="text-gray-300">Descrição do Produto *</Label>
                <Textarea
                  name="description"
                  value={formData.description}
                  onChange={handleChange}
                  placeholder="Camiseta azul, tamanho G"
                  className="bg-gray-800 border-gray-700 text-white"
                  rows={3}
                />
              </div>

              <div>
                <Label className="text-gray-300">Valor Total (R$) *</Label>
                <Input
                  name="totalAmount"
                  type="number"
                  step="0.01"
                  value={formData.totalAmount}
                  onChange={handleChange}
                  placeholder="99.90"
                  className="bg-gray-800 border-gray-700 text-white"
                />
              </div>

              <div>
                <Label className="text-gray-300">Notas</Label>
                <Textarea
                  name="notes"
                  value={formData.notes}
                  onChange={handleChange}
                  placeholder="Observações sobre o pedido..."
                  className="bg-gray-800 border-gray-700 text-white"
                  rows={2}
                />
              </div>
            </>
          )}

          {step === 3 && (
            <>
              <div className="bg-blue-900 bg-opacity-30 p-3 rounded">
                <p className="text-blue-300 text-sm mb-2">
                  Personalização (Opcional)
                </p>
              </div>

              <div>
                <Label className="text-gray-300">Nome da Personalização</Label>
                <Input
                  name="customizationName"
                  value={formData.customizationName}
                  onChange={handleChange}
                  placeholder="ex: Cor Azul"
                  className="bg-gray-800 border-gray-700 text-white"
                />
              </div>

              <div>
                <Label className="text-gray-300">Número/Tamanho</Label>
                <Input
                  name="customizationNumber"
                  value={formData.customizationNumber}
                  onChange={handleChange}
                  placeholder="ex: Tamanho G"
                  className="bg-gray-800 border-gray-700 text-white"
                />
              </div>

              <div>
                <Label className="text-gray-300">Detalhes Adicionais</Label>
                <Textarea
                  name="customizationDetails"
                  value={formData.customizationDetails}
                  onChange={handleChange}
                  placeholder="Mais detalhes sobre a personalização..."
                  className="bg-gray-800 border-gray-700 text-white"
                  rows={2}
                />
              </div>
            </>
          )}
        </div>

        <DialogFooter className="flex gap-2 justify-between">
          <div className="flex gap-2">
            {step > 1 && (
              <Button
                variant="outline"
                onClick={() => setStep(step - 1)}
                disabled={isLoading}
              >
                Voltar
              </Button>
            )}
          </div>

          <div className="flex gap-2">
            {step < 3 && (
              <Button
                onClick={() => setStep(step + 1)}
                className="bg-green-600 hover:bg-green-700"
                disabled={isLoading}
              >
                Próximo
              </Button>
            )}

            {step === 3 && (
              <Button
                onClick={handleSubmit}
                className="bg-green-600 hover:bg-green-700"
                disabled={isLoading}
              >
                {isLoading ? "Salvando..." : "Salvar Pedido"}
              </Button>
            )}

            <Button
              variant="ghost"
              onClick={onClose}
              disabled={isLoading}
              className="text-gray-400"
            >
              Cancelar
            </Button>
          </div>
        </DialogFooter>

        <div className="flex gap-1 justify-center mt-2">
          {[1, 2, 3].map((s) => (
            <div
              key={s}
              className={`h-1 w-8 rounded ${
                s <= step ? "bg-green-600" : "bg-gray-700"
              }`}
            />
          ))}
        </div>
      </DialogContent>
    </Dialog>
  );
}
