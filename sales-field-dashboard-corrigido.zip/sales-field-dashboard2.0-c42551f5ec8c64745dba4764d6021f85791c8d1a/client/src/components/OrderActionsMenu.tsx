import { useState } from 'react';
import { MoreVertical, CheckCircle, Truck, CreditCard, Package } from 'lucide-react';
import { Button } from '@/components/ui/button';

interface OrderActionsMenuProps {
  orderId: number;
  currentStatus: string;
  onStatusChange: (orderId: number, newStatus: string) => void;
  onEdit: (orderId: number) => void;
  onDelete: (orderId: number) => void;
}

const statusTransitions = {
  pendente: ['confirmado', 'cancelado'],
  confirmado: ['preparando', 'cancelado'],
  preparando: ['pronto', 'cancelado'],
  pronto: ['saiu_entrega', 'cancelado'],
  saiu_entrega: ['entregue', 'devolvido'],
  entregue: ['devolvido'],
  cancelado: [],
  devolvido: [],
};

const statusConfig = {
  confirmado: { icon: CheckCircle, label: 'Confirmado', color: 'text-green-600' },
  saiu_entrega: { icon: Truck, label: 'Saiu p/ Entrega', color: 'text-blue-600' },
  pronto: { icon: CreditCard, label: 'Pronto', color: 'text-purple-600' },
  entregue: { icon: Package, label: 'Entregue', color: 'text-green-700' },
};

export default function OrderActionsMenu({
  orderId,
  currentStatus,
  onStatusChange,
  onEdit,
  onDelete,
}: OrderActionsMenuProps) {
  const [isOpen, setIsOpen] = useState(false);

  const availableTransitions = statusTransitions[currentStatus as keyof typeof statusTransitions] || [];

  return (
    <div className="relative">
      <button
        onClick={() => setIsOpen(!isOpen)}
        className="p-2 hover:bg-secondary rounded-md transition-colors"
      >
        <MoreVertical className="w-5 h-5 text-foreground" />
      </button>

      {isOpen && (
        <>
          {/* Overlay to close menu */}
          <div
            className="fixed inset-0 z-40"
            onClick={() => setIsOpen(false)}
          />

          {/* Menu */}
          <div className="absolute right-0 top-full mt-2 bg-card border border-border rounded-lg shadow-lg z-50 min-w-[200px]">
            <div className="py-2">
              {/* Status Change Options */}
              <div className="px-4 py-2 border-b border-border">
                <p className="text-xs font-semibold text-muted-foreground mb-2">Mudar Status</p>
                {availableTransitions.length > 0 ? (
                  <div className="space-y-1">
                    {availableTransitions.map((status) => (
                      <button
                        key={status}
                        onClick={() => {
                          onStatusChange(orderId, status);
                          setIsOpen(false);
                        }}
                        className="w-full text-left px-3 py-2 text-sm hover:bg-secondary rounded transition-colors text-foreground"
                      >
                        → {status.charAt(0).toUpperCase() + status.slice(1).replace('_', ' ')}
                      </button>
                    ))}
                  </div>
                ) : (
                  <p className="text-xs text-muted-foreground italic">Sem transições disponíveis</p>
                )}
              </div>

              {/* Quick Status Buttons */}
              <div className="px-4 py-2 border-b border-border">
                <p className="text-xs font-semibold text-muted-foreground mb-2">Status Rápido</p>
                <div className="space-y-1">
                  {Object.entries(statusConfig).map(([key, config]) => {
                    const Icon = config.icon;
                    return (
                      <button
                        key={key}
                        onClick={() => {
                          onStatusChange(orderId, key);
                          setIsOpen(false);
                        }}
                        className="w-full flex items-center gap-2 px-3 py-2 text-sm hover:bg-secondary rounded transition-colors text-foreground"
                      >
                        <Icon className={`w-4 h-4 ${config.color}`} />
                        {config.label}
                      </button>
                    );
                  })}
                </div>
              </div>

              {/* Edit and Delete */}
              <div className="px-4 py-2 space-y-1">
                <button
                  onClick={() => {
                    onEdit(orderId);
                    setIsOpen(false);
                  }}
                  className="w-full text-left px-3 py-2 text-sm hover:bg-secondary rounded transition-colors text-foreground"
                >
                  ✏️ Editar Pedido
                </button>
                <button
                  onClick={() => {
                    if (confirm('Tem certeza que deseja deletar este pedido?')) {
                      onDelete(orderId);
                      setIsOpen(false);
                    }
                  }}
                  className="w-full text-left px-3 py-2 text-sm hover:bg-red-500/10 rounded transition-colors text-red-600"
                >
                  🗑️ Deletar Pedido
                </button>
              </div>
            </div>
          </div>
        </>
      )}
    </div>
  );
}
