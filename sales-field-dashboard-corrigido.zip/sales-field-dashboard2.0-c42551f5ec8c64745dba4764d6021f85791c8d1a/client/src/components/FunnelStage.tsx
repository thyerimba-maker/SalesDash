interface FunnelStageProps {
  stage: string;
  count: number;
  total: number;
  color: 'primary' | 'secondary' | 'accent' | 'destructive';
}

const colorClasses = {
  primary: 'bg-primary',
  secondary: 'bg-secondary',
  accent: 'bg-accent',
  destructive: 'bg-destructive',
};

const colorBgClasses = {
  primary: 'bg-primary/10',
  secondary: 'bg-secondary/10',
  accent: 'bg-accent/10',
  destructive: 'bg-destructive/10',
};

export default function FunnelStage({ stage, count, total, color }: FunnelStageProps) {
  const percentage = (count / total) * 100;
  const conversionRate = total > 0 ? ((count / total) * 100).toFixed(1) : '0';

  return (
    <div className="mb-6">
      <div className="flex items-center justify-between mb-2">
        <span className="font-semibold text-foreground">{stage}</span>
        <span className="text-sm font-bold text-primary">{count} leads</span>
      </div>
      
      <div className={`h-12 rounded-lg ${colorBgClasses[color]} flex items-center overflow-hidden border border-border`}>
        <div
          className={`h-full ${colorClasses[color]} flex items-center justify-center transition-all duration-500`}
          style={{ width: `${percentage}%` }}
        >
          {percentage > 15 && (
            <span className="text-sm font-bold text-white">{conversionRate}%</span>
          )}
        </div>
      </div>
      
      <p className="text-xs text-muted-foreground mt-2">{conversionRate}% de conversão</p>
    </div>
  );
}
