import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { AlertCircle, Lock } from 'lucide-react';
import { usePassword } from '@/contexts/PasswordContext';

export default function PasswordModal() {
  const { setAuthenticated } = usePassword();
  const [inputPassword, setInputPassword] = useState('');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setLoading(true);

    // Simple password verification (stored in localStorage)
    const storedPassword = localStorage.getItem('dashboardPassword');
    
    if (!storedPassword) {
      // No password set, allow access
      setAuthenticated(true);
      localStorage.setItem('dashboardAuth', 'true');
      return;
    }

    if (inputPassword === storedPassword) {
      setAuthenticated(true);
      localStorage.setItem('dashboardAuth', 'true');
    } else {
      setError('Senha incorreta');
    }

    setLoading(false);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-green-900 via-gray-900 to-gray-800 flex items-center justify-center p-4">
      <Card className="w-full max-w-md bg-gray-800 border-gray-700">
        <CardHeader className="space-y-2 text-center">
          <div className="flex justify-center mb-4">
            <div className="bg-green-600 p-3 rounded-full">
              <Lock className="h-6 w-6 text-white" />
            </div>
          </div>
          <CardTitle className="text-2xl text-white">SalesField</CardTitle>
          <CardDescription className="text-gray-400">
            Dashboard Protegido
          </CardDescription>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleSubmit} className="space-y-4">
            {error && (
              <Alert variant="destructive" className="bg-red-900 border-red-700">
                <AlertCircle className="h-4 w-4" />
                <AlertDescription className="text-red-200">{error}</AlertDescription>
              </Alert>
            )}

            <div className="space-y-2">
              <label className="text-sm font-medium text-gray-300">Senha</label>
              <Input
                type="password"
                placeholder="Digite a senha"
                value={inputPassword}
                onChange={(e) => setInputPassword(e.target.value)}
                className="bg-gray-700 border-gray-600 text-white placeholder-gray-500"
                disabled={loading}
                autoFocus
              />
            </div>

            <Button
              type="submit"
              className="w-full bg-green-600 hover:bg-green-700 text-white"
              disabled={loading || !inputPassword}
            >
              {loading ? 'Verificando...' : 'Acessar'}
            </Button>
          </form>
        </CardContent>
      </Card>
    </div>
  );
}
