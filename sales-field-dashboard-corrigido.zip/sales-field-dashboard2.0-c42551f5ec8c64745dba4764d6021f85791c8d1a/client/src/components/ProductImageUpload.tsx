import { useState } from 'react';
import { Upload, X } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { toast } from 'sonner';

interface ProductImageUploadProps {
  productId: number;
  currentImageUrl?: string;
  onImageUpload: (imageUrl: string) => void;
  isLoading?: boolean;
}

export default function ProductImageUpload({
  productId,
  currentImageUrl,
  onImageUpload,
  isLoading = false,
}: ProductImageUploadProps) {
  const [isUploading, setIsUploading] = useState(false);
  const [preview, setPreview] = useState<string | null>(currentImageUrl || null);

  const handleFileSelect = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    // Validate file size (max 5MB)
    if (file.size > 5 * 1024 * 1024) {
      toast.error('Imagem muito grande. Máximo 5MB');
      return;
    }

    // Validate file type
    if (!file.type.startsWith('image/')) {
      toast.error('Arquivo deve ser uma imagem');
      return;
    }

    setIsUploading(true);
    try {
      // Create preview
      const reader = new FileReader();
      reader.onload = (e) => {
        const result = e.target?.result as string;
        setPreview(result);
      };
      reader.readAsDataURL(file);

      // Upload to storage
      const formData = new FormData();
      formData.append('file', file);

      const uploadResponse = await fetch('/api/upload', {
        method: 'POST',
        body: formData,
      });

      if (!uploadResponse.ok) {
        throw new Error('Erro ao fazer upload');
      }

      const { url } = await uploadResponse.json();
      onImageUpload(url);
      toast.success('Imagem enviada com sucesso');
    } catch (error) {
      toast.error('Erro ao fazer upload da imagem');
      setPreview(currentImageUrl || null);
    } finally {
      setIsUploading(false);
    }
  };

  const handleRemoveImage = () => {
    setPreview(null);
    onImageUpload('');
    toast.success('Imagem removida');
  };

  return (
    <div className="space-y-3">
      {preview ? (
        <div className="relative w-full h-48 rounded-lg overflow-hidden bg-secondary">
          <img
            src={preview}
            alt="Product"
            className="w-full h-full object-cover"
          />
          <button
            onClick={handleRemoveImage}
            disabled={isUploading || isLoading}
            className="absolute top-2 right-2 p-1 bg-destructive/80 hover:bg-destructive text-white rounded"
          >
            <X size={16} />
          </button>
        </div>
      ) : (
        <label className="flex flex-col items-center justify-center w-full h-48 border-2 border-dashed border-border rounded-lg cursor-pointer hover:bg-secondary/50 transition">
          <div className="flex flex-col items-center justify-center pt-5 pb-6">
            <Upload size={32} className="text-muted-foreground mb-2" />
            <p className="text-sm text-muted-foreground">Clique para fazer upload</p>
            <p className="text-xs text-muted-foreground">PNG, JPG até 5MB</p>
          </div>
          <input
            type="file"
            accept="image/*"
            onChange={handleFileSelect}
            disabled={isUploading || isLoading}
            className="hidden"
          />
        </label>
      )}
    </div>
  );
}
