import { X } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useState } from 'react';
import LeadActionsMenu from './LeadActionsMenu';
import StatusBadge from './StatusBadge';
import { trpc } from '@/lib/trpc';
import { toast } from 'sonner';
import ProductPreviewModal from './ProductPreviewModal';
import CloseLeadModal from './CloseLeadModal';

interface LeadCardProps {
  id: string;
  leadId: number;
  name: string;
  phone: string;
  status: 'leads' | 'atendimento' | 'aguardando' | 'confirmado' | 'em_rota' | 'concluido' | 'venda_feita' | 'venda_perdida';
  product: string;
  notes?: string;
  lastContact?: string;
  onWhatsApp?: () => void;
  onEdit?: () => void;
  onClose?: () => void;
  onNotesUpdate?: () => void;
  onLinkProduct?: () => void;
}



export default function LeadCard({
  id,
  leadId,
  name,
  phone,
  status,
  product,
  notes = '',
  lastContact,
  onWhatsApp,
  onEdit,
  onClose,
  onNotesUpdate,
  onLinkProduct,
}: LeadCardProps) {
  const [isEditingNotes, setIsEditingNotes] = useState(false);
  const [editedNotes, setEditedNotes] = useState(notes || '');
  const [isSavingNotes, setIsSavingNotes] = useState(false);
  const [previewModalOpen, setPreviewModalOpen] = useState(false);
  const [selectedProductForPreview, setSelectedProductForPreview] = useState<any>(null);
  const [closeLeadModalOpen, setCloseLeadModalOpen] = useState(false);

  const updateLeadMutation = trpc.leads.update.useMutation();
  const { data: linkedProducts, refetch: refetchLinkedProducts } = trpc.leads.getLinkedProducts.useQuery({ leadId });
  const deleteProductMutation = trpc.leads.deleteProduct.useMutation();
  const deleteLeadMutation = trpc.leads.delete.useMutation();
  const utils = trpc.useUtils();

  const handleSaveNotes = async () => {
    setIsSavingNotes(true);
    try {
      await updateLeadMutation.mutateAsync({
        id: leadId,
        notes: editedNotes,
      });
      setIsEditingNotes(false);
      toast.success('Anotações salvas');
      if (onNotesUpdate) onNotesUpdate();
    } catch (error) {
      toast.error('Erro ao salvar anotações');
    } finally {
      setIsSavingNotes(false);
    }
  };

  const handleDeleteProduct = async (productId: number) => {
    try {
      await deleteProductMutation.mutateAsync({ productId, leadId });
      await utils.leads.getLinkedProducts.invalidate({ leadId });
      toast.success('Produto removido e estoque restaurado');
    } catch (error) {
      toast.error('Erro ao remover produto');
    }
  };

  const handleOpenPreview = (product: any) => {
    setSelectedProductForPreview(product);
    setPreviewModalOpen(true);
  };

  const handleDeleteFromPreview = async (productId: number) => {
    await handleDeleteProduct(productId);
    setPreviewModalOpen(false);
  };

  return (
    <div className="bg-card border border-border rounded-lg p-4 hover:shadow-lg transition-shadow">
      <div className="flex justify-between items-start mb-3">
        <div className="flex-1">
          <h3 className="font-semibold text-foreground">{name}</h3>
          <p className="text-sm text-muted-foreground">{phone}</p>
        </div>
        <div className="flex items-center gap-2">
          <StatusBadge status={status} />
          <LeadActionsMenu
            leadId={leadId}
            onEdit={onEdit}
            onClose={onClose}
            onLinkProduct={onLinkProduct}
            onCloseLead={() => setCloseLeadModalOpen(true)}
            onDelete={async () => {
              if (confirm(`Tem certeza que deseja deletar o lead "${name}"?`)) {
                try {
                  await deleteLeadMutation.mutateAsync({ id: leadId });
                  await utils.leads.list.invalidate();
                  toast.success('Lead deletado com sucesso');
                  if (onClose) onClose();
                } catch (error) {
                  toast.error('Erro ao deletar lead');
                }
              }
            }}
          />
        </div>
      </div>

      <p className="text-sm text-muted-foreground mb-3">
        <span className="font-medium text-foreground">Produto:</span> {product}
      </p>

      {lastContact && (
        <p className="text-xs text-muted-foreground mb-3">
          Último contato: {lastContact}
        </p>
      )}

      {linkedProducts && linkedProducts.length > 0 && (
        <div className="bg-primary/10 border border-primary/20 rounded p-3 mb-3">
          <p className="text-xs font-semibold text-primary mb-2">Produtos Vinculados:</p>
          <div className="space-y-2">
            {linkedProducts.map((lp: any) => (
              <button
                key={lp.id}
                onClick={() => handleOpenPreview(lp)}
                className="w-full text-left bg-background hover:bg-secondary border border-border rounded p-2 transition-colors"
              >
                <div className="flex justify-between items-start">
                  <div className="flex-1">
                    <p className="text-xs font-medium text-foreground">{lp.productName}</p>
                    <div className="text-xs text-muted-foreground mt-1 flex gap-2 flex-wrap">
                      {lp.sizeP > 0 && <span>P: {lp.sizeP}</span>}
                      {lp.sizeM > 0 && <span>M: {lp.sizeM}</span>}
                      {lp.sizeG > 0 && <span>G: {lp.sizeG}</span>}
                      {lp.sizeGG > 0 && <span>GG: {lp.sizeGG}</span>}
                    </div>
                  </div>
                  <span className="text-xs font-semibold text-primary ml-2">{lp.totalQuantity}</span>
                </div>
              </button>
            ))}
          </div>
        </div>
      )}

      {/* Notes Section */}
      <div className="bg-secondary/50 rounded p-3 mb-4">
        {isEditingNotes ? (
          <div className="space-y-2">
            <textarea
              value={editedNotes}
              onChange={(e) => setEditedNotes(e.target.value)}
              placeholder="Adicione anotações..."
              className="w-full p-2 text-sm border border-border rounded bg-background text-foreground focus:outline-none focus:ring-2 focus:ring-primary"
              rows={3}
            />
            <div className="flex gap-2">
              <Button
                size="sm"
                onClick={handleSaveNotes}
                disabled={isSavingNotes}
              >
                Salvar
              </Button>
              <Button
                size="sm"
                variant="outline"
                onClick={() => {
                  setIsEditingNotes(false);
                  setEditedNotes(notes || '');
                }}
              >
                Cancelar
              </Button>
            </div>
          </div>
        ) : (
          <div>
            <p className="text-sm text-foreground mb-2">
              {editedNotes || <span className="text-muted-foreground italic">Sem anotações</span>}
            </p>
            <Button
              size="sm"
              variant="ghost"
              onClick={() => setIsEditingNotes(true)}
              className="h-auto p-0 text-xs"
            >
              Editar anotações
            </Button>
          </div>
        )}
      </div>

      {/* Action Buttons */}
      <div className="flex gap-2">
        {onWhatsApp && (
          <Button
            size="sm"
            variant="outline"
            onClick={onWhatsApp}
            className="flex-1"
          >
            WhatsApp
          </Button>
        )}
      </div>

      {/* Product Preview Modal */}
      <ProductPreviewModal
        isOpen={previewModalOpen}
        onClose={() => setPreviewModalOpen(false)}
        product={selectedProductForPreview}
        onDelete={handleDeleteFromPreview}
        isDeleting={deleteProductMutation.isPending}
      />

      {/* Close Lead Modal */}
      <CloseLeadModal
        isOpen={closeLeadModalOpen}
        onClose={() => setCloseLeadModalOpen(false)}
        leadId={leadId}
        leadName={name}
        onSuccess={() => {
          if (onClose) onClose();
          refetchLinkedProducts();
        }}
      />
    </div>
  );
}
