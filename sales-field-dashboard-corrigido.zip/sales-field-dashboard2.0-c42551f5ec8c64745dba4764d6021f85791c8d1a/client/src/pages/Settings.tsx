import { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { toast } from 'sonner';
import DashboardLayout from '@/components/DashboardLayout';
import { trpc } from '@/lib/trpc';
import { Trash2, Plus, Download } from 'lucide-react';

interface AppUser {
  id: number;
  username: string;
  status: 'active' | 'inactive';
  createdAt: Date;
}

export default function Settings() {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [loading, setLoading] = useState(false);
  const [users, setUsers] = useState<AppUser[]>([]);

  const createUserMutation = trpc.auth.createUser.useMutation();
  const getAllUsersMutation = trpc.auth.getAllUsers.useQuery();
  const deleteUserMutation = trpc.auth.deleteUser.useMutation();
  const exportInventoryCSVMutation = trpc.backup.exportInventoryCSV.useQuery();
  const exportInventoryJSONMutation = trpc.backup.exportInventoryJSON.useQuery();
  const exportSalesCSVMutation = trpc.backup.exportCSV.useQuery();
  const exportSalesJSONMutation = trpc.backup.exportJSON.useQuery();

  useEffect(() => {
    if (getAllUsersMutation.data) {
      setUsers(getAllUsersMutation.data as AppUser[]);
    }
  }, [getAllUsersMutation.data]);

  const handleCreateUser = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!username.trim()) {
      toast.error('Digite um usuário');
      return;
    }

    if (!password.trim() || password.length < 4) {
      toast.error('A senha deve ter pelo menos 4 caracteres');
      return;
    }

    setLoading(true);
    try {
      await createUserMutation.mutateAsync({ username, password });
      toast.success('Usuário criado com sucesso!');
      setUsername('');
      setPassword('');
      // Refresh user list
      getAllUsersMutation.refetch();
    } catch (error: any) {
      toast.error(error.message || 'Erro ao criar usuário');
    } finally {
      setLoading(false);
    }
  };

  const handleDeleteUser = async (userId: number) => {
    if (!confirm('Tem certeza que deseja deletar este usuário?')) {
      return;
    }

    try {
      await deleteUserMutation.mutateAsync({ userId });
      toast.success('Usuário deletado com sucesso');
      getAllUsersMutation.refetch();
    } catch (error: any) {
      toast.error(error.message || 'Erro ao deletar usuário');
    }
  };

  const handleLogout = () => {
    sessionStorage.removeItem('appAuth');
    window.location.reload();
  };

  const downloadFile = (content: string, filename: string, type: string) => {
    const blob = new Blob([content], { type });
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = filename;
    document.body.appendChild(a);
    a.click();
    window.URL.revokeObjectURL(url);
    document.body.removeChild(a);
    toast.success(`${filename} baixado com sucesso!`);
  };

  const handleDownloadInventoryCSV = async () => {
    try {
      if (exportInventoryCSVMutation.data) {
        downloadFile(exportInventoryCSVMutation.data.data, exportInventoryCSVMutation.data.filename, 'text/csv');
      }
    } catch (error) {
      toast.error('Erro ao baixar backup de estoque');
    }
  };

  const handleDownloadInventoryJSON = async () => {
    try {
      if (exportInventoryJSONMutation.data) {
        downloadFile(exportInventoryJSONMutation.data.data, exportInventoryJSONMutation.data.filename, 'application/json');
      }
    } catch (error) {
      toast.error('Erro ao baixar backup de estoque');
    }
  };

  const handleDownloadSalesCSV = async () => {
    try {
      if (exportSalesCSVMutation.data) {
        downloadFile(exportSalesCSVMutation.data.data, exportSalesCSVMutation.data.filename, 'text/csv');
      }
    } catch (error) {
      toast.error('Erro ao baixar backup de vendas');
    }
  };

  const handleDownloadSalesJSON = async () => {
    try {
      if (exportSalesJSONMutation.data) {
        downloadFile(exportSalesJSONMutation.data.data, exportSalesJSONMutation.data.filename, 'application/json');
      }
    } catch (error) {
      toast.error('Erro ao baixar backup de vendas');
    }
  };

  return (
    <DashboardLayout title="Configurações">
      <div className="space-y-6">
        <div>
          <h1 className="text-3xl font-bold text-foreground">Configurações</h1>
          <p className="text-muted-foreground mt-2">Gerencie os usuários do dashboard</p>
        </div>

        {/* Create User Section */}
        <Card className="bg-card border-border">
          <CardHeader>
            <CardTitle className="text-foreground">Criar Novo Usuário</CardTitle>
            <CardDescription className="text-muted-foreground">
              Adicione um novo usuário ao dashboard
            </CardDescription>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleCreateUser} className="space-y-4">
              <div>
                <label className="text-sm font-medium text-foreground mb-2 block">
                  Usuário
                </label>
                <Input
                  type="text"
                  placeholder="Digite o nome de usuário"
                  value={username}
                  onChange={(e) => setUsername(e.target.value)}
                  disabled={loading}
                  className="bg-background border-border text-foreground"
                />
              </div>

              <div>
                <label className="text-sm font-medium text-foreground mb-2 block">
                  Senha
                </label>
                <Input
                  type="password"
                  placeholder="Digite a senha (mínimo 4 caracteres)"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  disabled={loading}
                  className="bg-background border-border text-foreground"
                />
              </div>

              <Button
                type="submit"
                disabled={loading || !username || !password}
                className="bg-green-600 hover:bg-green-700 text-white"
              >
                <Plus className="w-4 h-4 mr-2" />
                {loading ? 'Criando...' : 'Criar Usuário'}
              </Button>
            </form>
          </CardContent>
        </Card>

        {/* Users List Section */}
        <Card className="bg-card border-border">
          <CardHeader>
            <CardTitle className="text-foreground">Usuários Cadastrados</CardTitle>
            <CardDescription className="text-muted-foreground">
              Total de {users.length} usuário(s)
            </CardDescription>
          </CardHeader>
          <CardContent>
            {users.length === 0 ? (
              <p className="text-muted-foreground text-center py-8">Nenhum usuário cadastrado</p>
            ) : (
              <div className="space-y-2">
                {users.map((user) => (
                  <div key={user.id} className="flex items-center justify-between p-4 bg-background rounded-lg border border-border">
                    <div className="flex-1">
                      <p className="font-medium text-foreground">{user.username}</p>
                      <p className="text-sm text-muted-foreground">
                        Status: <span className={user.status === 'active' ? 'text-green-500' : 'text-red-500'}>
                          {user.status === 'active' ? 'Ativo' : 'Inativo'}
                        </span>
                      </p>
                    </div>
                    <Button
                      variant="destructive"
                      size="sm"
                      onClick={() => handleDeleteUser(user.id)}
                      className="bg-red-600 hover:bg-red-700"
                    >
                      <Trash2 className="w-4 h-4" />
                    </Button>
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>

        {/* Backup Section */}
        <Card className="bg-card border-border">
          <CardHeader>
            <CardTitle className="text-foreground">Backup de Dados</CardTitle>
            <CardDescription className="text-muted-foreground">
              Exporte seus dados de estoque e vendas
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div>
                <h3 className="text-sm font-medium text-foreground mb-3">Estoque</h3>
                <div className="flex gap-2 flex-wrap">
                  <Button
                    onClick={handleDownloadInventoryCSV}
                    disabled={!exportInventoryCSVMutation.data}
                    className="bg-blue-600 hover:bg-blue-700 text-white"
                  >
                    <Download className="w-4 h-4 mr-2" />
                    Estoque (CSV)
                  </Button>
                  <Button
                    onClick={handleDownloadInventoryJSON}
                    disabled={!exportInventoryJSONMutation.data}
                    className="bg-blue-600 hover:bg-blue-700 text-white"
                  >
                    <Download className="w-4 h-4 mr-2" />
                    Estoque (JSON)
                  </Button>
                </div>
              </div>
              <div>
                <h3 className="text-sm font-medium text-foreground mb-3">Vendas</h3>
                <div className="flex gap-2 flex-wrap">
                  <Button
                    onClick={handleDownloadSalesCSV}
                    disabled={!exportSalesCSVMutation.data}
                    className="bg-purple-600 hover:bg-purple-700 text-white"
                  >
                    <Download className="w-4 h-4 mr-2" />
                    Vendas (CSV)
                  </Button>
                  <Button
                    onClick={handleDownloadSalesJSON}
                    disabled={!exportSalesJSONMutation.data}
                    className="bg-purple-600 hover:bg-purple-700 text-white"
                  >
                    <Download className="w-4 h-4 mr-2" />
                    Vendas (JSON)
                  </Button>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Logout Section */}
        <Card className="bg-card border-border">
          <CardHeader>
            <CardTitle className="text-foreground">Sessão</CardTitle>
            <CardDescription className="text-muted-foreground">
              Gerencie sua sessão atual
            </CardDescription>
          </CardHeader>
          <CardContent>
            <Button
              onClick={handleLogout}
              className="bg-red-600 hover:bg-red-700 text-white"
            >
              Sair do Dashboard
            </Button>
          </CardContent>
        </Card>
      </div>
    </DashboardLayout>
  );
}
