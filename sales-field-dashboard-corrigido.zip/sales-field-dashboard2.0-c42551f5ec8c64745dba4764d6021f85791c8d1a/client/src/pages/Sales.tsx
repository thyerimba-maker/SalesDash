import { useState } from 'react';
import { Search } from 'lucide-react';
import { Input } from '@/components/ui/input';
import { toast } from 'sonner';
import { trpc } from '@/lib/trpc';
import DashboardLayout from '@/components/DashboardLayout';

export default function SalesPage() {
  const [searchValue, setSearchValue] = useState('');

  // Fetch sales
  const { data: salesData, isLoading: salesLoading } = trpc.sales.list.useQuery(undefined, {
    refetchInterval: 5000,
  });

  const sales = salesData || [];

  // Filter by search
  const filteredSales = sales.filter(s =>
    s.product?.toLowerCase().includes(searchValue.toLowerCase())
  );

  return (
    <DashboardLayout title="Vendas">
      <div className="space-y-6">
        {/* Header */}
        <div>
          <h1 className="text-3xl font-bold text-foreground">Histórico de Vendas</h1>
          <p className="text-muted-foreground mt-2">Total de vendas: {sales.length}</p>
        </div>

        {/* Search */}
        <div className="relative">
          <Search className="absolute left-3 top-3 text-muted-foreground" size={20} />
          <Input
            placeholder="Buscar por produto..."
            value={searchValue}
            onChange={(e) => setSearchValue(e.target.value)}
            className="pl-10"
          />
        </div>

        {/* Sales List */}
        {salesLoading ? (
          <div className="text-center text-muted-foreground py-8">Carregando...</div>
        ) : filteredSales.length === 0 ? (
          <div className="text-center text-muted-foreground py-8">
            Nenhuma venda encontrada
          </div>
        ) : (
          <div className="grid gap-4">
            {filteredSales.map((sale) => (
              <div key={sale.id} className="bg-card p-4 rounded border border-border">
                <div className="flex justify-between items-start">
                  <div>
                    <h3 className="font-semibold text-foreground">{sale.product}</h3>
                    <p className="text-sm text-muted-foreground">
                      {new Date(sale.createdAt).toLocaleDateString('pt-BR')}
                    </p>
                  </div>
                  <div className="text-right">
                    <p className="text-lg font-bold text-primary">
                      R$ {(sale.amount / 100).toFixed(2)}
                    </p>
                    {sale.paymentMethod && (
                      <p className="text-xs text-muted-foreground">{sale.paymentMethod}</p>
                    )}
                  </div>
                </div>
                {sale.notes && (
                  <p className="text-sm text-muted-foreground mt-2">{sale.notes}</p>
                )}
              </div>
            ))}
          </div>
        )}
      </div>
    </DashboardLayout>
  );
}
