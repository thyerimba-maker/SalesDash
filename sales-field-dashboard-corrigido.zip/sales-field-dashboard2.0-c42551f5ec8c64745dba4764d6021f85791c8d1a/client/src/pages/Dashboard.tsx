'use client';

import { useState, useEffect, useMemo } from 'react';
import { BarChart3, Users, DollarSign, TrendingUp, Plus } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { toast } from 'sonner';
import { trpc } from '@/lib/trpc';
import DashboardLayout from '@/components/DashboardLayout';
import MetricsCard from '@/components/MetricsCard';
import FunnelStage from '@/components/FunnelStage';
import LeadCard from '@/components/LeadCard';
import NewLeadModal, { LeadFormData } from '@/components/NewLeadModal';
import FilterBar from '@/components/FilterBar';
import ReportModal, { ReportConfig } from '@/components/ReportModal';
import AttendanceModal from '@/components/AttendanceModal';
import EditLeadModal from '@/components/EditLeadModal';
import LinkProductModal from '@/components/LinkProductModal';
import { generateSalesReport } from '@/lib/pdfGenerator';

export default function Dashboard() {
  const [modalOpen, setModalOpen] = useState(false);
  const [reportModalOpen, setReportModalOpen] = useState(false);
  const [isGeneratingReport, setIsGeneratingReport] = useState(false);
  const [searchValue, setSearchValue] = useState('');
  const [selectedStatus, setSelectedStatus] = useState('');
  const [attendanceModalOpen, setAttendanceModalOpen] = useState(false);
  const [selectedLeadForAttendance, setSelectedLeadForAttendance] = useState<any>(null);
  const [editModalOpen, setEditModalOpen] = useState(false);
  const [selectedLeadForEdit, setSelectedLeadForEdit] = useState<any>(null);
  const [linkProductModalOpen, setLinkProductModalOpen] = useState(false);
  const [selectedLeadForLinking, setSelectedLeadForLinking] = useState<any>(null);

  // Fetch leads from API with real-time refetch
  const { data: leadsData, isLoading: leadsLoading, refetch: refetchLeads } = trpc.leads.list.useQuery(undefined, {
    refetchInterval: 5000, // Refetch every 5 seconds
  });
  const { data: salesData, refetch: refetchSales } = trpc.sales.list.useQuery(undefined, {
    refetchInterval: 5000, // Refetch every 5 seconds
  });
  
  // Fetch cash register summary for today - use useMemo to stabilize date objects
  const todayRange = useMemo(() => {
    const today = new Date();
    return {
      startDate: new Date(today.getFullYear(), today.getMonth(), today.getDate()),
      endDate: new Date(today.getFullYear(), today.getMonth(), today.getDate() + 1),
    };
  }, []);
  
  const { data: cashSummary } = trpc.cashRegister.getSummary.useQuery(todayRange, {
    refetchInterval: 5000, // Refetch every 5 seconds
  });
  
  // Mutations
  const createLeadMutation = trpc.leads.create.useMutation();
  const updateLeadMutation = trpc.leads.update.useMutation();
  const createSaleMutation = trpc.sales.create.useMutation();
  const closeLeadMutation = trpc.leads.close.useMutation();
  const utils = trpc.useUtils();

  // Note: Auto-refresh is already handled by refetchInterval in useQuery above
  // Removed duplicate setInterval to prevent double-polling

  const leads = leadsData || [];
  const sales = salesData || [];

  // Calculate metrics
  // Use cash register summary for today's sales (includes both lead closures and manual transactions)
  const todaysSales = (cashSummary?.totalVendas || 0) / 100; // Convert from cents to reais

  const newLeadsThisWeek = leads.filter(l => {
    const leadDate = new Date(l.createdAt);
    const weekAgo = new Date();
    weekAgo.setDate(weekAgo.getDate() - 7);
    return leadDate >= weekAgo;
  }).length;

  const completedSales = leads.filter(l => l.status === 'venda_feita').length;
  const conversionRate = leads.length > 0 ? (completedSales / leads.length) * 100 : 0;
  const activeLeads = leads.filter(l => l.status !== 'concluido').length;

  // Funnel data
  const funnelData = [
    { stage: 'Leads', count: leads.filter(l => l.status === 'leads').length },
    { stage: 'Atendimento', count: leads.filter(l => l.status === 'atendimento').length },
    { stage: 'Aguardando', count: leads.filter(l => l.status === 'aguardando').length },
    { stage: 'Confirmado', count: leads.filter(l => l.status === 'confirmado').length },
    { stage: 'Em Rota', count: leads.filter(l => l.status === 'em_rota').length },
    { stage: 'Concluído', count: leads.filter(l => l.status === 'concluido').length },
  ];

  const handleWhatsApp = (phone: string) => {
    const message = encodeURIComponent('Olá! Tudo bem?');
    window.open(`https://wa.me/${phone.replace(/\D/g, '')}?text=${message}`, '_blank');
  };

  const handleCall = (phone: string) => {
    window.open(`tel:${phone}`, '_blank');
  };

  const handleAddLead = async (data: LeadFormData) => {
    try {
      await createLeadMutation.mutateAsync({
        name: data.name,
        phone: data.phone,
        product: data.product,
        source: data.source,
      });
      toast.success(`Lead "${data.name}" adicionado com sucesso!`);
      setModalOpen(false);
    } catch (error) {
      console.error('Error adding lead:', error);
      toast.error('Erro ao adicionar lead');
    }
  };

  const filteredLeads = leads.filter((lead) => {
    // Exclude finalized leads (venda_feita, venda_perdida)
    if (lead.status === 'venda_feita' || lead.status === 'venda_perdida') {
      return false;
    }
    const matchesSearch =
      lead.name.toLowerCase().includes(searchValue.toLowerCase()) ||
      lead.phone.includes(searchValue);
    const matchesStatus = !selectedStatus || lead.status === selectedStatus;
    return matchesSearch && matchesStatus;
  });

  const handleExportReport = async (config: ReportConfig) => {
    setIsGeneratingReport(true);
    try {
      const salesData = {
        metrics: {
          salestoday: Math.round(todaysSales * 100),
          newLeads: newLeadsThisWeek,
          conversionRate: conversionRate,
          activeLeads: activeLeads,
          weeklyTarget: 15000,
          monthlyTarget: 60000,
        },
        funnel: funnelData.map((item) => ({
          stage: item.stage,
          count: item.count,
          percentage: (item.count / leads.length) * 100 || 0,
        })),
        leads: leads,
      };

      await generateSalesReport(salesData, config);
      toast.success('Relatório exportado com sucesso!');
      setReportModalOpen(false);
    } catch (error) {
      console.error('Error generating report:', error);
      toast.error('Erro ao gerar relatório');
    } finally {
      setIsGeneratingReport(false);
    }
  };

  if (leadsLoading) {
    return (
      <DashboardLayout title="Dashboard de Vendas">
        <div className="flex items-center justify-center h-screen">
          <div className="text-center">
            <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary mx-auto mb-4"></div>
            <p className="text-muted-foreground">Carregando dados...</p>
          </div>
        </div>
      </DashboardLayout>
    );
  }

  return (
    <DashboardLayout title="Dashboard de Vendas">
      {/* Hero Section */}
      <div className="mb-8 p-6 bg-gradient-to-r from-primary/20 to-primary/10 rounded-lg border border-primary/20">
        <h1 className="text-3xl font-bold text-foreground mb-2">Bem-vindo, Vendedor!</h1>
        <p className="text-muted-foreground">Acompanhe seu desempenho em tempo real e gerencie seus leads com eficiência.</p>
      </div>

      {/* Metrics Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-8 animate-in fade-in slide-in-from-top-4 duration-500">
        <MetricsCard
          icon={DollarSign}
          label="Vendas Hoje"
          value={`R$ ${todaysSales.toLocaleString('pt-BR', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`}
          trend="up"
          trendValue="+12%"
          subtext="Vendas totais"
        />
        <MetricsCard
          icon={Users}
          label="Novos Leads"
          value={newLeadsThisWeek.toString()}
          trend="up"
          trendValue="+8%"
          subtext="Esta semana"
        />
        <MetricsCard
          icon={TrendingUp}
          label="Taxa de Conversão"
          value={`${conversionRate.toFixed(1)}%`}
          trend="up"
          trendValue="+1.3%"
          subtext="Média: 7.2%"
        />
        <MetricsCard
          icon={BarChart3}
          label="Leads Ativos"
          value={activeLeads.toString()}
          trend="neutral"
          trendValue="0%"
          subtext="Aguardando ação"
        />
      </div>

      {/* Main Content Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-8">
        {/* Funnel Section */}
        <div className="lg:col-span-1 bg-card border border-border rounded-lg p-6">
          <h2 className="text-xl font-bold text-foreground mb-4">Funil de Vendas</h2>
          <p className="text-sm text-muted-foreground mb-4">Total: {leads.length} leads</p>
          <div className="space-y-3">
            {funnelData.map((item) => (
              <FunnelStage
                key={item.stage}
                stage={item.stage}
                count={item.count}
                total={leads.length}
                color="primary"
              />
            ))}
          </div>
        </div>

        {/* Quick Actions */}
        <div className="lg:col-span-2 bg-card border border-border rounded-lg p-6">
          <h2 className="text-xl font-bold text-foreground mb-4">Ações Rápidas</h2>
          
          <div className="space-y-3">
            <Button
              onClick={() => setModalOpen(true)}
              className="w-full h-12 bg-primary hover:bg-primary/90 text-white font-semibold rounded-lg flex items-center justify-center gap-2"
            >
              <Plus className="w-5 h-5" />
              Novo Lead
            </Button>
            
            <Button
              onClick={() => setReportModalOpen(true)}
              variant="outline"
              className="w-full h-12 border-border hover:bg-secondary rounded-lg font-semibold"
            >
              Relatório Diário
            </Button>
            
            <Button variant="outline" className="w-full h-12 border-border hover:bg-secondary rounded-lg font-semibold">
              Configurações
            </Button>
          </div>
        </div>
      </div>

      {/* Leads Section */}
      <div className="mt-8">
        <div className="bg-card border border-border rounded-lg p-6">
          <div className="flex items-center justify-between mb-6">
            <h2 className="text-xl font-bold text-foreground">Leads Prioritários</h2>
            <span className="text-sm text-muted-foreground">{leads.length} leads</span>
          </div>

          <FilterBar
            searchValue={searchValue}
            onSearchChange={setSearchValue}
            selectedStatus={selectedStatus}
            onStatusChange={setSelectedStatus}
          />

          <div className="space-y-2">
            {filteredLeads.length > 0 ? (
              filteredLeads.map((lead) => (
                <LeadCard
                  key={lead.id}
                  id={lead.id.toString()}
                  leadId={lead.id}
                  name={lead.name}
                  phone={lead.phone}
                  status={lead.status}
                  product={lead.product}
                  notes={lead.notes}
                  lastContact={new Date(lead.lastContact || new Date()).toLocaleDateString('pt-BR')}
                  onWhatsApp={() => handleWhatsApp(lead.phone)}
                  onEdit={() => {
                    setSelectedLeadForEdit(lead);
                    setEditModalOpen(true);
                  }}
                  onClose={() => {
                    setSelectedLeadForAttendance(lead);
                    setAttendanceModalOpen(true);
                  }}
                  onNotesUpdate={() => refetchLeads()}
                  onLinkProduct={() => {
                    setSelectedLeadForLinking(lead);
                    setLinkProductModalOpen(true);
                  }}
                />
              ))
            ) : (
              <div className="text-center py-12">
                <Users className="w-12 h-12 text-muted-foreground mx-auto mb-3 opacity-50" />
                <p className="text-muted-foreground">Nenhum lead encontrado</p>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* New Lead Modal */}
      <NewLeadModal
        open={modalOpen}
        onOpenChange={setModalOpen}
        onSubmit={handleAddLead}
      />

      {/* Attendance Modal */}
      {selectedLeadForAttendance && (
        <AttendanceModal
          open={attendanceModalOpen}
          onOpenChange={setAttendanceModalOpen}
          leadName={selectedLeadForAttendance.name}
          onClose={async (data) => {
            try {
              await closeLeadMutation.mutateAsync({
                id: selectedLeadForAttendance.id,
                status: data.status,
                reason: data.reason,
                followUpDate: data.followUpDate,
              });
              await utils.leads.list.invalidate();
              setAttendanceModalOpen(false);
              setSelectedLeadForAttendance(null);
              toast.success(
                data.status === 'venda_feita'
                  ? 'Venda registrada com sucesso!'
                  : 'Lead marcado como venda perdida. Follow-up agendado!'
              );
            } catch (error) {
              toast.error('Erro ao finalizar atendimento');
            }
          }}
          isLoading={closeLeadMutation.isPending}
        />
      )}

      {/* Edit Lead Modal */}
      {selectedLeadForEdit && (
        <EditLeadModal
          open={editModalOpen}
          onOpenChange={setEditModalOpen}
          lead={selectedLeadForEdit}
          onSuccess={() => {
            refetchLeads();
            setSelectedLeadForEdit(null);
          }}
        />
      )}

      {/* Link Product Modal */}
      {selectedLeadForLinking && (
        <LinkProductModal
          isOpen={linkProductModalOpen}
          leadId={selectedLeadForLinking.id}
          onClose={() => {
            setLinkProductModalOpen(false);
            setSelectedLeadForLinking(null);
          }}
          onSuccess={() => {
            refetchLeads();
          }}
        />
      )}

      {/* Report Modal */}
      <ReportModal
        open={reportModalOpen}
        onOpenChange={setReportModalOpen}
        onExport={handleExportReport}
        isLoading={isGeneratingReport}
      />
    </DashboardLayout>
  );
}
