import { useState } from 'react';
import { Plus, Trash2, Edit2, Save, X } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { toast } from 'sonner';
import { trpc } from '@/lib/trpc';
import DashboardLayout from '@/components/DashboardLayout';
import ProductImageUpload from '@/components/ProductImageUpload';
import EditInventoryModal from '@/components/EditInventoryModal';

interface InventoryItem {
  id: number;
  productName: string;
  description?: string;
  sizeP: number;
  sizeM: number;
  sizeG: number;
  sizeGG: number;
  totalQuantity: number;
  unitPrice?: number;
  imageUrl?: string;
}

export default function Inventory() {
  const [isAddingNew, setIsAddingNew] = useState(false);
  const [editingId, setEditingId] = useState<number | null>(null);
  const [searchQuery, setSearchQuery] = useState('');
  const [editingProduct, setEditingProduct] = useState<InventoryItem | null>(null);
  const [statusFilter, setStatusFilter] = useState<'all' | 'active' | 'outofstock'>('all');
  const [newProduct, setNewProduct] = useState({
    productName: '',
    description: '',
    sizeP: 0,
    sizeM: 0,
    sizeG: 0,
    sizeGG: 0,
    unitPrice: 0,
    imageUrl: '',
  });

  const { data: inventory = [], refetch } = trpc.inventory.list.useQuery(undefined, {
    staleTime: 30000,
    gcTime: 5 * 60 * 1000,
  });
  
  const utils = trpc.useUtils();
  
  const filteredInventory = inventory.filter((item: InventoryItem) => {
    const matchesSearch = item.productName.toLowerCase().includes(searchQuery.toLowerCase());
    if (statusFilter === 'all') return matchesSearch;
    if (statusFilter === 'active') return matchesSearch && item.totalQuantity > 0;
    if (statusFilter === 'outofstock') return matchesSearch && item.totalQuantity === 0;
    return matchesSearch;
  });
  const createMutation = trpc.inventory.create.useMutation({
    onSuccess: () => utils.inventory.list.invalidate(),
  });
  const updateMutation = trpc.inventory.update.useMutation({
    onSuccess: () => utils.inventory.list.invalidate(),
  });
  const deleteMutation = trpc.inventory.delete.useMutation({
    onSuccess: () => utils.inventory.list.invalidate(),
  });
  const adjustMutation = trpc.inventory.adjustQuantity.useMutation({
    onSuccess: () => utils.inventory.list.invalidate(),
  });

  const handleEditProduct = (item: InventoryItem) => {
    setEditingProduct(item);
  };

  const handleSaveEdit = async (data: any) => {
    try {
      await updateMutation.mutateAsync(data);
      setEditingProduct(null);
      refetch();
    } catch (error) {
      toast.error('Erro ao atualizar produto');
    }
  };

  const handleAddProduct = async () => {
    if (!newProduct.productName.trim()) {
      toast.error('Nome do produto é obrigatório');
      return;
    }

    try {
      await createMutation.mutateAsync({
        productName: newProduct.productName,
        description: newProduct.description || undefined,
        sizeP: newProduct.sizeP,
        sizeM: newProduct.sizeM,
        sizeG: newProduct.sizeG,
        sizeGG: newProduct.sizeGG,
        unitPrice: newProduct.unitPrice || undefined,
        imageUrl: newProduct.imageUrl || undefined,
      });
      toast.success('Produto adicionado ao estoque!');
      setNewProduct({
        productName: '',
        description: '',
        sizeP: 0,
        sizeM: 0,
        sizeG: 0,
        sizeGG: 0,
        unitPrice: 0,
        imageUrl: '',
      });
      setIsAddingNew(false);
      refetch();
    } catch (error) {
      toast.error('Erro ao adicionar produto');
    }
  };

  const handleAdjustQuantity = async (itemId: number, size: 'P' | 'M' | 'G' | 'GG', delta: number) => {
    try {
      await adjustMutation.mutateAsync({
        id: itemId,
        size,
        quantity: delta,
      });
      refetch();
    } catch (error) {
      toast.error('Erro ao ajustar quantidade');
    }
  };

  const handleDeleteProduct = async (itemId: number) => {
    if (!confirm('Tem certeza que deseja remover este produto?')) return;

    try {
      await deleteMutation.mutateAsync({ id: itemId });
      toast.success('Produto removido!');
      refetch();
    } catch (error) {
      toast.error('Erro ao remover produto');
    }
  };

  const formatPrice = (price?: number) => {
    if (!price) return 'N/A';
    return `R$ ${(price / 100).toFixed(2)}`;
  };

  return (
    <DashboardLayout title="Gestão de Estoque">
      <div className="space-y-6">
        {/* Header */}
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-3xl font-bold text-foreground">Estoque</h1>
              <p className="text-sm text-muted-foreground mt-1">
                Total de peças: <span className="font-semibold text-primary">{inventory.reduce((sum, item) => sum + (item.totalQuantity || 0), 0)}</span>
              </p>
            </div>
            <Button
              onClick={() => setIsAddingNew(!isAddingNew)}
              className="bg-primary hover:bg-primary/90 text-white"
            >
              <Plus className="w-4 h-4 mr-2" />
              Novo Produto
            </Button>
          </div>

          {/* Filter Buttons */}
          <div className="flex gap-2 flex-wrap">
            <Button
              onClick={() => setStatusFilter('all')}
              variant={statusFilter === 'all' ? 'default' : 'outline'}
              className={statusFilter === 'all' ? 'bg-primary text-white' : 'bg-background border-border text-foreground hover:bg-card'}
            >
              Todos
            </Button>
            <Button
              onClick={() => setStatusFilter('active')}
              variant={statusFilter === 'active' ? 'default' : 'outline'}
              className={statusFilter === 'active' ? 'bg-green-600 text-white' : 'bg-background border-border text-foreground hover:bg-card'}
            >
              Ativos
            </Button>
            <Button
              onClick={() => setStatusFilter('outofstock')}
              variant={statusFilter === 'outofstock' ? 'default' : 'outline'}
              className={statusFilter === 'outofstock' ? 'bg-red-600 text-white' : 'bg-background border-border text-foreground hover:bg-card'}
            >
              Sem estoque
            </Button>
          </div>
        </div>

        {/* Search Bar */}
        <div className="bg-card border border-border rounded-lg p-4">
          <Input
            type="text"
            placeholder="Pesquisar produtos por nome..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full"
          />
        </div>

        {/* Add New Product Form */}
        {isAddingNew && (
          <div className="bg-card border border-border rounded-lg p-6 space-y-4">
            <h2 className="text-xl font-semibold text-foreground">Adicionar Novo Produto</h2>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="text-sm font-medium text-foreground mb-2 block">Nome do Produto *</label>
                <Input
                  value={newProduct.productName}
                  onChange={(e) => setNewProduct({ ...newProduct, productName: e.target.value })}
                  placeholder="Ex: Camiseta Básica"
                />
              </div>
              <div>
                <label className="text-sm font-medium text-foreground mb-2 block">Preço Unitário (R$)</label>
                <Input
                  type="number"
                  value={newProduct.unitPrice}
                  onChange={(e) => setNewProduct({ ...newProduct, unitPrice: parseFloat(e.target.value) || 0 })}
                  placeholder="0.00"
                  step="0.01"
                />
              </div>
            </div>

            <div>
              <label className="text-sm font-medium text-foreground mb-2 block">Foto do Produto</label>
              <ProductImageUpload
                productId={0}
                currentImageUrl={newProduct.imageUrl}
                onImageUpload={(url) => setNewProduct({ ...newProduct, imageUrl: url })}
              />
            </div>

            <div>
              <label className="text-sm font-medium text-foreground mb-2 block">Descrição</label>
              <Input
                value={newProduct.description}
                onChange={(e) => setNewProduct({ ...newProduct, description: e.target.value })}
                placeholder="Descrição do produto"
              />
            </div>

            <div className="grid grid-cols-4 gap-4">
              {(['P', 'M', 'G', 'GG'] as const).map((size) => (
                <div key={size}>
                  <label className="text-sm font-medium text-foreground mb-2 block">Tamanho {size}</label>
                  <Input
                    type="number"
                    value={newProduct[`size${size}`]}
                    onChange={(e) => setNewProduct({ ...newProduct, [`size${size}`]: parseInt(e.target.value) || 0 })}
                    min="0"
                  />
                </div>
              ))}
            </div>

            <div className="flex gap-2 justify-end">
              <Button
                variant="outline"
                onClick={() => setIsAddingNew(false)}
              >
                Cancelar
              </Button>
              <Button
                onClick={handleAddProduct}
                disabled={createMutation.isPending}
                className="bg-primary hover:bg-primary/90 text-white"
              >
                {createMutation.isPending ? 'Adicionando...' : 'Adicionar'}
              </Button>
            </div>
          </div>
        )}

        {/* Inventory Cards Grid */}
        <div>
          {inventory.length === 0 ? (
            <div className="bg-card border border-border rounded-lg p-12 text-center">
              <p className="text-muted-foreground">Nenhum produto no estoque. Adicione um novo produto para começar.</p>
            </div>
          ) : (
            <div className="grid grid-cols-2 md:grid-cols-2 lg:grid-cols-3 gap-4 md:gap-6">
              {filteredInventory.map((item: InventoryItem) => (
                <div key={item.id} className="bg-card border border-border rounded-lg overflow-hidden hover:shadow-lg transition-shadow relative">
                  {/* Floating Edit Button */}
                  <button
                    onClick={() => handleEditProduct(item)}
                    className="absolute top-2 right-2 z-10 p-1.5 bg-blue-600 hover:bg-blue-700 text-white rounded-full shadow-md transition-colors"
                    title="Editar produto"
                  >
                    <Edit2 className="w-4 h-4" />
                  </button>
                  {/* Product Image */}
                  <div className="relative w-full h-40 bg-secondary">
                    {item.imageUrl ? (
                      <img
                        src={item.imageUrl}
                        alt={item.productName}
                        className="w-full h-full object-cover"
                      />
                    ) : (
                      <div className="w-full h-full flex items-center justify-center">
                        <p className="text-muted-foreground">Sem imagem</p>
                      </div>
                    )}
                  </div>

                  {/* Product Info */}
                  <div className="p-2 space-y-1.5">
                    <div>
                      <h3 className="font-semibold text-foreground text-sm">{item.productName}</h3>
                      {item.description && (
                        <p className="text-xs text-muted-foreground mt-0.5 line-clamp-1">{item.description}</p>
                      )}
                    </div>

                    {/* Price */}
                    {item.unitPrice && (
                      <div className="text-sm font-bold text-primary">
                        {formatPrice(item.unitPrice)}
                      </div>
                    )}

                    {/* Sizes */}
                    <div className="grid grid-cols-4 gap-1">
                      {(['P', 'M', 'G', 'GG'] as const).map((size) => {
                        const quantity = item[`size${size}`];
                        return (
                          <div key={size} className="bg-secondary rounded p-1 text-center">
                            <p className="text-xs text-muted-foreground font-medium">{size}</p>
                            <p className="text-xs font-bold text-foreground">{quantity}</p>
                          </div>
                        );
                      })}
                    </div>

                    {/* Total Quantity */}
                    <div className="flex items-center justify-between bg-secondary rounded p-1.5">
                      <span className="text-xs font-medium text-muted-foreground">Total</span>
                      <span className="text-sm font-bold text-primary">{item.totalQuantity}</span>
                    </div>


                  </div>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Summary */}
        {inventory.length > 0 && (
          <div className="bg-card border border-border rounded-lg p-6">
            <h3 className="text-lg font-semibold text-foreground mb-4">Resumo do Estoque</h3>
            <div className="grid grid-cols-2 md:grid-cols-5 gap-4">
              <div className="bg-secondary rounded p-4">
                <p className="text-sm text-muted-foreground mb-1">Total de Produtos</p>
                <p className="text-2xl font-bold text-primary">{inventory.length}</p>
              </div>
              {(['P', 'M', 'G', 'GG'] as const).map((size) => {
                const total = inventory.reduce((sum, item: InventoryItem) => sum + item[`size${size}`], 0);
                return (
                  <div key={size} className="bg-secondary rounded p-4">
                    <p className="text-sm text-muted-foreground mb-1">Tamanho {size}</p>
                    <p className="text-2xl font-bold text-primary">{total}</p>
                  </div>
                );
              })}
            </div>
          </div>
        )}
      </div>

      {/* Edit Modal */}
      {editingProduct && (
        <EditInventoryModal
          product={editingProduct}
          isOpen={!!editingProduct}
          onClose={() => setEditingProduct(null)}
          onSave={handleSaveEdit}
          onDelete={handleDeleteProduct}
          isSaving={updateMutation.isPending}
        />
      )}
    </DashboardLayout>
  );
}
