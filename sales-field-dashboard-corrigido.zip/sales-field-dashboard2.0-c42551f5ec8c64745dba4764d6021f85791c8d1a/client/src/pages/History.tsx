import { useState, useMemo } from 'react';
import { useLocation } from 'wouter';
import { trpc } from '@/lib/trpc';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Search, CheckCircle2, XCircle, Calendar, Loader2, ArrowLeft } from 'lucide-react';
import { formatDistanceToNow } from 'date-fns';
import { ptBR } from 'date-fns/locale';

export default function History() {
  const [location, setLocation] = useLocation();
  const [searchTerm, setSearchTerm] = useState('');
  const [activeTab, setActiveTab] = useState<'closed' | 'followup'>('closed');

  const { data: closedLeads, isLoading: closedLoading } = trpc.leads.getClosed.useQuery();
  const { data: followUpLeads, isLoading: followUpLoading } = trpc.leads.getFollowUp.useQuery();

  const filteredClosed = useMemo(() => {
    if (!closedLeads) return [];
    return closedLeads.filter(lead =>
      lead.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      lead.phone.includes(searchTerm)
    );
  }, [closedLeads, searchTerm]);

  const filteredFollowUp = useMemo(() => {
    if (!followUpLeads) return [];
    return followUpLeads.filter(lead =>
      lead.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      lead.phone.includes(searchTerm)
    );
  }, [followUpLeads, searchTerm]);

  const vendidosCount = closedLeads?.filter(l => l.status === 'venda_feita').length || 0;
  const perdidosCount = closedLeads?.filter(l => l.status === 'venda_perdida').length || 0;
  const followUpCount = followUpLeads?.length || 0;

  return (
    <div className="space-y-6">
      {/* Back Button */}
      <Button
        variant="ghost"
        onClick={() => setLocation('/')}
        className="flex items-center gap-2 text-muted-foreground hover:text-foreground"
      >
        <ArrowLeft className="w-4 h-4" />
        Voltar ao Dashboard
      </Button>

      {/* Header */}
      <div className="bg-gradient-to-r from-primary/10 to-primary/5 border border-primary/20 rounded-lg p-6">
        <h1 className="text-3xl font-bold text-foreground mb-2">Histórico de Atendimentos</h1>
        <p className="text-muted-foreground">
          Acompanhe todas as vendas finalizadas e leads em espera de follow-up
        </p>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <Card className="p-4 bg-card border border-border">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-muted-foreground">Vendas Feitas</p>
              <p className="text-2xl font-bold text-foreground">{vendidosCount}</p>
            </div>
            <CheckCircle2 className="w-8 h-8 text-green-500" />
          </div>
        </Card>

        <Card className="p-4 bg-card border border-border">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-muted-foreground">Vendas Perdidas</p>
              <p className="text-2xl font-bold text-foreground">{perdidosCount}</p>
            </div>
            <XCircle className="w-8 h-8 text-red-500" />
          </div>
        </Card>

        <Card className="p-4 bg-card border border-border">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-muted-foreground">Follow-ups Pendentes</p>
              <p className="text-2xl font-bold text-foreground">{followUpCount}</p>
            </div>
            <Calendar className="w-8 h-8 text-primary" />
          </div>
        </Card>
      </div>

      {/* Search */}
      <div className="relative">
        <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-muted-foreground" />
        <Input
          placeholder="Buscar por nome ou telefone..."
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
          className="pl-10 h-10"
        />
      </div>

      {/* Tabs */}
      <Tabs value={activeTab} onValueChange={(v) => setActiveTab(v as any)} className="w-full">
        <TabsList className="grid w-full grid-cols-2">
          <TabsTrigger value="closed">Vendas Finalizadas ({closedLeads?.length || 0})</TabsTrigger>
          <TabsTrigger value="followup">Follow-ups ({followUpCount})</TabsTrigger>
        </TabsList>

        {/* Closed Leads Tab */}
        <TabsContent value="closed" className="space-y-4 mt-4">
          {closedLoading ? (
            <div className="flex items-center justify-center py-8">
              <Loader2 className="w-6 h-6 animate-spin text-primary" />
            </div>
          ) : filteredClosed.length === 0 ? (
            <Card className="p-8 text-center bg-card border border-border">
              <p className="text-muted-foreground">Nenhum lead finalizado encontrado</p>
            </Card>
          ) : (
            filteredClosed.map((lead) => (
              <Card key={lead.id} className="p-4 bg-card border border-border hover:shadow-md transition-shadow">
                <div className="flex items-start justify-between mb-3">
                  <div className="flex-1">
                    <div className="flex items-center gap-2 mb-1">
                      <h3 className="font-semibold text-foreground text-lg">{lead.name}</h3>
                      <div
                        className={`flex items-center gap-1 px-2 py-1 rounded-full text-xs font-semibold text-white ${
                          lead.status === 'venda_feita' ? 'bg-green-500' : 'bg-red-500'
                        }`}
                      >
                        {lead.status === 'venda_feita' ? (
                          <>
                            <CheckCircle2 className="w-3 h-3" />
                            Venda Feita
                          </>
                        ) : (
                          <>
                            <XCircle className="w-3 h-3" />
                            Venda Perdida
                          </>
                        )}
                      </div>
                    </div>
                    <p className="text-sm text-muted-foreground">{lead.phone}</p>
                  </div>
                </div>

                <div className="space-y-2 text-sm">
                  <p>
                    <span className="font-medium text-foreground">Produto:</span> {lead.product}
                  </p>
                  {lead.closureReason && (
                    <p>
                      <span className="font-medium text-foreground">Motivo:</span> {lead.closureReason}
                    </p>
                  )}
                  {lead.closureDate && (
                    <p className="text-xs text-muted-foreground">
                      Finalizado {formatDistanceToNow(new Date(lead.closureDate), { locale: ptBR, addSuffix: true })}
                    </p>
                  )}
                </div>
              </Card>
            ))
          )}
        </TabsContent>

        {/* Follow-up Tab */}
        <TabsContent value="followup" className="space-y-4 mt-4">
          {followUpLoading ? (
            <div className="flex items-center justify-center py-8">
              <Loader2 className="w-6 h-6 animate-spin text-primary" />
            </div>
          ) : filteredFollowUp.length === 0 ? (
            <Card className="p-8 text-center bg-card border border-border">
              <p className="text-muted-foreground">Nenhum follow-up pendente</p>
            </Card>
          ) : (
            filteredFollowUp.map((lead) => (
              <Card key={lead.id} className="p-4 bg-card border border-border hover:shadow-md transition-shadow border-l-4 border-l-primary">
                <div className="flex items-start justify-between mb-3">
                  <div className="flex-1">
                    <h3 className="font-semibold text-foreground text-lg">{lead.name}</h3>
                    <p className="text-sm text-muted-foreground">{lead.phone}</p>
                  </div>
                  <div className="flex items-center gap-2 px-3 py-1 rounded-full bg-primary/10 text-primary text-xs font-semibold">
                    <Calendar className="w-3 h-3" />
                    Agendado
                  </div>
                </div>

                <div className="space-y-2 text-sm">
                  <p>
                    <span className="font-medium text-foreground">Produto:</span> {lead.product}
                  </p>
                  {lead.closureReason && (
                    <p>
                      <span className="font-medium text-foreground">Motivo:</span> {lead.closureReason}
                    </p>
                  )}
                  {lead.followUpDate && (
                    <p className="text-xs text-muted-foreground">
                      Follow-up agendado para {new Date(lead.followUpDate).toLocaleDateString('pt-BR', {
                        day: '2-digit',
                        month: '2-digit',
                        year: 'numeric',
                        hour: '2-digit',
                        minute: '2-digit',
                      })}
                    </p>
                  )}
                </div>

                <Button className="mt-3 w-full bg-primary hover:bg-primary/90 text-white font-semibold">
                  Fazer Follow-up Agora
                </Button>
              </Card>
            ))
          )}
        </TabsContent>
      </Tabs>
    </div>
  );
}
