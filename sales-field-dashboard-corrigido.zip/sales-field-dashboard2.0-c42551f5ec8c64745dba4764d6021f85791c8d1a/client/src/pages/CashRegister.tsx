import { useState } from 'react';
import { Plus, Trash2, Edit2, Save, X } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { toast } from 'sonner';
import { trpc } from '@/lib/trpc';
import DashboardLayout from '@/components/DashboardLayout';

interface CashTransaction {
  id: number;
  type: 'venda' | 'despesa' | 'devolucao' | 'ajuste';
  description: string;
  amount: number;
  paymentMethod?: string;
  notes?: string;
  createdAt: Date;
}

const typeConfig = {
  venda: { label: 'Venda', color: 'bg-green-500/10 text-green-600' },
  despesa: { label: 'Despesa', color: 'bg-red-500/10 text-red-600' },
  devolucao: { label: 'Devolução', color: 'bg-yellow-500/10 text-yellow-600' },
  ajuste: { label: 'Ajuste', color: 'bg-blue-500/10 text-blue-600' },
};

export default function CashRegister() {
  const [isAddingNew, setIsAddingNew] = useState(false);
  const [editingId, setEditingId] = useState<number | null>(null);
  const [newTransaction, setNewTransaction] = useState({
    type: 'venda' as const,
    description: '',
    amount: 0,
    paymentMethod: '',
    notes: '',
  });
  const [dateRange, setDateRange] = useState({
    startDate: new Date(new Date().setDate(new Date().getDate() - 30)).toISOString().split('T')[0],
    endDate: new Date().toISOString().split('T')[0],
  });

  const { data: transactions = [], refetch } = trpc.cashRegister.list.useQuery(undefined, {
    staleTime: 30000,
    gcTime: 5 * 60 * 1000,
  });
  const { data: summary } = trpc.cashRegister.getSummary.useQuery({
    startDate: new Date(dateRange.startDate),
    endDate: new Date(dateRange.endDate),
  }, {
    staleTime: 30000,
    gcTime: 5 * 60 * 1000,
  });

  const createMutation = trpc.cashRegister.create.useMutation();
  const updateMutation = trpc.cashRegister.update.useMutation({
    onSuccess: () => {
      toast.success('Transação atualizada!');
      setEditingId(null);
      setNewTransaction({
        type: 'venda',
        description: '',
        amount: 0,
        paymentMethod: '',
        notes: '',
      });
      refetch();
    },
    onError: () => {
      toast.error('Erro ao atualizar transação');
    },
  });
  const deleteMutation = trpc.cashRegister.delete.useMutation({
    onSuccess: () => {
      trpc.useUtils().cashRegister.list.invalidate();
      trpc.useUtils().cashRegister.getSummary.invalidate();
    },
  });

  const handleAddTransaction = async () => {
    if (!newTransaction.description.trim()) {
      toast.error('Descrição é obrigatória');
      return;
    }

    if (newTransaction.amount <= 0) {
      toast.error('Valor deve ser maior que zero');
      return;
    }

    try {
      if (editingId) {
        await updateMutation.mutateAsync({
          id: editingId,
          type: newTransaction.type,
          description: newTransaction.description,
          amount: Math.round(newTransaction.amount * 100),
          paymentMethod: newTransaction.paymentMethod || undefined,
          notes: newTransaction.notes || undefined,
        });
      } else {
        await createMutation.mutateAsync({
          type: newTransaction.type,
          description: newTransaction.description,
          amount: Math.round(newTransaction.amount * 100),
          paymentMethod: newTransaction.paymentMethod || undefined,
          notes: newTransaction.notes || undefined,
        });
        toast.success('Transação registrada!');
      }
      setNewTransaction({
        type: 'venda',
        description: '',
        amount: 0,
        paymentMethod: '',
        notes: '',
      });
      setEditingId(null);
      setIsAddingNew(false);
      refetch();
    } catch (error) {
      toast.error(editingId ? 'Erro ao atualizar transação' : 'Erro ao registrar transação');
    }
  };

  const handleEditTransaction = (transaction: CashTransaction) => {
    setEditingId(transaction.id);
    setNewTransaction({
      type: transaction.type,
      description: transaction.description,
      amount: transaction.amount / 100,
      paymentMethod: transaction.paymentMethod || '',
      notes: transaction.notes || '',
    });
    setIsAddingNew(true);
  };

  const handleDeleteTransaction = async (transactionId: number) => {
    if (!confirm('Tem certeza que deseja remover esta transação?')) return;

    try {
      await deleteMutation.mutateAsync({ id: transactionId });
      toast.success('Transação removida!');
      refetch();
    } catch (error) {
      toast.error('Erro ao remover transação');
    }
  };

  const formatCurrency = (cents: number) => {
    return `R$ ${(cents / 100).toFixed(2).replace('.', ',')}`;
  };

  const filteredTransactions = transactions.filter(t => {
    const transDate = new Date(t.createdAt).toISOString().split('T')[0];
    return transDate >= dateRange.startDate && transDate <= dateRange.endDate;
  });

  return (
    <DashboardLayout title="Caixa">
      <div className="space-y-6">
        {/* Header */}
        <div className="flex items-center justify-between">
          <h1 className="text-3xl font-bold text-foreground">Caixa</h1>
          <Button
            onClick={() => setIsAddingNew(!isAddingNew)}
            className="bg-primary hover:bg-primary/90 text-white"
          >
            <Plus className="w-4 h-4 mr-2" />
            Nova Transação
          </Button>
        </div>

        {/* Summary Cards */}
        {summary && (
          <div className="grid grid-cols-1 md:grid-cols-5 gap-4">
            <div className="bg-card border border-border rounded-lg p-4">
              <p className="text-sm text-muted-foreground mb-1">Total Vendas</p>
              <p className="text-2xl font-bold text-green-600">{formatCurrency(summary.totalVendas)}</p>
            </div>
            <div className="bg-card border border-border rounded-lg p-4">
              <p className="text-sm text-muted-foreground mb-1">Total Despesas</p>
              <p className="text-2xl font-bold text-red-600">{formatCurrency(summary.totalDespesas)}</p>
            </div>
            <div className="bg-card border border-border rounded-lg p-4">
              <p className="text-sm text-muted-foreground mb-1">Devoluções</p>
              <p className="text-2xl font-bold text-yellow-600">{formatCurrency(summary.totalDevolucoes)}</p>
            </div>
            <div className="bg-card border border-border rounded-lg p-4">
              <p className="text-sm text-muted-foreground mb-1">Ajustes</p>
              <p className="text-2xl font-bold text-blue-600">{formatCurrency(summary.totalAjustes)}</p>
            </div>
            <div className="bg-card border border-border rounded-lg p-4 border-primary">
              <p className="text-sm text-muted-foreground mb-1">Saldo Final</p>
              <p className={`text-2xl font-bold ${summary.saldoFinal >= 0 ? 'text-green-600' : 'text-red-600'}`}>
                {formatCurrency(summary.saldoFinal)}
              </p>
            </div>
          </div>
        )}

        {/* Add/Edit Transaction Form */}
        {isAddingNew && (
          <div className="bg-card border border-border rounded-lg p-6 space-y-4">
            <h2 className="text-xl font-semibold text-foreground">{editingId ? 'Editar Transação' : 'Registrar Transação'}</h2>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="text-sm font-medium text-foreground mb-2 block">Tipo de Transação</label>
                <select
                  value={newTransaction.type}
                  onChange={(e) => setNewTransaction({ ...newTransaction, type: e.target.value as any })}
                  className="w-full px-3 py-2 bg-secondary border border-border rounded-md text-foreground"
                >
                  <option value="venda">Venda</option>
                  <option value="despesa">Despesa</option>
                  <option value="devolucao">Devolução</option>
                  <option value="ajuste">Ajuste</option>
                </select>
              </div>
              <div>
                <label className="text-sm font-medium text-foreground mb-2 block">Valor (R$) *</label>
                <Input
                  type="number"
                  value={newTransaction.amount}
                  onChange={(e) => setNewTransaction({ ...newTransaction, amount: parseFloat(e.target.value) || 0 })}
                  placeholder="0.00"
                  step="0.01"
                />
              </div>
            </div>

            <div>
              <label className="text-sm font-medium text-foreground mb-2 block">Descrição *</label>
              <Input
                value={newTransaction.description}
                onChange={(e) => setNewTransaction({ ...newTransaction, description: e.target.value })}
                placeholder="Ex: Venda de camiseta para João"
              />
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="text-sm font-medium text-foreground mb-2 block">Forma de Pagamento</label>
                <Input
                  value={newTransaction.paymentMethod}
                  onChange={(e) => setNewTransaction({ ...newTransaction, paymentMethod: e.target.value })}
                  placeholder="Ex: Dinheiro, Cartão, PIX"
                />
              </div>
              <div>
                <label className="text-sm font-medium text-foreground mb-2 block">Observações</label>
                <Input
                  value={newTransaction.notes}
                  onChange={(e) => setNewTransaction({ ...newTransaction, notes: e.target.value })}
                  placeholder="Notas adicionais"
                />
              </div>
            </div>

            <div className="flex gap-2 justify-end">
              <Button
                variant="outline"
                onClick={() => setIsAddingNew(false)}
              >
                Cancelar
              </Button>
              <Button
                onClick={handleAddTransaction}
                disabled={createMutation.isPending || updateMutation.isPending}
                className="bg-primary hover:bg-primary/90 text-white"
              >
                {editingId ? (updateMutation.isPending ? 'Atualizando...' : 'Atualizar') : (createMutation.isPending ? 'Registrando...' : 'Registrar')}
              </Button>
            </div>
          </div>
        )}

        {/* Date Range Filter */}
        <div className="bg-card border border-border rounded-lg p-4 flex gap-4 items-end">
          <div>
            <label className="text-sm font-medium text-foreground mb-2 block">Data Inicial</label>
            <Input
              type="date"
              value={dateRange.startDate}
              onChange={(e) => setDateRange({ ...dateRange, startDate: e.target.value })}
            />
          </div>
          <div>
            <label className="text-sm font-medium text-foreground mb-2 block">Data Final</label>
            <Input
              type="date"
              value={dateRange.endDate}
              onChange={(e) => setDateRange({ ...dateRange, endDate: e.target.value })}
            />
          </div>
        </div>

        {/* Transactions Table */}
        <div className="bg-card border border-border rounded-lg overflow-hidden">
          {filteredTransactions.length === 0 ? (
            <div className="p-12 text-center">
              <p className="text-muted-foreground">Nenhuma transação neste período.</p>
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead className="bg-secondary border-b border-border">
                  <tr>
                    <th className="px-6 py-3 text-left text-sm font-semibold text-foreground">Data</th>
                    <th className="px-6 py-3 text-left text-sm font-semibold text-foreground">Tipo</th>
                    <th className="px-6 py-3 text-left text-sm font-semibold text-foreground">Descrição</th>
                    <th className="px-6 py-3 text-left text-sm font-semibold text-foreground">Forma de Pagamento</th>
                    <th className="px-6 py-3 text-right text-sm font-semibold text-foreground">Valor</th>
                    <th className="px-6 py-3 text-right text-sm font-semibold text-foreground">Ações</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-border">
                  {filteredTransactions.map((transaction: CashTransaction) => {
                    const config = typeConfig[transaction.type];
                    return (
                      <tr key={transaction.id} className="hover:bg-secondary/50 transition-colors">
                        <td className="px-6 py-4">
                          <span className="text-sm text-foreground">
                            {new Date(transaction.createdAt).toLocaleDateString('pt-BR')}
                          </span>
                        </td>
                        <td className="px-6 py-4">
                          <span className={`px-3 py-1 rounded-full text-xs font-semibold ${config.color}`}>
                            {config.label}
                          </span>
                        </td>
                        <td className="px-6 py-4">
                          <div>
                            <p className="font-medium text-foreground">{transaction.description}</p>
                            {transaction.notes && (
                              <p className="text-xs text-muted-foreground mt-1">{transaction.notes}</p>
                            )}
                          </div>
                        </td>
                        <td className="px-6 py-4">
                          <span className="text-sm text-foreground">{transaction.paymentMethod || '—'}</span>
                        </td>
                        <td className="px-6 py-4 text-right">
                          <span className={`font-bold ${transaction.type === 'venda' || transaction.type === 'ajuste' ? 'text-green-600' : 'text-red-600'}`}>
                            {transaction.type === 'venda' || transaction.type === 'ajuste' ? '+' : '−'}
                            {formatCurrency(transaction.amount)}
                          </span>
                        </td>
                        <td className="px-6 py-4 text-right space-x-2 flex justify-end">
                          <button
                            onClick={() => handleEditTransaction(transaction)}
                            className="inline-flex items-center justify-center p-2 hover:bg-blue-500/10 rounded text-blue-600 hover:text-blue-700"
                          >
                            <Edit2 className="w-4 h-4" />
                          </button>
                          <button
                            onClick={() => handleDeleteTransaction(transaction.id)}
                            className="inline-flex items-center justify-center p-2 hover:bg-red-500/10 rounded text-red-600 hover:text-red-700"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          )}
        </div>
      </div>
    </DashboardLayout>
  );
}
