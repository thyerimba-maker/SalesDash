import { useState, useEffect } from "react";
import { useLocation } from "wouter";
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { toast } from "sonner";
import { Plus, Search, ArrowLeft } from "lucide-react";
import OrderCard from "@/components/OrderCard";
import OrderModal from "@/components/OrderModal";

export default function Orders() {
  const [searchTerm, setSearchTerm] = useState("");
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [activeTab, setActiveTab] = useState("leads");
  const [editingOrder, setEditingOrder] = useState<any>(null);

  // Queries with caching
  const activeOrders = trpc.orders.listActive.useQuery(undefined, {
    staleTime: 30000,
    gcTime: 5 * 60 * 1000,
  });
  const completedOrders = trpc.orders.listCompleted.useQuery(undefined, {
    staleTime: 30000,
    gcTime: 5 * 60 * 1000,
  });
  const stats = trpc.orders.getStats.useQuery(undefined, {
    staleTime: 30000,
    gcTime: 5 * 60 * 1000,
  });
  const leadsWithProducts = trpc.leads.listWithProducts.useQuery(undefined, {
    staleTime: 30000,
    gcTime: 5 * 60 * 1000,
  });

  // Mutations with automatic invalidation
  const createOrderMutation = trpc.orders.create.useMutation({
    onSuccess: () => {
      toast.success("Pedido criado com sucesso!");
      setIsModalOpen(false);
      trpc.useUtils().orders.listActive.invalidate();
      trpc.useUtils().orders.getStats.invalidate();
    },
    onError: (error) => {
      toast.error(`Erro: ${error.message}`);
    },
  });

  const updateOrderMutation = trpc.orders.update.useMutation({
    onSuccess: () => {
      toast.success("Pedido atualizado com sucesso!");
      setIsModalOpen(false);
      setEditingOrder(null);
      trpc.useUtils().orders.listActive.invalidate();
      trpc.useUtils().orders.listCompleted.invalidate();
      trpc.useUtils().orders.getStats.invalidate();
    },
    onError: (error) => {
      toast.error(`Erro: ${error.message}`);
    },
  });

  const updateStatusMutation = trpc.orders.updateStatus.useMutation({
    onSuccess: () => {
      toast.success("Status atualizado!");
      trpc.useUtils().orders.listActive.invalidate();
      trpc.useUtils().orders.listCompleted.invalidate();
      trpc.useUtils().orders.getStats.invalidate();
    },
    onError: (error) => {
      toast.error(`Erro: ${error.message}`);
    },
  });

  const cancelOrderMutation = trpc.orders.cancel.useMutation({
    onSuccess: () => {
      toast.success("Pedido cancelado!");
      trpc.useUtils().orders.listActive.invalidate();
      trpc.useUtils().orders.listCompleted.invalidate();
      trpc.useUtils().orders.getStats.invalidate();
    },
    onError: (error) => {
      toast.error(`Erro: ${error.message}`);
    },
  });

  const handleCreateOrder = (data: any) => {
    createOrderMutation.mutate(data);
  };

  const handleUpdateOrder = (data: any) => {
    updateOrderMutation.mutate({
      id: editingOrder.id,
      ...data,
    });
  };

  const handleStatusChange = (orderId: number, status: string) => {
    updateStatusMutation.mutate({ id: orderId, status: status as any });
  };

  const handleDeleteOrder = (orderId: number) => {
    if (confirm("Tem certeza que deseja cancelar este pedido?")) {
      cancelOrderMutation.mutate({ id: orderId });
    }
  };

  const handleEditOrder = (order: any) => {
    setEditingOrder(order);
    setIsModalOpen(true);
  };

  const filteredActive =
    activeOrders.data?.filter(
      (order) =>
        order.customerName.toLowerCase().includes(searchTerm.toLowerCase()) ||
        order.orderNumber.toLowerCase().includes(searchTerm.toLowerCase())
    ) || [];

  const filteredCompleted =
    completedOrders.data?.filter(
      (order) =>
        order.customerName.toLowerCase().includes(searchTerm.toLowerCase()) ||
        order.orderNumber.toLowerCase().includes(searchTerm.toLowerCase())
    ) || [];

  const [, navigate] = useLocation();

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex justify-between items-center">
        <div className="flex items-center gap-3">
          <Button
            variant="outline"
            size="sm"
            onClick={() => navigate('/')}
            className="gap-2"
          >
            <ArrowLeft className="w-4 h-4" />
            Voltar
          </Button>
          <h1 className="text-3xl font-bold text-white">Gestão de Pedidos</h1>
        </div>
        <Button
          onClick={() => {
            setEditingOrder(null);
            setIsModalOpen(true);
          }}
          className="bg-green-600 hover:bg-green-700 gap-2"
        >
          <Plus size={20} /> Novo Pedido
        </Button>
      </div>

      {/* Stats */}
      {stats.data && (
        <div className="grid grid-cols-5 gap-4">
          <div className="bg-gray-900 p-4 rounded border border-gray-700">
            <p className="text-gray-400 text-sm">Total de Pedidos</p>
            <p className="text-2xl font-bold text-white">
              {(stats.data.totalOrders || 0) + (leadsWithProducts.data?.length || 0)}
            </p>
          </div>
          <div className="bg-gray-900 p-4 rounded border border-gray-700">
            <p className="text-gray-400 text-sm">Leads com Produtos</p>
            <p className="text-2xl font-bold text-blue-400">
              {leadsWithProducts.data?.length || 0}
            </p>
          </div>
          <div className="bg-gray-900 p-4 rounded border border-gray-700">
            <p className="text-gray-400 text-sm">Pedidos Ativos</p>
            <p className="text-2xl font-bold text-yellow-400">
              {stats.data.activeOrders}
            </p>
          </div>
          <div className="bg-gray-900 p-4 rounded border border-gray-700">
            <p className="text-gray-400 text-sm">Finalizados</p>
            <p className="text-2xl font-bold text-green-400">
              {stats.data.completedOrders}
            </p>
          </div>
          <div className="bg-gray-900 p-4 rounded border border-gray-700">
            <p className="text-gray-400 text-sm">Receita Total</p>
            <p className="text-2xl font-bold text-green-500">
              R$ {(stats.data.totalRevenue / 100).toFixed(2)}
            </p>
          </div>
        </div>
      )}

      {/* Search */}
      <div className="relative">
        <Search className="absolute left-3 top-3 text-gray-500" size={20} />
        <Input
          placeholder="Buscar por nome ou número do pedido..."
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
          className="bg-gray-800 border-gray-700 text-white pl-10"
        />
      </div>

      {/* Tabs */}
      <Tabs value={activeTab} onValueChange={setActiveTab}>
        <TabsList className="bg-gray-800 border-gray-700">
          <TabsTrigger value="leads" className="text-gray-300">
            Leads com Produtos ({leadsWithProducts.data?.length || 0})
          </TabsTrigger>
          <TabsTrigger value="active" className="text-gray-300">
            Pedidos Ativos ({filteredActive.length})
          </TabsTrigger>
          <TabsTrigger value="completed" className="text-gray-300">
            Finalizados ({filteredCompleted.length})
          </TabsTrigger>
        </TabsList>

        <TabsContent value="leads">
          {leadsWithProducts.isLoading ? (
            <div className="text-center text-gray-400 py-8">Carregando...</div>
          ) : (leadsWithProducts.data?.length || 0) === 0 ? (
            <div className="text-center text-gray-400 py-8">
              Nenhum lead com produtos vinculados
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {leadsWithProducts.data?.map((lead: any) => (
                <div key={lead.id} className="bg-gray-900 p-4 rounded border border-gray-700">
                  <h3 className="text-lg font-bold text-white mb-2">{lead.name}</h3>
                  <p className="text-gray-400 text-sm mb-1">Phone: {lead.phone}</p>
                  {lead.email && <p className="text-gray-400 text-sm mb-1">Email: {lead.email}</p>}
                  <p className="text-gray-400 text-sm mb-3">Status: <span className="text-blue-400">{lead.status}</span></p>
                  <div className="border-t border-gray-700 pt-3 mt-3">
                    <p className="text-gray-300 text-sm font-semibold mb-2">Produtos:</p>
                    {lead.linkedProducts?.map((product: any, idx: number) => (
                      <div key={idx} className="text-gray-400 text-xs mb-1">
                        {product.productName}: P({product.sizeP}) M({product.sizeM}) G({product.sizeG}) GG({product.sizeGG})
                      </div>
                    ))}
                  </div>
                </div>
              ))}
            </div>
          )}
        </TabsContent>

        <TabsContent value="active">
          {activeOrders.isLoading ? (
            <div className="text-center text-gray-400 py-8">Carregando...</div>
          ) : filteredActive.length === 0 ? (
            <div className="text-center text-gray-400 py-8">
              Nenhum pedido ativo encontrado
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {filteredActive.map((order) => (
                <OrderCard
                  key={order.id}
                  id={order.id}
                  orderNumber={order.orderNumber}
                  customerName={order.customerName}
                  customerPhone={order.customerPhone}
                  description={order.description}
                  totalAmount={order.totalAmount}
                  status={order.status}
                  customizationName={order.customizationName || undefined}
                  customizationNumber={order.customizationNumber || undefined}
                  notes={order.notes || undefined}
                  onEdit={handleEditOrder}
                  onStatusChange={handleStatusChange}
                  onDelete={handleDeleteOrder}
                />
              ))}
            </div>
          )}
        </TabsContent>

        <TabsContent value="completed">
          {completedOrders.isLoading ? (
            <div className="text-center text-gray-400 py-8">Carregando...</div>
          ) : filteredCompleted.length === 0 ? (
            <div className="text-center text-gray-400 py-8">
              Nenhum pedido finalizado encontrado
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {filteredCompleted.map((order) => (
                <OrderCard
                  key={order.id}
                  id={order.id}
                  orderNumber={order.orderNumber}
                  customerName={order.customerName}
                  customerPhone={order.customerPhone}
                  description={order.description}
                  totalAmount={order.totalAmount}
                  status={order.status}
                  customizationName={order.customizationName || undefined}
                  customizationNumber={order.customizationNumber || undefined}
                  notes={order.notes || undefined}
                  onEdit={handleEditOrder}
                  onStatusChange={handleStatusChange}
                  onDelete={handleDeleteOrder}
                />
              ))}
            </div>
          )}
        </TabsContent>
      </Tabs>

      {/* Modal */}
      <OrderModal
        isOpen={isModalOpen}
        onClose={() => {
          setIsModalOpen(false);
          setEditingOrder(null);
        }}
        onSubmit={editingOrder ? handleUpdateOrder : handleCreateOrder}
        initialData={editingOrder}
        isLoading={
          createOrderMutation.isPending || updateOrderMutation.isPending
        }
      />
    </div>
  );
}
