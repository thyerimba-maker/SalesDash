import { useState } from 'react';
import { Plus, Trash2, Edit2, DollarSign } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { toast } from 'sonner';
import { trpc } from '@/lib/trpc';
import DashboardLayout from '@/components/DashboardLayout';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog';
import { Badge } from '@/components/ui/badge';

interface Supplier {
  id: number;
  name: string;
  contact: string;
  email?: string;
  products: string;
  averagePrice: string;
  status: 'active' | 'inactive';
  notes?: string;
}

export default function Suppliers() {
  const [isAddingNew, setIsAddingNew] = useState(false);
  const [editingId, setEditingId] = useState<number | null>(null);
  const [searchQuery, setSearchQuery] = useState('');
  const [dollarRate, setDollarRate] = useState<number>(5.0);
  const [dollarInput, setDollarInput] = useState<string>('');
  const [newSupplier, setNewSupplier] = useState({
    name: '',
    contact: '',
    email: '',
    products: '',
    averagePrice: '',
    status: 'active' as const,
    notes: '',
  });

  const { data: suppliers = [] } = trpc.suppliers.list.useQuery(undefined, {
    staleTime: 30000,
    gcTime: 5 * 60 * 1000,
  });

  const utils = trpc.useUtils();

  const createMutation = trpc.suppliers.create.useMutation({
    onSuccess: () => utils.suppliers.list.invalidate(),
  });

  const updateMutation = trpc.suppliers.update.useMutation({
    onSuccess: () => utils.suppliers.list.invalidate(),
  });

  const deleteMutation = trpc.suppliers.delete.useMutation({
    onSuccess: () => utils.suppliers.list.invalidate(),
  });

  const filteredSuppliers = suppliers.filter((supplier: Supplier) =>
    supplier.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
    supplier.products.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const handleAddSupplier = async () => {
    if (!newSupplier.name || !newSupplier.contact || !newSupplier.products || !newSupplier.averagePrice) {
      toast.error('Preencha todos os campos obrigatórios');
      return;
    }

    try {
      await createMutation.mutateAsync({
        ...newSupplier,
        averagePrice: newSupplier.averagePrice,
        status: 'active',
      });
      setNewSupplier({
        name: '',
        contact: '',
        email: '',
        products: '',
        averagePrice: '',
        status: 'active',
        notes: '',
      });
      setIsAddingNew(false);
      toast.success('Fornecedor adicionado com sucesso');
    } catch (error) {
      toast.error('Erro ao adicionar fornecedor');
    }
  };

  const handleDeleteSupplier = async (id: number) => {
    if (!confirm('Tem certeza que deseja deletar este fornecedor?')) return;

    try {
      await deleteMutation.mutateAsync({ id });
      toast.success('Fornecedor deletado com sucesso');
    } catch (error) {
      toast.error('Erro ao deletar fornecedor');
    }
  };

  const handleToggleStatus = async (supplier: Supplier) => {
    try {
      await updateMutation.mutateAsync({
        id: supplier.id,
        status: supplier.status === 'active' ? 'inactive' : 'active',
      });
      toast.success('Status atualizado com sucesso');
    } catch (error) {
      toast.error('Erro ao atualizar status');
    }
  };

  const dollarValue = dollarInput ? (parseFloat(dollarInput) * dollarRate).toFixed(2) : '0.00';

  return (
    <DashboardLayout title="Gestão de Fornecedores">
      <div className="space-y-6">
        {/* Header */}
        <div className="flex items-center justify-between">
          <h1 className="text-3xl font-bold text-foreground">Fornecedores</h1>
          <Button
            onClick={() => setIsAddingNew(!isAddingNew)}
            className="bg-primary hover:bg-primary/90 text-white"
          >
            <Plus className="w-4 h-4 mr-2" />
            Novo Fornecedor
          </Button>
        </div>

        {/* Search Bar */}
        <div className="bg-card border border-border rounded-lg p-4">
          <Input
            type="text"
            placeholder="Pesquisar por nome ou produtos..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full"
          />
        </div>

        {/* Dollar Converter */}
        <div className="bg-card border border-border rounded-lg p-6">
          <div className="flex items-center gap-2 mb-4">
            <DollarSign className="w-5 h-5 text-primary" />
            <h2 className="text-lg font-semibold text-foreground">Conversor de Dólar</h2>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div>
              <label className="text-sm text-muted-foreground">Taxa de câmbio (R$/USD)</label>
              <Input
                type="number"
                value={dollarRate}
                onChange={(e) => setDollarRate(parseFloat(e.target.value) || 0)}
                placeholder="5.00"
                className="mt-2"
                step="0.01"
              />
            </div>
            <div>
              <label className="text-sm text-muted-foreground">Valor em USD</label>
              <Input
                type="number"
                value={dollarInput}
                onChange={(e) => setDollarInput(e.target.value)}
                placeholder="0.00"
                className="mt-2"
                step="0.01"
              />
            </div>
            <div>
              <label className="text-sm text-muted-foreground">Valor em BRL</label>
              <div className="mt-2 bg-background border border-border rounded px-3 py-2 text-foreground font-semibold">
                R$ {dollarValue}
              </div>
            </div>
          </div>
        </div>

        {/* Add New Supplier Form */}
        {isAddingNew && (
          <div className="bg-card border border-border rounded-lg p-6 space-y-4">
            <h2 className="text-lg font-semibold text-foreground">Novo Fornecedor</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <Input
                placeholder="Nome do fornecedor"
                value={newSupplier.name}
                onChange={(e) => setNewSupplier({ ...newSupplier, name: e.target.value })}
              />
              <Input
                placeholder="Contato (telefone)"
                value={newSupplier.contact}
                onChange={(e) => setNewSupplier({ ...newSupplier, contact: e.target.value })}
              />
              <Input
                placeholder="Email"
                type="email"
                value={newSupplier.email}
                onChange={(e) => setNewSupplier({ ...newSupplier, email: e.target.value })}
              />
              <Input
                placeholder="Produtos que vende"
                value={newSupplier.products}
                onChange={(e) => setNewSupplier({ ...newSupplier, products: e.target.value })}
              />
              <Input
                placeholder="Preço médio"
                type="number"
                value={newSupplier.averagePrice}
                onChange={(e) => setNewSupplier({ ...newSupplier, averagePrice: e.target.value })}
                step="0.01"
              />
            </div>
            <textarea
              placeholder="Notas adicionais"
              value={newSupplier.notes}
              onChange={(e) => setNewSupplier({ ...newSupplier, notes: e.target.value })}
              className="w-full p-2 border border-border rounded bg-background text-foreground"
              rows={3}
            />
            <div className="flex gap-2">
              <Button
                onClick={handleAddSupplier}
                className="bg-green-600 hover:bg-green-700 text-white"
                disabled={createMutation.isPending}
              >
                {createMutation.isPending ? 'Salvando...' : 'Salvar'}
              </Button>
              <Button
                onClick={() => setIsAddingNew(false)}
                variant="outline"
              >
                Cancelar
              </Button>
            </div>
          </div>
        )}

        {/* Suppliers List */}
        <div className="space-y-3">
          {filteredSuppliers.length === 0 ? (
            <div className="text-center text-muted-foreground py-8">
              Nenhum fornecedor encontrado
            </div>
          ) : (
            filteredSuppliers.map((supplier: Supplier) => (
              <div key={supplier.id} className="bg-card border border-border rounded-lg p-4 hover:shadow-md transition-shadow">
                <div className="flex items-start justify-between">
                  <div className="flex-1">
                    <div className="flex items-center gap-2 mb-2">
                      <h3 className="text-lg font-semibold text-foreground">{supplier.name}</h3>
                      <Badge variant={supplier.status === 'active' ? 'default' : 'secondary'}>
                        {supplier.status === 'active' ? 'Ativo' : 'Inativo'}
                      </Badge>
                    </div>
                    <div className="grid grid-cols-2 md:grid-cols-4 gap-2 text-sm">
                      <div>
                        <span className="text-muted-foreground">Contato:</span>
                        <p className="text-foreground font-medium">{supplier.contact}</p>
                      </div>
                      {supplier.email && (
                        <div>
                          <span className="text-muted-foreground">Email:</span>
                          <p className="text-foreground font-medium">{supplier.email}</p>
                        </div>
                      )}
                      <div>
                        <span className="text-muted-foreground">Produtos:</span>
                        <p className="text-foreground font-medium">{supplier.products}</p>
                      </div>
                      <div>
                        <span className="text-muted-foreground">Preço médio:</span>
                        <p className="text-foreground font-medium">R$ {supplier.averagePrice}</p>
                      </div>
                    </div>
                    {supplier.notes && (
                      <p className="text-sm text-muted-foreground mt-2">Notas: {supplier.notes}</p>
                    )}
                  </div>
                  <div className="flex gap-2 ml-4">
                    <Button
                      onClick={() => handleToggleStatus(supplier)}
                      variant="outline"
                      size="sm"
                      className={supplier.status === 'active' ? 'text-green-600' : 'text-red-600'}
                    >
                      {supplier.status === 'active' ? 'Desativar' : 'Ativar'}
                    </Button>
                    <Button
                      onClick={() => handleDeleteSupplier(supplier.id)}
                      variant="outline"
                      size="sm"
                      className="text-red-600 hover:text-red-700"
                      disabled={deleteMutation.isPending}
                    >
                      <Trash2 className="w-4 h-4" />
                    </Button>
                  </div>
                </div>
              </div>
            ))
          )}
        </div>
      </div>
    </DashboardLayout>
  );
}
