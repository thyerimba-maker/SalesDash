import { useState } from 'react';
import { Plus, Search } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { toast } from 'sonner';
import { trpc } from '@/lib/trpc';
import DashboardLayout from '@/components/DashboardLayout';
import LeadCard from '@/components/LeadCard';
import NewLeadModal, { LeadFormData } from '@/components/NewLeadModal';
import EditLeadModal from '@/components/EditLeadModal';
import LinkProductModal from '@/components/LinkProductModal';

export default function LeadsPage() {
  const [modalOpen, setModalOpen] = useState(false);
  const [editModalOpen, setEditModalOpen] = useState(false);
  const [linkProductModalOpen, setLinkProductModalOpen] = useState(false);
  const [selectedLeadForEdit, setSelectedLeadForEdit] = useState<any>(null);
  const [selectedLeadForLinking, setSelectedLeadForLinking] = useState<any>(null);
  const [searchValue, setSearchValue] = useState('');
  const [activeTab, setActiveTab] = useState('new');

  // Fetch leads
  const { data: leadsData, isLoading: leadsLoading, refetch: refetchLeads } = trpc.leads.list.useQuery(undefined, {
    staleTime: 30000, // Cache for 30 seconds
    gcTime: 5 * 60 * 1000, // Keep in cache for 5 minutes
  });

  // Mutations
  const createLeadMutation = trpc.leads.create.useMutation();
  const updateLeadMutation = trpc.leads.update.useMutation();

  const leads = leadsData || [];

  // Filter leads by status
  const newLeads = leads.filter(l => l.status === 'leads');
  const activeLeads = leads.filter(l => l.status !== 'leads' && l.status !== 'venda_feita' && l.status !== 'venda_perdida');

  // Filter by search
  const filteredNewLeads = newLeads.filter(l =>
    l.name.toLowerCase().includes(searchValue.toLowerCase()) ||
    l.phone.includes(searchValue)
  );

  const filteredActiveLeads = activeLeads.filter(l =>
    l.name.toLowerCase().includes(searchValue.toLowerCase()) ||
    l.phone.includes(searchValue)
  );

  const handleCreateLead = async (data: LeadFormData) => {
    try {
      await createLeadMutation.mutateAsync({
        name: data.name,
        phone: data.phone,
        email: data.email,
        product: data.product,
        source: data.source,
        notes: data.notes,
      });
      toast.success('Lead criado com sucesso!');
      setModalOpen(false);
      // Invalidate cache instead of refetching
      trpc.useUtils().leads.list.invalidate();
    } catch (error: any) {
      toast.error(`Erro: ${error.message}`);
    }
  };

  const handleEditLead = (lead: any) => {
    setSelectedLeadForEdit(lead);
    setEditModalOpen(true);
  };

  const handleSaveEdit = async (data: any) => {
    try {
      await updateLeadMutation.mutateAsync({
        id: selectedLeadForEdit.id,
        ...data,
      });
      toast.success('Lead atualizado com sucesso!');
      setEditModalOpen(false);
      setSelectedLeadForEdit(null);
      refetchLeads();
    } catch (error: any) {
      toast.error(`Erro: ${error.message}`);
    }
  };

  const handleLinkProduct = (lead: any) => {
    setSelectedLeadForLinking(lead);
    setLinkProductModalOpen(true);
  };

  // Note: Lead closure is now handled by CloseLeadModal component
  // which provides all required fields (status, reason, saleAmount, etc.)

  return (
    <DashboardLayout title="Gerenciamento de Leads">
      <div className="space-y-6">
        {/* Header */}
        <div className="flex justify-between items-center">
          <h1 className="text-3xl font-bold text-foreground">Leads</h1>
          <Button
            onClick={() => setModalOpen(true)}
            className="bg-primary hover:bg-primary/90"
          >
            <Plus size={20} /> Novo Lead
          </Button>
        </div>

        {/* Search */}
        <div className="relative">
          <Search className="absolute left-3 top-3 text-muted-foreground" size={20} />
          <Input
            placeholder="Buscar por nome ou telefone..."
            value={searchValue}
            onChange={(e) => setSearchValue(e.target.value)}
            className="pl-10"
          />
        </div>

        {/* Tabs */}
        <Tabs value={activeTab} onValueChange={setActiveTab}>
          <TabsList className="grid w-full grid-cols-2">
            <TabsTrigger value="new">
              Novos ({filteredNewLeads.length})
            </TabsTrigger>
            <TabsTrigger value="active">
              Ativos ({filteredActiveLeads.length})
            </TabsTrigger>
          </TabsList>

          <TabsContent value="new" className="space-y-4">
            {leadsLoading ? (
              <div className="text-center text-muted-foreground py-8">Carregando...</div>
            ) : filteredNewLeads.length === 0 ? (
              <div className="text-center text-muted-foreground py-8">
                Nenhum lead novo encontrado
              </div>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                {filteredNewLeads.map((lead) => (
                  <LeadCard
                    key={lead.id}
                    id={lead.id.toString()}
                    leadId={lead.id}
                    name={lead.name}
                    phone={lead.phone}
                    status={lead.status}
                    product={lead.product}
                    notes={lead.notes}
                    onEdit={() => handleEditLead(lead)}
                    onLinkProduct={() => handleLinkProduct(lead)}
                    onClose={() => handleCloseLead(lead.id)}
                  />
                ))}
              </div>
            )}
          </TabsContent>

          <TabsContent value="active" className="space-y-4">
            {leadsLoading ? (
              <div className="text-center text-muted-foreground py-8">Carregando...</div>
            ) : filteredActiveLeads.length === 0 ? (
              <div className="text-center text-muted-foreground py-8">
                Nenhum lead ativo encontrado
              </div>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                {filteredActiveLeads.map((lead) => (
                  <LeadCard
                    key={lead.id}
                    id={lead.id.toString()}
                    leadId={lead.id}
                    name={lead.name}
                    phone={lead.phone}
                    status={lead.status}
                    product={lead.product}
                    notes={lead.notes}
                    onEdit={() => handleEditLead(lead)}
                    onLinkProduct={() => handleLinkProduct(lead)}
                    onClose={() => handleCloseLead(lead.id)}
                  />
                ))}
              </div>
            )}
          </TabsContent>
        </Tabs>

        {/* Modals */}
        <NewLeadModal
          isOpen={modalOpen}
          onClose={() => setModalOpen(false)}
          onSubmit={handleCreateLead}
        />

        {selectedLeadForEdit && (
          <EditLeadModal
            isOpen={editModalOpen}
            lead={selectedLeadForEdit}
            onClose={() => {
              setEditModalOpen(false);
              setSelectedLeadForEdit(null);
            }}
            onSave={handleSaveEdit}
          />
        )}

        {selectedLeadForLinking && (
          <LinkProductModal
            isOpen={linkProductModalOpen}
            leadId={selectedLeadForLinking.id}
            onClose={() => {
              setLinkProductModalOpen(false);
              setSelectedLeadForLinking(null);
            }}
            onSuccess={() => {
              refetchLeads();
            }}
          />
        )}
      </div>
    </DashboardLayout>
  );
}
