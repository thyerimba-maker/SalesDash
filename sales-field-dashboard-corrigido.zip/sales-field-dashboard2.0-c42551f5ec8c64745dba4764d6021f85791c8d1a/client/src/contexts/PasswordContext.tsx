import React, { createContext, useContext, useState, useEffect } from 'react';

interface PasswordContextType {
  isAuthenticated: boolean;
  setAuthenticated: (value: boolean) => void;
  password: string;
  setPassword: (value: string) => void;
}

const PasswordContext = createContext<PasswordContextType | undefined>(undefined);

export function PasswordProvider({ children }: { children: React.ReactNode }) {
  const [isAuthenticated, setAuthenticated] = useState(false);
  const [password, setPassword] = useState('');

  // Check if already authenticated on mount
  useEffect(() => {
    const stored = localStorage.getItem('dashboardAuth');
    if (stored === 'true') {
      setAuthenticated(true);
    }
  }, []);

  return (
    <PasswordContext.Provider value={{ isAuthenticated, setAuthenticated, password, setPassword }}>
      {children}
    </PasswordContext.Provider>
  );
}

export function usePassword() {
  const context = useContext(PasswordContext);
  if (!context) {
    throw new Error('usePassword must be used within PasswordProvider');
  }
  return context;
}
