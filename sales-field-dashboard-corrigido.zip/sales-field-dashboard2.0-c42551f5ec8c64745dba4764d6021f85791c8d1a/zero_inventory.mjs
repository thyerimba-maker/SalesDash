import mysql from 'mysql2/promise';

async function zeroInventory() {
  const connection = await mysql.createConnection({
    host: process.env.DATABASE_URL?.split('@')[1]?.split('/')[0] || 'localhost',
    user: process.env.DATABASE_URL?.split('://')[1]?.split(':')[0] || 'root',
    password: process.env.DATABASE_URL?.split(':')[2]?.split('@')[0] || '',
    database: process.env.DATABASE_URL?.split('/').pop() || 'test',
  });

  try {
    // Zero all inventory
    const [result] = await connection.execute(
      'UPDATE inventory SET sizeP = 0, sizeM = 0, sizeG = 0, sizeGG = 0, totalQuantity = 0'
    );
    console.log(`✅ ${result.affectedRows} produtos zerados com sucesso!`);
  } catch (error) {
    console.error('❌ Erro ao zerar produtos:', error);
  } finally {
    await connection.end();
  }
}

zeroInventory();
