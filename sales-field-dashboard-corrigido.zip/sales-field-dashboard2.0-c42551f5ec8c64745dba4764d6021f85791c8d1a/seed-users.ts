import { drizzle } from 'drizzle-orm/mysql2';
import mysql from 'mysql2/promise';
import bcrypt from 'bcrypt';
import { appUsers } from './drizzle/schema';
import { eq } from 'drizzle-orm';

const DATABASE_URL = process.env.DATABASE_URL;

if (!DATABASE_URL) {
  console.error('DATABASE_URL not set');
  process.exit(1);
}

async function seed() {
  try {
    const connection = await mysql.createConnection(DATABASE_URL);
    const db = drizzle(connection);

    // Hash password
    const passwordHash = await bcrypt.hash('admin123', 10);

    // Check if user exists
    const existing = await db
      .select()
      .from(appUsers)
      .where(eq(appUsers.username, 'admin'))
      .limit(1);

    if (existing.length > 0) {
      console.log('✓ User admin already exists');
    } else {
      // Insert default user
      await db.insert(appUsers).values({
        username: 'admin',
        passwordHash,
        status: 'active',
      });
      console.log('✓ Default user created: admin / admin123');
    }

    await connection.end();
  } catch (error) {
    console.error('Seed error:', error);
    process.exit(1);
  }
}

seed();
