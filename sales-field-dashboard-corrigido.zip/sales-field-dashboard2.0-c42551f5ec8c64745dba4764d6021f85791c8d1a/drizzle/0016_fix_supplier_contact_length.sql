ALTER TABLE `suppliers` MODIFY COLUMN `contact` varchar(100) NOT NULL;
