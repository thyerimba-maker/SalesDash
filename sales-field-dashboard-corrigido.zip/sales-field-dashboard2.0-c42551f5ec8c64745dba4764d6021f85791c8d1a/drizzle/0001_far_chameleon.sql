CREATE TABLE `contactHistory` (
	`id` int AUTO_INCREMENT NOT NULL,
	`leadId` int NOT NULL,
	`userId` int NOT NULL,
	`type` enum('call','whatsapp','email','meeting','note') NOT NULL,
	`description` text,
	`duration` int,
	`outcome` varchar(100),
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `contactHistory_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `dailyMetrics` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`date` varchar(10) NOT NULL,
	`salesAmount` int DEFAULT 0,
	`salesCount` int DEFAULT 0,
	`newLeads` int DEFAULT 0,
	`conversions` int DEFAULT 0,
	`calls` int DEFAULT 0,
	`messages` int DEFAULT 0,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `dailyMetrics_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `leads` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`name` varchar(255) NOT NULL,
	`phone` varchar(20) NOT NULL,
	`email` varchar(320),
	`product` varchar(255) NOT NULL,
	`status` enum('leads','atendimento','aguardando','confirmado','em_rota','concluido') NOT NULL DEFAULT 'leads',
	`source` varchar(100) DEFAULT 'direto',
	`notes` text,
	`lastContact` timestamp,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `leads_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `sales` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`leadId` int NOT NULL,
	`amount` int NOT NULL,
	`product` varchar(255) NOT NULL,
	`paymentMethod` varchar(100),
	`notes` text,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `sales_id` PRIMARY KEY(`id`)
);
