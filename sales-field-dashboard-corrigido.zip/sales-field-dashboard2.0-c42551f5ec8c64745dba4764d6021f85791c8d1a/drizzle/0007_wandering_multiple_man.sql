CREATE TABLE `leadHistory` (
	`id` int AUTO_INCREMENT NOT NULL,
	`leadId` int NOT NULL,
	`userId` int NOT NULL,
	`action` varchar(100) NOT NULL,
	`oldValue` text,
	`newValue` text,
	`description` text,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `leadHistory_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `leadProducts` (
	`id` int AUTO_INCREMENT NOT NULL,
	`leadId` int NOT NULL,
	`userId` int NOT NULL,
	`productName` varchar(255) NOT NULL,
	`description` text,
	`sizeP` int NOT NULL DEFAULT 0,
	`sizeM` int NOT NULL DEFAULT 0,
	`sizeG` int NOT NULL DEFAULT 0,
	`sizeGG` int NOT NULL DEFAULT 0,
	`totalQuantity` int NOT NULL DEFAULT 0,
	`unitPrice` int,
	`status` enum('pendente','confirmado','em_producao','pronto','entregue') NOT NULL DEFAULT 'pendente',
	`notes` text,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `leadProducts_id` PRIMARY KEY(`id`)
);
