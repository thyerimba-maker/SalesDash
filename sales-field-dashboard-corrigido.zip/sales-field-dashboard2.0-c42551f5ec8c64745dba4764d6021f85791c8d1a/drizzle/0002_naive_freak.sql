ALTER TABLE `leads` MODIFY COLUMN `status` enum('leads','atendimento','aguardando','confirmado','em_rota','concluido','venda_feita','venda_perdida') NOT NULL DEFAULT 'leads';--> statement-breakpoint
ALTER TABLE `leads` ADD `closureReason` varchar(255);--> statement-breakpoint
ALTER TABLE `leads` ADD `closureDate` timestamp;--> statement-breakpoint
ALTER TABLE `leads` ADD `followUpDate` timestamp;