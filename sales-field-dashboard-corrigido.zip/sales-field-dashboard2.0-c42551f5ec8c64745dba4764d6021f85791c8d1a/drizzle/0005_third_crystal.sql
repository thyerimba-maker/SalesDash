CREATE TABLE `orderHistory` (
	`id` int AUTO_INCREMENT NOT NULL,
	`orderId` int NOT NULL,
	`userId` int NOT NULL,
	`action` varchar(100) NOT NULL,
	`oldValue` text,
	`newValue` text,
	`description` text,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `orderHistory_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `orders` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`leadId` int,
	`customerName` varchar(255) NOT NULL,
	`customerPhone` varchar(20) NOT NULL,
	`customerEmail` varchar(320),
	`orderNumber` varchar(50) NOT NULL,
	`description` text NOT NULL,
	`totalAmount` int NOT NULL,
	`status` enum('pendente','confirmado','preparando','pronto','saiu_entrega','entregue','cancelado','devolvido') NOT NULL DEFAULT 'pendente',
	`customizationName` varchar(255),
	`customizationNumber` varchar(100),
	`customizationDetails` text,
	`notes` text,
	`internalNotes` text,
	`orderDate` timestamp NOT NULL DEFAULT (now()),
	`dueDate` timestamp,
	`completedDate` timestamp,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `orders_id` PRIMARY KEY(`id`),
	CONSTRAINT `orders_orderNumber_unique` UNIQUE(`orderNumber`)
);
