import { int, mysqlEnum, mysqlTable, text, timestamp, varchar, decimal } from "drizzle-orm/mysql-core";

/**
 * Core user table backing auth flow.
 * Extend this file with additional tables as your product grows.
 * Columns use camelCase to match both database fields and generated types.
 */
export const users = mysqlTable("users", {
  /**
   * Surrogate primary key. Auto-incremented numeric value managed by the database.
   * Use this for relations between tables.
   */
  id: int("id").autoincrement().primaryKey(),
  /** Manus OAuth identifier (openId) returned from the OAuth callback. Unique per user. */
  openId: varchar("openId", { length: 64 }).notNull().unique(),
  name: text("name"),
  email: varchar("email", { length: 320 }),
  loginMethod: varchar("loginMethod", { length: 64 }),
  role: mysqlEnum("role", ["user", "admin"]).default("user").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  lastSignedIn: timestamp("lastSignedIn").defaultNow().notNull(),
});

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;

/**
 * App Users table - for local username/password authentication
 */
export const appUsers = mysqlTable("appUsers", {
  id: int("id").autoincrement().primaryKey(),
  username: varchar("username", { length: 100 }).notNull().unique(),
  passwordHash: varchar("passwordHash", { length: 255 }).notNull(),
  status: mysqlEnum("status", ["active", "inactive"]).default("active").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type AppUser = typeof appUsers.$inferSelect;
export type InsertAppUser = typeof appUsers.$inferInsert;

/**
 * Leads table - stores all sales leads with contact information and status
 */
export const leads = mysqlTable("leads", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  name: varchar("name", { length: 255 }).notNull(),
  phone: varchar("phone", { length: 20 }).notNull(),
  email: varchar("email", { length: 320 }),
  product: varchar("product", { length: 255 }).notNull(),
  status: mysqlEnum("status", ["leads", "atendimento", "aguardando", "confirmado", "em_rota", "concluido", "venda_feita", "venda_perdida"]).default("leads").notNull(),
  source: varchar("source", { length: 100 }).default("direto"),
  notes: text("notes"),
  closureReason: varchar("closureReason", { length: 255 }), // Motivo da finalização
  closureDate: timestamp("closureDate"), // Data da finalização
  followUpDate: timestamp("followUpDate"), // Data agendada para follow-up
  saleAmount: int("saleAmount"), // Valor da venda em centavos
  lastContact: timestamp("lastContact"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Lead = typeof leads.$inferSelect;
export type InsertLead = typeof leads.$inferInsert;

/**
 * Sales table - records completed sales transactions
 */
export const sales = mysqlTable("sales", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  leadId: int("leadId").notNull(),
  amount: int("amount").notNull(), // Stored in cents (e.g., 284000 = R$ 2.840,00)
  product: varchar("product", { length: 255 }).notNull(),
  paymentMethod: varchar("paymentMethod", { length: 100 }),
  notes: text("notes"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Sale = typeof sales.$inferSelect;
export type InsertSale = typeof sales.$inferInsert;

/**
 * Contact history table - tracks all interactions with leads
 */
export const contactHistory = mysqlTable("contactHistory", {
  id: int("id").autoincrement().primaryKey(),
  leadId: int("leadId").notNull(),
  userId: int("userId").notNull(),
  type: mysqlEnum("type", ["call", "whatsapp", "email", "meeting", "note"]).notNull(),
  description: text("description"),
  duration: int("duration"), // Duration in seconds for calls
  outcome: varchar("outcome", { length: 100 }), // e.g., "interested", "not_interested", "callback"
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type ContactHistory = typeof contactHistory.$inferSelect;
export type InsertContactHistory = typeof contactHistory.$inferInsert;

/**
 * Daily metrics table - stores aggregated performance metrics
 */
export const dailyMetrics = mysqlTable("dailyMetrics", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  date: varchar("date", { length: 10 }).notNull(), // YYYY-MM-DD format
  salesAmount: int("salesAmount").default(0), // Total sales in cents
  salesCount: int("salesCount").default(0),
  newLeads: int("newLeads").default(0),
  conversions: int("conversions").default(0),
  calls: int("calls").default(0),
  messages: int("messages").default(0),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type DailyMetrics = typeof dailyMetrics.$inferSelect;
export type InsertDailyMetrics = typeof dailyMetrics.$inferInsert;

/**
 * Tasks table - stores tasks assigned to sales reps
 */
export const tasks = mysqlTable("tasks", {
  id: int("id").autoincrement().primaryKey(),
  leadId: int("leadId"),
  assignedTo: int("assignedTo").notNull(),
  assignedBy: int("assignedBy").notNull(),
  title: varchar("title", { length: 255 }).notNull(),
  description: text("description"),
  priority: mysqlEnum("priority", ["low", "normal", "high", "urgent"]).default("normal").notNull(),
  status: mysqlEnum("status", ["pending", "in_progress", "completed", "cancelled"]).default("pending").notNull(),
  dueDate: timestamp("dueDate").notNull(),
  completedAt: timestamp("completedAt"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Task = typeof tasks.$inferSelect;
export type InsertTask = typeof tasks.$inferInsert;

/**
 * Audit logs table - tracks all critical actions for compliance
 */
export const auditLogs = mysqlTable("auditLogs", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  action: varchar("action", { length: 100 }).notNull(),
  entityType: varchar("entityType", { length: 100 }).notNull(),
  entityId: int("entityId"),
  details: text("details"),
  ipAddress: varchar("ipAddress", { length: 45 }),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type AuditLog = typeof auditLogs.$inferSelect;
export type InsertAuditLog = typeof auditLogs.$inferInsert;

/**
 * Lead scoring table - stores calculated lead scores
 */
export const leadScores = mysqlTable("leadScores", {
  id: int("id").autoincrement().primaryKey(),
  leadId: int("leadId").notNull().unique(),
  score: int("score").notNull(),
  conversionProbability: int("conversionProbability").notNull(),
  factors: text("factors"),
  lastUpdated: timestamp("lastUpdated").defaultNow().onUpdateNow().notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type LeadScore = typeof leadScores.$inferSelect;
export type InsertLeadScore = typeof leadScores.$inferInsert;

/**
 * Webhooks table - stores webhook configurations
 */
export const webhooks = mysqlTable("webhooks", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  name: varchar("name", { length: 255 }).notNull(),
  url: varchar("url", { length: 2048 }).notNull(),
  events: varchar("events", { length: 500 }).notNull(),
  isActive: int("isActive").default(1).notNull(),
  secret: varchar("secret", { length: 255 }).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Webhook = typeof webhooks.$inferSelect;
export type InsertWebhook = typeof webhooks.$inferInsert;



/**
 * Orders table - stores customer orders with status tracking
 */
export const orders = mysqlTable("orders", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  leadId: int("leadId"), // Optional: link to lead
  customerName: varchar("customerName", { length: 255 }).notNull(),
  customerPhone: varchar("customerPhone", { length: 20 }).notNull(),
  customerEmail: varchar("customerEmail", { length: 320 }),
  
  // Order details
  orderNumber: varchar("orderNumber", { length: 50 }).notNull().unique(),
  description: text("description").notNull(),
  totalAmount: int("totalAmount").notNull(), // Amount in cents
  
  // Status tracking
  status: mysqlEnum("status", [
    "pendente",
    "confirmado",
    "preparando",
    "pronto",
    "saiu_entrega",
    "entregue",
    "cancelado",
    "devolvido"
  ]).default("pendente").notNull(),
  
  // Customization (optional fields for product customization)
  customizationName: varchar("customizationName", { length: 255 }), // e.g., "Cor: Azul"
  customizationNumber: varchar("customizationNumber", { length: 100 }), // e.g., "Tamanho: G"
  customizationDetails: text("customizationDetails"), // Additional customization info
  
  // Notes and tracking
  notes: text("notes"), // Internal notes
  internalNotes: text("internalNotes"), // Private notes for team
  
  // Dates
  orderDate: timestamp("orderDate").defaultNow().notNull(),
  dueDate: timestamp("dueDate"), // Expected delivery/completion date
  completedDate: timestamp("completedDate"), // Actual completion date
  
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Order = typeof orders.$inferSelect;
export type InsertOrder = typeof orders.$inferInsert;

/**
 * Order history - tracks status changes and modifications
 */
export const orderHistory = mysqlTable("orderHistory", {
  id: int("id").autoincrement().primaryKey(),
  orderId: int("orderId").notNull(),
  userId: int("userId").notNull(),
  action: varchar("action", { length: 100 }).notNull(), // "status_changed", "note_added", "customization_updated"
  oldValue: text("oldValue"),
  newValue: text("newValue"),
  description: text("description"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type OrderHistory = typeof orderHistory.$inferSelect;
export type InsertOrderHistory = typeof orderHistory.$inferInsert;

/**
 * Inventory table - stores product inventory with size variants
 */
export const inventory = mysqlTable("inventory", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  productName: varchar("productName", { length: 255 }).notNull(),
  description: text("description"),
  
  // Size variants - quantities for each size
  sizeP: int("sizeP").default(0).notNull(), // Pequeno
  sizeM: int("sizeM").default(0).notNull(), // Médio
  sizeG: int("sizeG").default(0).notNull(), // Grande
  sizeGG: int("sizeGG").default(0).notNull(), // Extra Grande
  
  // Total quantity
  totalQuantity: int("totalQuantity").default(0).notNull(),
  
  // Pricing
  unitPrice: int("unitPrice"), // Price in cents
  
  // Image
  imageUrl: varchar("imageUrl", { length: 2048 }), // URL to product image
  
  // Tracking
  lastRestocked: timestamp("lastRestocked"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Inventory = typeof inventory.$inferSelect;
export type InsertInventory = typeof inventory.$inferInsert;

/**
 * Cash register table - tracks all cash transactions (sales, expenses, etc)
 */
export const cashRegister = mysqlTable("cashRegister", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  type: mysqlEnum("type", ["venda", "despesa", "devolucao", "ajuste"]).notNull(),
  description: varchar("description", { length: 255 }).notNull(),
  amount: int("amount").notNull(), // Amount in cents
  paymentMethod: varchar("paymentMethod", { length: 100 }),
  relatedOrderId: int("relatedOrderId"), // Link to order if applicable
  relatedSaleId: int("relatedSaleId"), // Link to sale if applicable
  notes: text("notes"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type CashRegister = typeof cashRegister.$inferSelect;
export type InsertCashRegister = typeof cashRegister.$inferInsert;

/**
 * Lead products - links products to leads with quantities and sizes
 */
export const leadProducts = mysqlTable("leadProducts", {
  id: int("id").autoincrement().primaryKey(),
  leadId: int("leadId").notNull(),
  userId: int("userId").notNull(),
  productName: varchar("productName", { length: 255 }).notNull(),
  description: text("description"),
  
  // Size variants - quantities for each size
  sizeP: int("sizeP").default(0).notNull(),
  sizeM: int("sizeM").default(0).notNull(),
  sizeG: int("sizeG").default(0).notNull(),
  sizeGG: int("sizeGG").default(0).notNull(),
  
  // Total quantity
  totalQuantity: int("totalQuantity").default(0).notNull(),
  
  // Pricing
  unitPrice: int("unitPrice"), // Price in cents
  
  // Image URL for product preview
  imageUrl: varchar("imageUrl", { length: 2048 }),
  
  // Status
  status: mysqlEnum("status", ["pendente", "confirmado", "em_producao", "pronto", "entregue"]).default("pendente").notNull(),
  
  notes: text("notes"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type LeadProduct = typeof leadProducts.$inferSelect;
export type InsertLeadProduct = typeof leadProducts.$inferInsert;

/**
 * Lead history/activity - tracks all movements and changes for leads
 */
export const leadHistory = mysqlTable("leadHistory", {
  id: int("id").autoincrement().primaryKey(),
  leadId: int("leadId").notNull(),
  userId: int("userId").notNull(),
  action: varchar("action", { length: 100 }).notNull(), // "created", "status_changed", "product_added", "product_removed", "note_added", "contact_made"
  oldValue: text("oldValue"),
  newValue: text("newValue"),
  description: text("description"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type LeadHistory = typeof leadHistory.$inferSelect;
export type InsertLeadHistory = typeof leadHistory.$inferInsert;


/**
 * Suppliers table - stores supplier information with contact details and products
 */
export const suppliers = mysqlTable("suppliers", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  name: varchar("name", { length: 255 }).notNull(),
  contact: varchar("contact", { length: 100 }).notNull(),
  email: varchar("email", { length: 255 }),
  products: text("products").notNull(), // JSON array of products they sell
  averagePrice: decimal("averagePrice", { precision: 10, scale: 2 }).notNull(),
  status: mysqlEnum("status", ["active", "inactive"]).default("active").notNull(),
  notes: text("notes"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Supplier = typeof suppliers.$inferSelect;
export type InsertSupplier = typeof suppliers.$inferInsert;
