CREATE TABLE `cashRegister` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`type` enum('venda','despesa','devolucao','ajuste') NOT NULL,
	`description` varchar(255) NOT NULL,
	`amount` int NOT NULL,
	`paymentMethod` varchar(100),
	`relatedOrderId` int,
	`relatedSaleId` int,
	`notes` text,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `cashRegister_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `inventory` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`productName` varchar(255) NOT NULL,
	`description` text,
	`sizeP` int NOT NULL DEFAULT 0,
	`sizeM` int NOT NULL DEFAULT 0,
	`sizeG` int NOT NULL DEFAULT 0,
	`sizeGG` int NOT NULL DEFAULT 0,
	`totalQuantity` int NOT NULL DEFAULT 0,
	`unitPrice` int,
	`lastRestocked` timestamp,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `inventory_id` PRIMARY KEY(`id`)
);
