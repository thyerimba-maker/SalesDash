import { drizzle } from 'drizzle-orm/mysql2';
import { appUsers } from '../drizzle/schema.js';
import { eq } from 'drizzle-orm';
import bcrypt from 'bcrypt';
import 'dotenv/config';

const SALT_ROUNDS = 10;

async function initAdmin() {
  if (!process.env.DATABASE_URL) {
    throw new Error('DATABASE_URL environment variable is not set');
  }
  const db = drizzle(process.env.DATABASE_URL);
  
  // Check if admin already exists
  const existing = await db
    .select()
    .from(appUsers)
    .where(eq(appUsers.username, 'admin'))
    .limit(1);
  
  if (existing.length > 0) {
    console.log('✓ Admin user already exists');
    return;
  }
  
  // Hash password
  const passwordHash = await bcrypt.hash('admin123', SALT_ROUNDS);
  
  // Create admin user
  await db.insert(appUsers).values({
    username: 'admin',
    passwordHash,
    status: 'active',
  });
  
  console.log('✓ Admin user created successfully');
  console.log('  Username: admin');
  console.log('  Password: admin123');
}

initAdmin()
  .then(() => process.exit(0))
  .catch(err => {
    console.error('Error:', err.message);
    process.exit(1);
  });
