import { getDb } from '../server/db.ts';
import { cashRegister, leadHistory } from '../drizzle/schema.ts';

async function clearData() {
  const db = await getDb();
  if (!db) {
    console.error('Database not available');
    process.exit(1);
  }

  try {
    // Delete all cash register records
    await db.delete(cashRegister);
    console.log('✅ Caixa zerado - todos os registros deletados');

    // Delete all lead history records
    await db.delete(leadHistory);
    console.log('✅ Histórico zerado - todos os registros deletados');

    console.log('\n✅ Dados limpos com sucesso!');
    process.exit(0);
  } catch (error) {
    console.error('❌ Erro ao limpar dados:', error);
    process.exit(1);
  }
}

clearData();
