import { getDb } from '../server/db.ts';
import { leads, cashRegister, leadHistory } from '../drizzle/schema.ts';
import { eq } from 'drizzle-orm';

async function restoreLeads() {
  const db = await getDb();
  if (!db) {
    console.error('Database not available');
    process.exit(1);
  }

  try {
    // Get all closed leads
    const closedLeads = await db.select().from(leads).where(
      (lead) => lead.status === 'venda_feita' || lead.status === 'venda_perdida'
    );

    console.log(`Found ${closedLeads.length} closed leads to restore`);

    // Restore each closed lead to "confirmado" status
    for (const lead of closedLeads) {
      await db.update(leads).set({
        status: 'confirmado',
        closureReason: null,
        closureDate: null,
        followUpDate: null,
      }).where(eq(leads.id, lead.id));
      console.log(`✅ Restored lead: ${lead.name}`);
    }

    // Delete all cash register records
    await db.delete(cashRegister);
    console.log('✅ Caixa zerado - todos os registros deletados');

    // Delete all lead history records
    await db.delete(leadHistory);
    console.log('✅ Histórico zerado - todos os registros deletados');

    console.log('\n✅ Dados restaurados com sucesso!');
    process.exit(0);
  } catch (error) {
    console.error('❌ Erro ao restaurar dados:', error);
    process.exit(1);
  }
}

restoreLeads();
