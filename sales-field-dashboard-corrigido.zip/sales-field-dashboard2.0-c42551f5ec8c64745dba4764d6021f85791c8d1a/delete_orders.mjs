import { getDb } from './server/_core/index.ts';
import { orders } from './drizzle/schema.ts';
import { sql } from 'drizzle-orm';

async function deleteAllOrders() {
  const db = await getDb();
  if (!db) {
    console.error('Database not available');
    process.exit(1);
  }

  try {
    const result = await db.delete(orders);
    console.log('✅ Todos os pedidos foram deletados com sucesso!');
    process.exit(0);
  } catch (error) {
    console.error('❌ Erro ao deletar pedidos:', error);
    process.exit(1);
  }
}

deleteAllOrders();
