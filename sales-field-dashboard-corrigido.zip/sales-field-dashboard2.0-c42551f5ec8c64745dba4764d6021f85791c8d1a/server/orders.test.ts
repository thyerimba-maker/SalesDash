import { describe, expect, it } from "vitest";
import { appRouter } from "./routers";
import type { TrpcContext } from "./_core/context";

type AuthenticatedUser = NonNullable<TrpcContext["user"]>;

function createAuthContext(): TrpcContext {
  const user: AuthenticatedUser = {
    id: 1,
    openId: "test-user",
    email: "test@example.com",
    name: "Test User",
    loginMethod: "manus",
    role: "user",
    createdAt: new Date(),
    updatedAt: new Date(),
    lastSignedIn: new Date(),
  };

  const ctx: TrpcContext = {
    user,
    req: {
      protocol: "https",
      headers: {},
    } as TrpcContext["req"],
    res: {
      clearCookie: () => {},
    } as TrpcContext["res"],
  };

  return ctx;
}

describe("orders.create", () => {
  it("should create a new order with all fields", async () => {
    const ctx = createAuthContext();
    const caller = appRouter.createCaller(ctx);

    const result = await caller.orders.create({
      customerName: "João Silva",
      customerPhone: "69999999999",
      description: "Camiseta azul tamanho M",
      totalAmount: 89.9,
      customizationName: "João",
      customizationNumber: "123",
    });

    expect(result).toBeDefined();
    expect(result[0]).toBeDefined(); // Insert returns array with insertId
  });

  it("should create order without customization fields", async () => {
    const ctx = createAuthContext();
    const caller = appRouter.createCaller(ctx);

    const result = await caller.orders.create({
      customerName: "Maria Santos",
      customerPhone: "69988888888",
      description: "Calça preta tamanho 40",
      totalAmount: 129.9,
    });

    expect(result).toBeDefined();
    expect(result[0]).toBeDefined();
  });
});

describe("orders.listActive", () => {
  it("should list all active orders", async () => {
    const ctx = createAuthContext();
    const caller = appRouter.createCaller(ctx);

    // Create two orders
    await caller.orders.create({
      customerName: "Order 1",
      customerPhone: "69911111111",
      description: "Product 1",
      totalAmount: 50,
    });

    await caller.orders.create({
      customerName: "Order 2",
      customerPhone: "69922222222",
      description: "Product 2",
      totalAmount: 75,
    });

    const result = await caller.orders.listActive();

    expect(result).toBeDefined();
    expect(Array.isArray(result)).toBe(true);
    expect(result.length).toBeGreaterThanOrEqual(0);
  });
});

describe("orders.listAll", () => {
  it("should list all orders including completed", async () => {
    const ctx = createAuthContext();
    const caller = appRouter.createCaller(ctx);

    const result = await caller.orders.listAll();

    expect(result).toBeDefined();
    expect(Array.isArray(result)).toBe(true);
  });
});

describe("orders.listCompleted", () => {
  it("should list completed orders", async () => {
    const ctx = createAuthContext();
    const caller = appRouter.createCaller(ctx);

    const result = await caller.orders.listCompleted();

    expect(result).toBeDefined();
    expect(Array.isArray(result)).toBe(true);
  });
});

describe("orders.updateStatus", () => {
  it("should update order status", async () => {
    const ctx = createAuthContext();
    const caller = appRouter.createCaller(ctx);

    // Create order
    await caller.orders.create({
      customerName: "Test Order",
      customerPhone: "69933333333",
      description: "Test Product",
      totalAmount: 99.9,
    });

    // Get the created order
    const allOrders = await caller.orders.listAll();
    const order = allOrders[allOrders.length - 1]; // Get the last created order

    if (!order) {
      throw new Error("Order not found");
    }

    // Update status
    const updated = await caller.orders.updateStatus({
      id: order.id,
      status: "confirmado",
    });

    expect(updated).toBeDefined();
  });
});

describe("orders.updateNotes", () => {
  it("should update order notes", async () => {
    const ctx = createAuthContext();
    const caller = appRouter.createCaller(ctx);

    // Create order
    await caller.orders.create({
      customerName: "Test Order",
      customerPhone: "69944444444",
      description: "Test Product",
      totalAmount: 99.9,
    });

    // Get the created order
    const allOrders = await caller.orders.listAll();
    const order = allOrders[allOrders.length - 1];

    if (!order) {
      throw new Error("Order not found");
    }

    // Update notes
    const updated = await caller.orders.updateNotes({
      id: order.id,
      notes: "Cliente preferiu entrega na segunda-feira",
    });

    expect(updated).toBeDefined();
  });
});

describe("orders.updateCustomization", () => {
  it("should update customization fields", async () => {
    const ctx = createAuthContext();
    const caller = appRouter.createCaller(ctx);

    // Create order
    await caller.orders.create({
      customerName: "Test Order",
      customerPhone: "69955555555",
      description: "Test Product",
      totalAmount: 99.9,
    });

    // Get the created order
    const allOrders = await caller.orders.listAll();
    const order = allOrders[allOrders.length - 1];

    if (!order) {
      throw new Error("Order not found");
    }

    // Update customization
    const updated = await caller.orders.updateCustomization({
      id: order.id,
      customizationName: "João",
      customizationNumber: "M",
    });

    expect(updated).toBeDefined();
  });
});

describe("orders.update", () => {
  it("should update all order fields", async () => {
    const ctx = createAuthContext();
    const caller = appRouter.createCaller(ctx);

    // Create order
    await caller.orders.create({
      customerName: "Original Name",
      customerPhone: "69956666666",
      description: "Original Description",
      totalAmount: 50,
    });

    // Get the created order
    const allOrders = await caller.orders.listAll();
    const order = allOrders[allOrders.length - 1];

    if (!order) {
      throw new Error("Order not found");
    }

    // Update all fields
    const updated = await caller.orders.update({
      id: order.id,
      customerName: "Updated Name",
      description: "Updated Description",
      totalAmount: 150,
      notes: "Order updated successfully",
    });

    expect(updated).toBeDefined();
  });
});

describe("orders.cancel", () => {
  it("should cancel an order", async () => {
    const ctx = createAuthContext();
    const caller = appRouter.createCaller(ctx);

    // Create order
    await caller.orders.create({
      customerName: "Order to Cancel",
      customerPhone: "69966666666",
      description: "Test Product",
      totalAmount: 99.9,
    });

    // Get the created order
    const allOrders = await caller.orders.listAll();
    const order = allOrders[allOrders.length - 1];

    if (!order) {
      throw new Error("Order not found");
    }

    // Cancel order
    const result = await caller.orders.cancel({ id: order.id });

    expect(result).toBeDefined();
  });
});

describe("orders.getStats", () => {
  it("should return order statistics", async () => {
    const ctx = createAuthContext();
    const caller = appRouter.createCaller(ctx);

    // Create multiple orders
    await caller.orders.create({
      customerName: "Order 1",
      customerPhone: "69977777777",
      description: "Product 1",
      totalAmount: 100,
    });

    await caller.orders.create({
      customerName: "Order 2",
      customerPhone: "69988888888",
      description: "Product 2",
      totalAmount: 200,
    });

    const stats = await caller.orders.getStats();

    expect(stats).toBeDefined();
    expect(stats.totalOrders).toBeGreaterThanOrEqual(0);
    expect(stats.totalRevenue).toBeGreaterThanOrEqual(0);
  });
});

describe("orders.get", () => {
  it("should retrieve a single order", async () => {
    const ctx = createAuthContext();
    const caller = appRouter.createCaller(ctx);

    // Create order
    await caller.orders.create({
      customerName: "Test Customer",
      customerPhone: "69999999999",
      description: "Test Product",
      totalAmount: 99.9,
    });

    // Get all orders to find the created one
    const allOrders = await caller.orders.listAll();
    const order = allOrders[allOrders.length - 1];

    if (!order) {
      throw new Error("Order not found");
    }

    // Get single order
    const retrieved = await caller.orders.get({ id: order.id });

    expect(retrieved).toBeDefined();
    expect(retrieved.id).toBe(order.id);
  });
});
