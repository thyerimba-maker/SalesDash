import { eq, and, gte, lte, desc } from "drizzle-orm";
import { tasks, auditLogs, leadScores, webhooks, leads } from "../drizzle/schema";
import { getDb } from "./db";

/**
 * TASKS MANAGEMENT
 */
export async function createTask(data: {
  leadId?: number;
  assignedTo: number;
  assignedBy: number;
  title: string;
  description?: string;
  priority: "low" | "normal" | "high" | "urgent";
  dueDate: Date;
}) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  const result = await db.insert(tasks).values({
    ...data,
    status: "pending",
  });
  return result;
}

export async function getTasksByUser(userId: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  return db
    .select()
    .from(tasks)
    .where(and(eq(tasks.assignedTo, userId), eq(tasks.status, "pending")))
    .orderBy(desc(tasks.priority), tasks.dueDate);
}

export async function updateTaskStatus(
  taskId: number,
  status: "pending" | "in_progress" | "completed" | "cancelled"
) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  const updateData: any = { status };
  if (status === "completed") {
    updateData.completedAt = new Date();
  }

  return db.update(tasks).set(updateData).where(eq(tasks.id, taskId));
}

/**
 * AUDIT LOGS
 */
export async function logAction(data: {
  userId: number;
  action: string;
  entityType: string;
  entityId?: number;
  details?: string;
  ipAddress?: string;
}) {
  const db = await getDb();
  if (!db) {
    console.warn("Database not available for audit log");
    return;
  }

  try {
    await db.insert(auditLogs).values(data);
  } catch (error) {
    console.error("Failed to log action:", error);
  }
}

export async function getAuditLogs(userId?: number, limit = 100) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  if (userId) {
    return db
      .select()
      .from(auditLogs)
      .where(eq(auditLogs.userId, userId))
      .orderBy(desc(auditLogs.createdAt))
      .limit(limit);
  }

  return db
    .select()
    .from(auditLogs)
    .orderBy(desc(auditLogs.createdAt))
    .limit(limit);
}

/**
 * LEAD SCORING
 */
export async function calculateLeadScore(leadId: number): Promise<number> {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  // Get lead data
  const lead = await db
    .select()
    .from(leads)
    .where(eq(leads.id, leadId))
    .limit(1);

  if (!lead || lead.length === 0) return 0;

  const leadData = lead[0];
  let score = 0;
  const factors: Record<string, number> = {};

  // Factor 1: Lead age (0-20 points)
  // Newer leads score higher
  const ageInDays = Math.floor(
    (Date.now() - leadData.createdAt.getTime()) / (1000 * 60 * 60 * 24)
  );
  const ageFactor = Math.max(0, 20 - ageInDays * 0.5);
  score += ageFactor;
  factors.age = ageFactor;

  // Factor 2: Contact frequency (0-25 points)
  // More recent contact = higher score
  if (leadData.lastContact) {
    const daysSinceContact = Math.floor(
      (Date.now() - leadData.lastContact.getTime()) / (1000 * 60 * 60 * 24)
    );
    const contactFactor = Math.max(0, 25 - daysSinceContact * 2);
    score += contactFactor;
    factors.contact = contactFactor;
  }

  // Factor 3: Status progression (0-30 points)
  const statusScores: Record<string, number> = {
    leads: 5,
    atendimento: 10,
    aguardando: 15,
    confirmado: 20,
    em_rota: 25,
    concluido: 30,
    venda_feita: 100, // Already converted
    venda_perdida: 0,
  };
  const statusFactor = statusScores[leadData.status] || 0;
  score += statusFactor;
  factors.status = statusFactor;

  // Factor 4: Sale amount (0-25 points)
  // Higher value leads score higher
  if (leadData.saleAmount) {
    const amountFactor = Math.min(25, (leadData.saleAmount / 10000) * 25);
    score += amountFactor;
    factors.amount = amountFactor;
  }

  // Normalize to 0-100
  score = Math.min(100, score);

  // Save score
  await db
    .insert(leadScores)
    .values({
      leadId,
      score: Math.round(score),
      conversionProbability: Math.round(score * 0.8), // Conversion probability is 80% of score
      factors: JSON.stringify(factors),
    })
    .onDuplicateKeyUpdate({
      set: {
        score: Math.round(score),
        conversionProbability: Math.round(score * 0.8),
        factors: JSON.stringify(factors),
      },
    });

  return Math.round(score);
}

export async function getLeadScore(leadId: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  const result = await db
    .select()
    .from(leadScores)
    .where(eq(leadScores.leadId, leadId))
    .limit(1);

  return result[0] || null;
}

export async function getTopLeadsByScore(userId: number, limit = 10) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  return db
    .select({
      lead: leads,
      score: leadScores.score,
      probability: leadScores.conversionProbability,
    })
    .from(leads)
    .innerJoin(leadScores, eq(leads.id, leadScores.leadId))
    .where(
      and(
        eq(leads.userId, userId),
        eq(leads.status, "leads") // Only active leads
      )
    )
    .orderBy(desc(leadScores.score))
    .limit(limit);
}

/**
 * WEBHOOKS
 */
export async function createWebhook(data: {
  userId: number;
  name: string;
  url: string;
  events: string;
  secret: string;
}) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  return db.insert(webhooks).values({
    ...data,
    isActive: 1,
  });
}

export async function getWebhooks(userId: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  return db
    .select()
    .from(webhooks)
    .where(and(eq(webhooks.userId, userId), eq(webhooks.isActive, 1)));
}

export async function triggerWebhook(
  event: string,
  data: Record<string, any>,
  userId: number
) {
  const db = await getDb();
  if (!db) return;

  try {
    const userWebhooks = await getWebhooks(userId);

    for (const webhook of userWebhooks) {
      const events = webhook.events.split(",");
      if (!events.includes(event)) continue;

      // Create HMAC signature
      const crypto = await import("crypto");
      const signature = crypto
        .createHmac("sha256", webhook.secret)
        .update(JSON.stringify(data))
        .digest("hex");

      // Send webhook
      fetch(webhook.url, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "X-Webhook-Signature": signature,
          "X-Webhook-Event": event,
        },
        body: JSON.stringify(data),
      }).catch((error) => console.error("Webhook delivery failed:", error));
    }
  } catch (error) {
    console.error("Failed to trigger webhooks:", error);
  }
}
