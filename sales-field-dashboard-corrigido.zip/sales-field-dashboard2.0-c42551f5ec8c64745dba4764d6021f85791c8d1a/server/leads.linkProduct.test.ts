import { describe, it, expect, beforeAll, afterAll } from 'vitest';
import { getDb } from './db';
import { leads, leadProducts, inventory, appUsers } from '../drizzle/schema';
import { eq } from 'drizzle-orm';

describe('Product Linking with Real-time Updates', () => {
  let db: any;
  let testUserId: number;
  let testLeadId: number;
  let testProductId: number;

  beforeAll(async () => {
    db = await getDb();
    
    // Create test user
    const userResult = await db.insert(appUsers).values({
      username: `test_user_${Date.now()}`,
      passwordHash: 'test_hash',
      status: 'active',
    });
    testUserId = userResult[0].insertId;

    // Create test lead
    const leadResult = await db.insert(leads).values({
      userId: testUserId,
      name: 'Test Lead',
      phone: '11999999999',
      product: 'Test Product',
      status: 'leads',
    });
    testLeadId = leadResult[0].insertId;

    // Create test inventory product
    const inventoryResult = await db.insert(inventory).values({
      userId: testUserId,
      productName: 'Test Inventory Product',
      sizeP: 5,
      sizeM: 10,
      sizeG: 8,
      sizeGG: 3,
      totalQuantity: 26,
      unitPrice: 10000, // R$ 100.00
      imageUrl: 'https://example.com/product.jpg',
      status: 'ativo',
    });
    testProductId = inventoryResult[0].insertId;
  });

  afterAll(async () => {
    // Cleanup
    if (testLeadId) {
      await db.delete(leadProducts).where(eq(leadProducts.leadId, testLeadId));
      await db.delete(leads).where(eq(leads.id, testLeadId));
    }
    if (testProductId) {
      await db.delete(inventory).where(eq(inventory.id, testProductId));
    }
    if (testUserId) {
      await db.delete(appUsers).where(eq(appUsers.id, testUserId));
    }
  });

  it('should link product to lead with imageUrl', async () => {
    const linkedProduct = await db
      .insert(leadProducts)
      .values({
        leadId: testLeadId,
        userId: testUserId,
        productName: 'Test Inventory Product',
        sizeP: 2,
        sizeM: 1,
        sizeG: 0,
        sizeGG: 0,
        totalQuantity: 3,
        unitPrice: 10000,
        imageUrl: 'https://example.com/product.jpg',
        status: 'pendente',
      });

    expect(linkedProduct).toBeDefined();
    expect(linkedProduct[0].insertId).toBeGreaterThan(0);

    // Verify the linked product was created
    const result = await db
      .select()
      .from(leadProducts)
      .where(eq(leadProducts.id, linkedProduct[0].insertId));

    expect(result).toHaveLength(1);
    expect(result[0].productName).toBe('Test Inventory Product');
    expect(result[0].imageUrl).toBe('https://example.com/product.jpg');
    expect(result[0].totalQuantity).toBe(3);
    expect(result[0].sizeP).toBe(2);
    expect(result[0].sizeM).toBe(1);
  });

  it('should retrieve linked products with imageUrl', async () => {
    // Link a product
    await db.insert(leadProducts).values({
      leadId: testLeadId,
      userId: testUserId,
      productName: 'Product with Image',
      sizeP: 1,
      sizeM: 2,
      sizeG: 3,
      sizeGG: 4,
      totalQuantity: 10,
      unitPrice: 15000,
      imageUrl: 'https://example.com/image.jpg',
      status: 'pendente',
    });

    // Retrieve all linked products for the lead
    const linkedProducts = await db
      .select()
      .from(leadProducts)
      .where(eq(leadProducts.leadId, testLeadId));

    expect(linkedProducts.length).toBeGreaterThan(0);
    
    // Check that imageUrl is present
    const productWithImage = linkedProducts.find(p => p.imageUrl === 'https://example.com/image.jpg');
    expect(productWithImage).toBeDefined();
    expect(productWithImage?.imageUrl).toBe('https://example.com/image.jpg');
  });

  it('should handle optional imageUrl field', async () => {
    // Link product without imageUrl
    const linkedProduct = await db
      .insert(leadProducts)
      .values({
        leadId: testLeadId,
        userId: testUserId,
        productName: 'Product without Image',
        sizeP: 1,
        sizeM: 0,
        sizeG: 0,
        sizeGG: 0,
        totalQuantity: 1,
        unitPrice: 5000,
        status: 'pendente',
      });

    expect(linkedProduct).toBeDefined();

    // Verify imageUrl is null
    const result = await db
      .select()
      .from(leadProducts)
      .where(eq(leadProducts.id, linkedProduct[0].insertId));

    expect(result[0].imageUrl).toBeNull();
  });

  it('should update product imageUrl', async () => {
    // Create a linked product
    const linkedProduct = await db
      .insert(leadProducts)
      .values({
        leadId: testLeadId,
        userId: testUserId,
        productName: 'Product to Update',
        sizeP: 1,
        sizeM: 1,
        sizeG: 1,
        sizeGG: 1,
        totalQuantity: 4,
        unitPrice: 8000,
        imageUrl: 'https://example.com/old-image.jpg',
        status: 'pendente',
      });

    const productId = linkedProduct[0].insertId;

    // Update imageUrl
    await db
      .update(leadProducts)
      .set({ imageUrl: 'https://example.com/new-image.jpg' })
      .where(eq(leadProducts.id, productId));

    // Verify update
    const result = await db
      .select()
      .from(leadProducts)
      .where(eq(leadProducts.id, productId));

    expect(result[0].imageUrl).toBe('https://example.com/new-image.jpg');
  });

  it('should preserve all product fields when linking', async () => {
    const linkedProduct = await db
      .insert(leadProducts)
      .values({
        leadId: testLeadId,
        userId: testUserId,
        productName: 'Complete Product',
        description: 'Product Description',
        sizeP: 5,
        sizeM: 4,
        sizeG: 3,
        sizeGG: 2,
        totalQuantity: 14,
        unitPrice: 20000,
        imageUrl: 'https://example.com/complete.jpg',
        status: 'confirmado',
        notes: 'Test notes',
      });

    const result = await db
      .select()
      .from(leadProducts)
      .where(eq(leadProducts.id, linkedProduct[0].insertId));

    expect(result[0]).toMatchObject({
      productName: 'Complete Product',
      description: 'Product Description',
      sizeP: 5,
      sizeM: 4,
      sizeG: 3,
      sizeGG: 2,
      totalQuantity: 14,
      unitPrice: 20000,
      imageUrl: 'https://example.com/complete.jpg',
      status: 'confirmado',
      notes: 'Test notes',
    });
  });
});
