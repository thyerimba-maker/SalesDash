import { describe, it, expect, beforeEach, vi } from 'vitest';
import * as db from './db';
import { createUserBackup, exportBackupAsJSON, exportBackupAsCSV, calculateBackupStats } from './backup';

// Mock database functions
vi.mock('./db', () => ({
  getUserLeads: vi.fn(),
  getUserSales: vi.fn(),
  getLeadContactHistory: vi.fn(),
  createLead: vi.fn(),
  updateLead: vi.fn(),
  deleteLead: vi.fn(),
}));

describe('Leads API', () => {
  const mockUserId = 1;

  describe('Lead Management', () => {
    it('should create a new lead with valid data', async () => {
      const leadData = {
        name: 'João Silva',
        phone: '(11) 99999-1111',
        product: 'Produto Premium',
        source: 'direto',
      };

      vi.mocked(db.createLead).mockResolvedValueOnce({ insertId: 1 } as any);

      const result = await db.createLead(mockUserId, leadData);
      expect(result).toBeDefined();
      expect(vi.mocked(db.createLead)).toHaveBeenCalledWith(mockUserId, leadData);
    });

    it('should retrieve user leads', async () => {
      const mockLeads = [
        {
          id: 1,
          userId: mockUserId,
          name: 'João Silva',
          phone: '(11) 99999-1111',
          status: 'leads' as const,
          product: 'Produto Premium',
          createdAt: new Date(),
          updatedAt: new Date(),
          email: 'joao@example.com',
          source: 'direto',
          notes: null,
          lastContact: null,
        },
      ];

      vi.mocked(db.getUserLeads).mockResolvedValueOnce(mockLeads);

      const result = await db.getUserLeads(mockUserId);
      expect(result).toEqual(mockLeads);
      expect(result).toHaveLength(1);
      expect(result[0].name).toBe('João Silva');
    });

    it('should update lead status', async () => {
      const leadId = 1;
      const updateData = { status: 'confirmado' as const };

      vi.mocked(db.updateLead).mockResolvedValueOnce({} as any);

      await db.updateLead(leadId, mockUserId, updateData);
      expect(vi.mocked(db.updateLead)).toHaveBeenCalledWith(leadId, mockUserId, updateData);
    });

    it('should delete a lead', async () => {
      const leadId = 1;

      vi.mocked(db.deleteLead).mockResolvedValueOnce({} as any);

      await db.deleteLead(leadId, mockUserId);
      expect(vi.mocked(db.deleteLead)).toHaveBeenCalledWith(leadId, mockUserId);
    });
  });

  describe('Backup and Export', () => {
    beforeEach(() => {
      vi.clearAllMocks();
    });

    it('should create a backup with all user data', async () => {
      const mockLeads = [
        {
          id: 1,
          userId: mockUserId,
          name: 'João Silva',
          phone: '(11) 99999-1111',
          status: 'leads' as const,
          product: 'Produto Premium',
          createdAt: new Date(),
          updatedAt: new Date(),
          email: 'joao@example.com',
          source: 'direto',
          notes: null,
          lastContact: null,
        },
      ];

      const mockSales = [
        {
          id: 1,
          userId: mockUserId,
          leadId: 1,
          amount: 50000,
          product: 'Produto Premium',
          createdAt: new Date(),
          updatedAt: new Date(),
          paymentMethod: 'cartao',
          notes: null,
        },
      ];

      const mockHistory: any[] = [];

      vi.mocked(db.getUserLeads).mockResolvedValueOnce(mockLeads);
      vi.mocked(db.getUserSales).mockResolvedValueOnce(mockSales);
      vi.mocked(db.getLeadContactHistory).mockResolvedValueOnce(mockHistory);

      const backup = await createUserBackup(mockUserId);

      expect(backup).toBeDefined();
      expect(backup.leads).toHaveLength(1);
      expect(backup.sales).toHaveLength(1);
      expect(backup.metadata.totalLeads).toBe(1);
      expect(backup.metadata.totalSales).toBe(1);
    });

    it('should export backup as JSON', async () => {
      const mockBackup = {
        timestamp: new Date().toISOString(),
        leads: [],
        sales: [],
        contactHistory: [],
        metadata: {
          totalLeads: 0,
          totalSales: 0,
          totalContacts: 0,
          exportDate: new Date().toLocaleDateString('pt-BR'),
        },
      };

      const json = exportBackupAsJSON(mockBackup);
      expect(json).toBeDefined();
      expect(typeof json).toBe('string');

      const parsed = JSON.parse(json);
      expect(parsed.metadata).toBeDefined();
      expect(parsed.leads).toEqual([]);
    });

    it('should export backup as CSV', async () => {
      const mockBackup = {
        timestamp: new Date().toISOString(),
        leads: [
          {
            id: 1,
            userId: mockUserId,
            name: 'João Silva',
            phone: '(11) 99999-1111',
            status: 'leads' as const,
            product: 'Produto Premium',
            createdAt: new Date(),
            updatedAt: new Date(),
            email: 'joao@example.com',
            source: 'direto',
            notes: null,
            lastContact: null,
          },
        ],
        sales: [],
        contactHistory: [],
        metadata: {
          totalLeads: 1,
          totalSales: 0,
          totalContacts: 0,
          exportDate: new Date().toLocaleDateString('pt-BR'),
        },
      };

      const csv = exportBackupAsCSV(mockBackup);
      expect(csv).toBeDefined();
      expect(typeof csv).toBe('string');
      expect(csv).toContain('BACKUP DE VENDAS');
      expect(csv).toContain('João Silva');
    });

    it('should calculate backup statistics', async () => {
      const mockBackup = {
        timestamp: new Date().toISOString(),
        leads: [
          {
            id: 1,
            userId: mockUserId,
            name: 'João Silva',
            phone: '(11) 99999-1111',
            status: 'concluido' as const,
            product: 'Produto Premium',
            createdAt: new Date(),
            updatedAt: new Date(),
            email: 'joao@example.com',
            source: 'direto',
            notes: null,
            lastContact: null,
          },
        ],
        sales: [
          {
            id: 1,
            userId: mockUserId,
            leadId: 1,
            amount: 100000, // R$ 1.000,00
            product: 'Produto Premium',
            createdAt: new Date(),
            updatedAt: new Date(),
            paymentMethod: 'cartao',
            notes: null,
          },
        ],
        contactHistory: [],
        metadata: {
          totalLeads: 1,
          totalSales: 1,
          totalContacts: 0,
          exportDate: new Date().toLocaleDateString('pt-BR'),
        },
      };

      const stats = calculateBackupStats(mockBackup);

      expect(stats).toBeDefined();
      expect(stats.totalRevenue).toBe('1000.00');
      expect(stats.conversionRate).toBe('100.0');
      expect(stats.leadsByStatus.concluido).toBe(1);
    });
  });
});

describe('Lead Editing Features', () => {
  const mockUserId = 1;

  describe('Update lead information', () => {
    it('should update lead name', async () => {
      const leadId = 1;
      const updateData = { name: 'João Silva Updated' };

      vi.mocked(db.updateLead).mockResolvedValueOnce({} as any);

      await db.updateLead(leadId, mockUserId, updateData);
      expect(vi.mocked(db.updateLead)).toHaveBeenCalledWith(leadId, mockUserId, updateData);
    });

    it('should update lead phone', async () => {
      const leadId = 1;
      const updateData = { phone: '(11) 98888-2222' };

      vi.mocked(db.updateLead).mockResolvedValueOnce({} as any);

      await db.updateLead(leadId, mockUserId, updateData);
      expect(vi.mocked(db.updateLead)).toHaveBeenCalledWith(leadId, mockUserId, updateData);
    });

    it('should update lead email', async () => {
      const leadId = 1;
      const updateData = { email: 'newemail@example.com' };

      vi.mocked(db.updateLead).mockResolvedValueOnce({} as any);

      await db.updateLead(leadId, mockUserId, updateData);
      expect(vi.mocked(db.updateLead)).toHaveBeenCalledWith(leadId, mockUserId, updateData);
    });

    it('should update lead product', async () => {
      const leadId = 1;
      const updateData = { product: 'Novo Produto' };

      vi.mocked(db.updateLead).mockResolvedValueOnce({} as any);

      await db.updateLead(leadId, mockUserId, updateData);
      expect(vi.mocked(db.updateLead)).toHaveBeenCalledWith(leadId, mockUserId, updateData);
    });

    it('should update multiple lead fields at once', async () => {
      const leadId = 1;
      const updateData = {
        name: 'João Silva Updated',
        phone: '(11) 98888-2222',
        email: 'newemail@example.com',
        product: 'Novo Produto',
      };

      vi.mocked(db.updateLead).mockResolvedValueOnce({} as any);

      await db.updateLead(leadId, mockUserId, updateData);
      expect(vi.mocked(db.updateLead)).toHaveBeenCalledWith(leadId, mockUserId, updateData);
    });
  });

  describe('Lead notes editing', () => {
    it('should add notes to a lead', async () => {
      const leadId = 1;
      const updateData = { notes: 'Cliente interessado em promoção' };

      vi.mocked(db.updateLead).mockResolvedValueOnce({} as any);

      await db.updateLead(leadId, mockUserId, updateData);
      expect(vi.mocked(db.updateLead)).toHaveBeenCalledWith(leadId, mockUserId, updateData);
    });

    it('should update existing notes', async () => {
      const leadId = 1;
      const updateData = { notes: 'Cliente ligou - agendou para segunda' };

      vi.mocked(db.updateLead).mockResolvedValueOnce({} as any);

      await db.updateLead(leadId, mockUserId, updateData);
      expect(vi.mocked(db.updateLead)).toHaveBeenCalledWith(leadId, mockUserId, updateData);
    });

    it('should clear notes from a lead', async () => {
      const leadId = 1;
      const updateData = { notes: '' };

      vi.mocked(db.updateLead).mockResolvedValueOnce({} as any);

      await db.updateLead(leadId, mockUserId, updateData);
      expect(vi.mocked(db.updateLead)).toHaveBeenCalledWith(leadId, mockUserId, updateData);
    });

    it('should update lead information and notes together', async () => {
      const leadId = 1;
      const updateData = {
        name: 'João Silva',
        phone: '(11) 98888-2222',
        notes: 'Cliente confirmou interesse',
      };

      vi.mocked(db.updateLead).mockResolvedValueOnce({} as any);

      await db.updateLead(leadId, mockUserId, updateData);
      expect(vi.mocked(db.updateLead)).toHaveBeenCalledWith(leadId, mockUserId, updateData);
    });
  });
});
