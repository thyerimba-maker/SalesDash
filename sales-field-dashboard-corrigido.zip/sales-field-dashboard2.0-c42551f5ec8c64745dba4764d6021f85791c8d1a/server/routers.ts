import { COOKIE_NAME } from "@shared/const";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { publicProcedure, router, protectedProcedure } from "./_core/trpc";
import { z } from "zod";
import * as db from "./db";
import { createUserBackup, exportBackupAsJSON, exportBackupAsCSV, calculateBackupStats } from "./backup";
import { crmRouter } from "./crm-routers";
import { ordersRouter } from "./orders-routers";
import { authRouter } from "./routers/auth";

export const appRouter = router({
    // if you need to use socket.io, read and register route in server/_core/index.ts, all api should start with '/api/' so that the gateway can route correctly
  system: systemRouter,
  auth: authRouter,
  oauthAuth: router({
    me: publicProcedure.query(opts => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return {
        success: true,
      } as const;
    }),
  }),

  leads: router({
    list: protectedProcedure.query(({ ctx }) => db.getUserLeads(ctx.user.id)),
    create: protectedProcedure
      .input(z.object({
        name: z.string().min(1),
        phone: z.string().min(1),
        email: z.string().email().optional(),
        product: z.string().min(1),
        source: z.string().optional(),
        notes: z.string().optional(),
      }))
      .mutation(({ ctx, input }) => db.createLead(ctx.user.id, input)),
    get: protectedProcedure
      .input(z.object({ id: z.number() }))
      .query(({ ctx, input }) => db.getLead(input.id, ctx.user.id)),
    update: protectedProcedure
      .input(z.object({
        id: z.number(),
        name: z.string().optional(),
        phone: z.string().optional(),
        email: z.string().email().optional(),
        product: z.string().optional(),
        status: z.enum(["leads", "atendimento", "aguardando", "confirmado", "em_rota", "concluido", "venda_feita", "venda_perdida"]).optional(),
        notes: z.string().optional(),
        lastContact: z.date().optional(),
      }))
      .mutation(({ ctx, input }) => {
        const { id, ...data } = input;
        return db.updateLead(id, ctx.user.id, data);
      }),
    delete: protectedProcedure
      .input(z.object({ id: z.number() }))
      .mutation(({ ctx, input }) => db.deleteLead(input.id, ctx.user.id)),
    close: protectedProcedure
      .input(z.object({
        id: z.number(),
        status: z.enum(["venda_feita", "venda_perdida"]),
        reason: z.string().min(1),
        followUpDate: z.date().optional(),
        saleAmount: z.number().optional(),
      }))
      .mutation(({ ctx, input }) => db.closeLead(input.id, ctx.user.id, input.status, input.reason, input.followUpDate, input.saleAmount)),
    getClosed: protectedProcedure.query(({ ctx }) => db.getClosedLeads(ctx.user.id)),
    getFollowUp: protectedProcedure.query(({ ctx }) => db.getFollowUpLeads(ctx.user.id)),
    getMonthlySales: protectedProcedure
      .input(z.object({
        year: z.number().optional(),
        month: z.number().optional(),
      }))
      .query(({ ctx, input }) => db.getMonthlySales(ctx.user.id, input.year, input.month)),
    getMonthlySalesStats: protectedProcedure
      .input(z.object({
        year: z.number().optional(),
        month: z.number().optional(),
      }))
      .query(({ ctx, input }) => db.getMonthlySalesStats(ctx.user.id, input.year, input.month)),
    linkProduct: protectedProcedure
      .input(z.object({
        leadId: z.number(),
        productName: z.string(),
        description: z.string().optional(),
        sizeP: z.number().default(0),
        sizeM: z.number().default(0),
        sizeG: z.number().default(0),
        sizeGG: z.number().default(0),
        totalQuantity: z.number().default(0),
        unitPrice: z.number().optional(),
        imageUrl: z.string().optional(),
        status: z.enum(["pendente", "confirmado", "em_producao", "pronto", "entregue"]).default("pendente"),
        notes: z.string().optional(),
      }))
      .mutation(({ ctx, input }) => db.linkProductToLeadWithInventoryDeduction(input.leadId, ctx.user.id, input)),
    getProducts: protectedProcedure
      .input(z.object({ leadId: z.number() }))
      .query(({ input }) => db.getLeadProducts(input.leadId)),
    getLinkedProducts: protectedProcedure
      .input(z.object({ leadId: z.number() }))
      .query(({ input }) => db.getLeadProducts(input.leadId)),
    updateProduct: protectedProcedure
      .input(z.object({
        productId: z.number(),
        sizeP: z.number().optional(),
        sizeM: z.number().optional(),
        sizeG: z.number().optional(),
        sizeGG: z.number().optional(),
        totalQuantity: z.number().optional(),
        status: z.enum(["pendente", "confirmado", "em_producao", "pronto", "entregue"]).optional(),
        notes: z.string().optional(),
      }))
      .mutation(({ input }) => db.updateLeadProduct(input.productId, input)),
    deleteProduct: protectedProcedure
      .input(z.object({ productId: z.number(), leadId: z.number() }))
      .mutation(({ ctx, input }) => db.deleteLeadProduct(input.productId, input.leadId, ctx.user.id)),
    getHistory: protectedProcedure
      .input(z.object({ leadId: z.number() }))
      .query(({ input }) => db.getLeadActivityTimeline(input.leadId)),
    listWithProducts: protectedProcedure.query(({ ctx }) => db.getLeadsWithProducts(ctx.user.id)),
  }),

  sales: router({
    list: protectedProcedure.query(({ ctx }) => db.getUserSales(ctx.user.id)),
    create: protectedProcedure
      .input(z.object({
        leadId: z.number(),
        amount: z.number().positive(),
        product: z.string().min(1),
        paymentMethod: z.string().optional(),
        notes: z.string().optional(),
      }))
      .mutation(async ({ ctx, input }) => {
        const result = await db.createSale(ctx.user.id, input);
        await db.updateLead(input.leadId, ctx.user.id, { status: "concluido" });
        return result;
      }),
    getByDateRange: protectedProcedure
      .input(z.object({
        startDate: z.date(),
        endDate: z.date(),
      }))
      .query(({ ctx, input }) => db.getSalesByDateRange(ctx.user.id, input.startDate, input.endDate)),
  }),

  metrics: router({
    getDaily: protectedProcedure
      .input(z.object({ date: z.string() }))
      .query(({ ctx, input }) => db.getDailyMetrics(ctx.user.id, input.date)),
    getRange: protectedProcedure
      .input(z.object({
        startDate: z.string(),
        endDate: z.string(),
      }))
      .query(({ ctx, input }) => db.getUserMetricsRange(ctx.user.id, input.startDate, input.endDate)),
  }),

  contactHistory: router({
    getByLead: protectedProcedure
      .input(z.object({ leadId: z.number() }))
      .query(({ input }) => db.getLeadContactHistory(input.leadId)),
    create: protectedProcedure
      .input(z.object({
        leadId: z.number(),
        type: z.enum(["call", "whatsapp", "email", "meeting", "note"]),
        description: z.string().optional(),
        duration: z.number().optional(),
        outcome: z.string().optional(),
      }))
      .mutation(({ ctx, input }) => db.createContactHistory(ctx.user.id, input)),
  }),

  backup: router({
    createBackup: protectedProcedure.query(async ({ ctx }) => createUserBackup(ctx.user.id)),
    exportJSON: protectedProcedure.query(async ({ ctx }) => {
      const backup = await createUserBackup(ctx.user.id);
      return { data: exportBackupAsJSON(backup), filename: `backup_vendas_${new Date().toISOString().split('T')[0]}.json` };
    }),
    exportCSV: protectedProcedure.query(async ({ ctx }) => {
      const backup = await createUserBackup(ctx.user.id);
      return { data: exportBackupAsCSV(backup), filename: `backup_vendas_${new Date().toISOString().split('T')[0]}.csv` };
    }),
    getStats: protectedProcedure.query(async ({ ctx }) => {
      const backup = await createUserBackup(ctx.user.id);
      return calculateBackupStats(backup);
    }),
    exportInventoryCSV: protectedProcedure.query(async () => {
      const { exportInventoryAsCSV } = await import('./backup');
      return { data: await exportInventoryAsCSV(), filename: `backup_estoque_${new Date().toISOString().split('T')[0]}.csv` };
    }),
    exportInventoryJSON: protectedProcedure.query(async () => {
      const { exportInventoryAsJSON } = await import('./backup');
      return { data: await exportInventoryAsJSON(), filename: `backup_estoque_${new Date().toISOString().split('T')[0]}.json` };
    }),
  }),

    tasks: crmRouter.tasks,
  auditLogs: crmRouter.auditLogs,
  leadScoring: crmRouter.leadScoring,
  webhooks: crmRouter.webhooks,
  orders: ordersRouter,
  
  inventory: router({
    list: protectedProcedure.query(({ ctx }) => db.getUserInventory(ctx.user.id)),
    create: protectedProcedure
      .input(z.object({
        productName: z.string().min(1),
        description: z.string().optional(),
        sizeP: z.number().default(0),
        sizeM: z.number().default(0),
        sizeG: z.number().default(0),
        sizeGG: z.number().default(0),
        unitPrice: z.number().optional(),
        imageUrl: z.string().optional(),
      }))
      .mutation(({ ctx, input }) => db.createInventoryItem(ctx.user.id, input)),
    update: protectedProcedure
      .input(z.object({
        id: z.number(),
        productName: z.string().optional(),
        description: z.string().optional(),
        sizeP: z.number().optional(),
        sizeM: z.number().optional(),
        sizeG: z.number().optional(),
        sizeGG: z.number().optional(),
        unitPrice: z.number().optional(),
        imageUrl: z.string().optional(),
      }))
      .mutation(({ ctx, input }) => {
        const { id, ...data } = input;
        return db.updateInventoryItem(id, ctx.user.id, data);
      }),
    delete: protectedProcedure
      .input(z.object({ id: z.number() }))
      .mutation(({ ctx, input }) => db.deleteInventoryItem(input.id, ctx.user.id)),
    adjustQuantity: protectedProcedure
      .input(z.object({
        id: z.number(),
        size: z.enum(['P', 'M', 'G', 'GG']),
        quantity: z.number(),
      }))
      .mutation(({ ctx, input }) => db.adjustInventoryQuantity(input.id, ctx.user.id, input.size, input.quantity)),
  }),
  
  cashRegister: router({
    list: protectedProcedure.query(({ ctx }) => db.getCashRegisterTransactions(ctx.user.id)),
    create: protectedProcedure
      .input(z.object({
        type: z.enum(['venda', 'despesa', 'devolucao', 'ajuste']),
        description: z.string().min(1),
        amount: z.number().positive(),
        paymentMethod: z.string().optional(),
        relatedOrderId: z.number().optional(),
        relatedSaleId: z.number().optional(),
        notes: z.string().optional(),
      }))
      .mutation(({ ctx, input }) => db.createCashTransaction(ctx.user.id, input)),
    update: protectedProcedure
      .input(z.object({
        id: z.number(),
        type: z.enum(['venda', 'despesa', 'devolucao', 'ajuste']).optional(),
        description: z.string().optional(),
        amount: z.number().optional(),
        paymentMethod: z.string().optional(),
        notes: z.string().optional(),
      }))
      .mutation(({ ctx, input }) => {
        const { id, ...data } = input;
        return db.updateCashTransaction(id, ctx.user.id, data);
      }),
    delete: protectedProcedure
      .input(z.object({ id: z.number() }))
      .mutation(({ ctx, input }) => db.deleteCashTransaction(input.id, ctx.user.id)),
    getSummary: protectedProcedure
      .input(z.object({
        startDate: z.date(),
        endDate: z.date(),
      }))
      .query(({ ctx, input }) => db.getCashRegisterSummary(ctx.user.id, input.startDate, input.endDate)),
  }),

  suppliers: router({
    list: protectedProcedure.query(({ ctx }) => db.getUserSuppliers(ctx.user.id)),
    create: protectedProcedure
      .input(z.object({
        name: z.string().min(1),
        contact: z.string().min(1),
        email: z.string().email().optional(),
        products: z.string().min(1),
        averagePrice: z.union([z.string().min(1), z.number()]).transform(v => String(v)),
        status: z.enum(["active", "inactive"]).default("active"),
        notes: z.string().optional(),
      }))
      .mutation(({ ctx, input }) => db.createSupplier(ctx.user.id, input)),
    get: protectedProcedure
      .input(z.object({ id: z.number() }))
      .query(({ ctx, input }) => db.getSupplier(input.id, ctx.user.id)),
    update: protectedProcedure
      .input(z.object({
        id: z.number(),
        name: z.string().optional(),
        contact: z.string().optional(),
        email: z.string().email().optional(),
        products: z.string().optional(),
        averagePrice: z.union([z.string(), z.number()]).transform(v => String(v)).optional(),
        status: z.enum(["active", "inactive"]).optional(),
        notes: z.string().optional(),
      }))
      .mutation(({ ctx, input }) => {
        const { id, ...data } = input;
        return db.updateSupplier(id, ctx.user.id, data);
      }),
    delete: protectedProcedure
      .input(z.object({ id: z.number() }))
      .mutation(({ ctx, input }) => db.deleteSupplier(input.id, ctx.user.id)),
  }),

});
export type AppRouter = typeof appRouter;
