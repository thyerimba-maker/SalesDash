import { eq, and, desc, ne } from "drizzle-orm";
import { orders, orderHistory, Order, InsertOrder } from "../drizzle/schema";
import { getDb } from "./db";

/**
 * CREATE - Add new order
 */
export async function createOrder(userId: number, data: InsertOrder) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  // Auto-generate orderNumber if not provided
  const orderNumber = data.orderNumber || `ORD-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;

  const result = await db.insert(orders).values({
    ...data,
    userId,
    orderNumber,
  });

  return result;
}

/**
 * READ - Get all active orders (not completed/cancelled)
 */
export async function getUserActiveOrders(userId: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  return db
    .select()
    .from(orders)
    .where(
      and(
        eq(orders.userId, userId),
        ne(orders.status, "entregue"),
        ne(orders.status, "cancelado"),
        ne(orders.status, "devolvido")
      )
    )
    .orderBy(desc(orders.createdAt));
}

/**
 * READ - Get all orders including completed
 */
export async function getUserAllOrders(userId: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  return db
    .select()
    .from(orders)
    .where(eq(orders.userId, userId))
    .orderBy(desc(orders.createdAt));
}

/**
 * READ - Get completed orders
 */
export async function getUserCompletedOrders(userId: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  return db
    .select()
    .from(orders)
    .where(
      and(
        eq(orders.userId, userId),
        ne(orders.status, "pendente"),
        ne(orders.status, "confirmado"),
        ne(orders.status, "preparando"),
        ne(orders.status, "pronto"),
        ne(orders.status, "saiu_entrega")
      )
    )
    .orderBy(desc(orders.completedDate));
}

/**
 * READ - Get single order
 */
export async function getOrder(orderId: number, userId: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  const result = await db
    .select()
    .from(orders)
    .where(and(eq(orders.id, orderId), eq(orders.userId, userId)))
    .limit(1);

  return result.length > 0 ? result[0] : null;
}

/**
 * UPDATE - Update order status and track history
 */
export async function updateOrderStatus(
  orderId: number,
  userId: number,
  newStatus: string
) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  // Get current order to track old value
  const currentOrder = await getOrder(orderId, userId);
  if (!currentOrder) throw new Error("Order not found");

  const oldStatus = currentOrder.status;

  // Update order
  await db
    .update(orders)
    .set({
      status: newStatus as any,
      completedDate:
        newStatus === "entregue" || newStatus === "cancelado"
          ? new Date()
          : null,
      updatedAt: new Date(),
    })
    .where(eq(orders.id, orderId));

  // Track history
  await db.insert(orderHistory).values({
    orderId,
    userId,
    action: "status_changed",
    oldValue: oldStatus,
    newValue: newStatus,
    description: `Status changed from ${oldStatus} to ${newStatus}`,
  });

  return { success: true };
}

/**
 * UPDATE - Update order notes
 */
export async function updateOrderNotes(
  orderId: number,
  userId: number,
  notes?: string,
  internalNotes?: string
) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  const updateData: any = {
    updatedAt: new Date(),
  };

  if (notes !== undefined) updateData.notes = notes;
  if (internalNotes !== undefined) updateData.internalNotes = internalNotes;

  await db
    .update(orders)
    .set(updateData)
    .where(and(eq(orders.id, orderId), eq(orders.userId, userId)));

  // Track history
  await db.insert(orderHistory).values({
    orderId,
    userId,
    action: "note_added",
    description: "Notes updated",
  });

  return { success: true };
}

/**
 * UPDATE - Update order customization
 */
export async function updateOrderCustomization(
  orderId: number,
  userId: number,
  customizationName?: string,
  customizationNumber?: string,
  customizationDetails?: string
) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  const updateData: any = {
    updatedAt: new Date(),
  };

  if (customizationName !== undefined)
    updateData.customizationName = customizationName;
  if (customizationNumber !== undefined)
    updateData.customizationNumber = customizationNumber;
  if (customizationDetails !== undefined)
    updateData.customizationDetails = customizationDetails;

  await db
    .update(orders)
    .set(updateData)
    .where(and(eq(orders.id, orderId), eq(orders.userId, userId)));

  // Track history
  await db.insert(orderHistory).values({
    orderId,
    userId,
    action: "customization_updated",
    description: "Customization details updated",
  });

  return { success: true };
}

/**
 * UPDATE - Full order edit
 */
export async function updateOrder(
  orderId: number,
  userId: number,
  data: Partial<InsertOrder>
) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  const updateData = {
    ...data,
    updatedAt: new Date(),
  };

  await db
    .update(orders)
    .set(updateData as any)
    .where(and(eq(orders.id, orderId), eq(orders.userId, userId)));

  // Track history
  await db.insert(orderHistory).values({
    orderId,
    userId,
    action: "order_edited",
    description: "Order details updated",
  });

  return { success: true };
}

/**
 * DELETE - Cancel/delete order
 */
export async function cancelOrder(orderId: number, userId: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  await db
    .update(orders)
    .set({
      status: "cancelado" as any,
      completedDate: new Date(),
      updatedAt: new Date(),
    })
    .where(and(eq(orders.id, orderId), eq(orders.userId, userId)));

  // Track history
  await db.insert(orderHistory).values({
    orderId,
    userId,
    action: "order_cancelled",
    description: "Order cancelled",
  });

  return { success: true };
}

/**
 * READ - Get order history
 */
export async function getOrderHistory(orderId: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  return db
    .select()
    .from(orderHistory)
    .where(eq(orderHistory.orderId, orderId))
    .orderBy(desc(orderHistory.createdAt));
}

/**
 * STATS - Get order statistics
 */
export async function getOrderStats(userId: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  const allOrders = await db
    .select()
    .from(orders)
    .where(eq(orders.userId, userId));

  const activeOrders = allOrders.filter(
    (o) =>
      o.status !== "entregue" &&
      o.status !== "cancelado" &&
      o.status !== "devolvido"
  );

  const completedOrders = allOrders.filter(
    (o) =>
      o.status === "entregue" || o.status === "cancelado" || o.status === "devolvido"
  );

  const totalRevenue = allOrders.reduce((sum, o) => sum + (o.totalAmount || 0), 0);

  return {
    totalOrders: allOrders.length,
    activeOrders: activeOrders.length,
    completedOrders: completedOrders.length,
    totalRevenue,
    averageOrderValue:
      allOrders.length > 0
        ? Math.round(totalRevenue / allOrders.length)
        : 0,
  };
}
