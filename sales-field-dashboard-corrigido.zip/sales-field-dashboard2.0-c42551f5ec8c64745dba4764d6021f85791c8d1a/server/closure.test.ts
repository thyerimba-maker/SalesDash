import { describe, it, expect, beforeEach, vi } from 'vitest';
import * as db from './db';

vi.mock('./db', () => ({
  closeLead: vi.fn(),
  getClosedLeads: vi.fn(),
  getFollowUpLeads: vi.fn(),
}));

describe('Lead Closure System', () => {
  const mockUserId = 1;
  const mockLeadId = 1;

  beforeEach(() => {
    vi.clearAllMocks();
  });

  describe('Close Lead', () => {
    it('should close a lead with venda_feita status', async () => {
      const reason = 'Cliente confirmou compra do Combo Premium';

      vi.mocked(db.closeLead).mockResolvedValueOnce({} as any);

      await db.closeLead(mockLeadId, mockUserId, 'venda_feita', reason);

      expect(vi.mocked(db.closeLead)).toHaveBeenCalled();
      const calls = vi.mocked(db.closeLead).mock.calls;
      expect(calls[0][0]).toBe(mockLeadId);
      expect(calls[0][1]).toBe(mockUserId);
      expect(calls[0][2]).toBe('venda_feita');
      expect(calls[0][3]).toBe(reason);
    });

    it('should close a lead with venda_perdida status and schedule follow-up', async () => {
      const reason = 'Cliente pediu para retornar em 2 semanas';
      const followUpDate = new Date(Date.now() + 14 * 24 * 60 * 60 * 1000); // 2 weeks from now

      vi.mocked(db.closeLead).mockResolvedValueOnce({} as any);

      await db.closeLead(mockLeadId, mockUserId, 'venda_perdida', reason, followUpDate);

      expect(vi.mocked(db.closeLead)).toHaveBeenCalledWith(
        mockLeadId,
        mockUserId,
        'venda_perdida',
        reason,
        followUpDate
      );
    });

    it('should close a lead without follow-up date', async () => {
      const reason = 'Cliente desistiu definitivamente';

      vi.mocked(db.closeLead).mockResolvedValueOnce({} as any);

      await db.closeLead(mockLeadId, mockUserId, 'venda_perdida', reason);

      expect(vi.mocked(db.closeLead)).toHaveBeenCalledWith(
        mockLeadId,
        mockUserId,
        'venda_perdida',
        reason
      );
    });
  });

  describe('Get Closed Leads', () => {
    it('should retrieve all closed leads for a user', async () => {
      const mockClosedLeads = [
        {
          id: 1,
          userId: mockUserId,
          name: 'João Silva',
          phone: '(11) 99999-1111',
          status: 'venda_feita' as const,
          product: 'Produto Premium',
          closureReason: 'Cliente confirmou compra',
          closureDate: new Date(),
          followUpDate: null,
          createdAt: new Date(),
          updatedAt: new Date(),
          email: 'joao@example.com',
          source: 'direto',
          notes: null,
          lastContact: null,
        },
        {
          id: 2,
          userId: mockUserId,
          name: 'Maria Santos',
          phone: '(11) 88888-2222',
          status: 'venda_perdida' as const,
          product: 'Produto Standard',
          closureReason: 'Cliente pediu para retornar depois',
          closureDate: new Date(),
          followUpDate: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000),
          createdAt: new Date(),
          updatedAt: new Date(),
          email: 'maria@example.com',
          source: 'indicacao',
          notes: null,
          lastContact: null,
        },
      ];

      vi.mocked(db.getClosedLeads).mockResolvedValueOnce(mockClosedLeads);

      const result = await db.getClosedLeads(mockUserId);

      expect(result).toEqual(mockClosedLeads);
      expect(result).toHaveLength(2);
      expect(result[0].status).toBe('venda_feita');
      expect(result[1].status).toBe('venda_perdida');
    });

    it('should return empty array if no closed leads', async () => {
      vi.mocked(db.getClosedLeads).mockResolvedValueOnce([]);

      const result = await db.getClosedLeads(mockUserId);

      expect(result).toEqual([]);
      expect(result).toHaveLength(0);
    });
  });

  describe('Get Follow-up Leads', () => {
    it('should retrieve leads with pending follow-ups', async () => {
      const now = new Date();
      const pastDate = new Date(now.getTime() - 1000); // 1 second ago

      const mockFollowUpLeads = [
        {
          id: 2,
          userId: mockUserId,
          name: 'Maria Santos',
          phone: '(11) 88888-2222',
          status: 'venda_perdida' as const,
          product: 'Produto Standard',
          closureReason: 'Cliente pediu para retornar depois',
          closureDate: new Date(),
          followUpDate: pastDate,
          createdAt: new Date(),
          updatedAt: new Date(),
          email: 'maria@example.com',
          source: 'indicacao',
          notes: null,
          lastContact: null,
        },
      ];

      vi.mocked(db.getFollowUpLeads).mockResolvedValueOnce(mockFollowUpLeads);

      const result = await db.getFollowUpLeads(mockUserId);

      expect(result).toEqual(mockFollowUpLeads);
      expect(result).toHaveLength(1);
      expect(new Date(result[0].followUpDate!).getTime()).toBeLessThanOrEqual(now.getTime());
    });

    it('should return empty array if no follow-ups pending', async () => {
      vi.mocked(db.getFollowUpLeads).mockResolvedValueOnce([]);

      const result = await db.getFollowUpLeads(mockUserId);

      expect(result).toEqual([]);
      expect(result).toHaveLength(0);
    });
  });

  describe('Closure Workflow', () => {
    it('should handle complete workflow: create lead -> close as venda_feita', async () => {
      const leadData = {
        name: 'João Silva',
        phone: '(11) 99999-1111',
        product: 'Produto Premium',
        source: 'direto',
      };

      const closureData = {
        status: 'venda_feita' as const,
        reason: 'Cliente confirmou compra',
      };

      vi.mocked(db.closeLead).mockResolvedValueOnce({} as any);

      await db.closeLead(mockLeadId, mockUserId, closureData.status, closureData.reason);

      expect(vi.mocked(db.closeLead)).toHaveBeenCalledWith(
        mockLeadId,
        mockUserId,
        'venda_feita',
        'Cliente confirmou compra'
      );
    });

    it('should handle complete workflow: create lead -> close as venda_perdida with follow-up', async () => {
      const closureData = {
        status: 'venda_perdida' as const,
        reason: 'Cliente pediu para retornar em 2 semanas',
        followUpDate: new Date(Date.now() + 14 * 24 * 60 * 60 * 1000),
      };

      vi.mocked(db.closeLead).mockResolvedValueOnce({} as any);

      await db.closeLead(
        mockLeadId,
        mockUserId,
        closureData.status,
        closureData.reason,
        closureData.followUpDate
      );

      expect(vi.mocked(db.closeLead)).toHaveBeenCalled();
      const calls = vi.mocked(db.closeLead).mock.calls;
      expect(calls[0][0]).toBe(mockLeadId);
      expect(calls[0][1]).toBe(mockUserId);
      expect(calls[0][2]).toBe('venda_perdida');
      expect(calls[0][3]).toBe('Cliente pediu para retornar em 2 semanas');
    });
  });
});
