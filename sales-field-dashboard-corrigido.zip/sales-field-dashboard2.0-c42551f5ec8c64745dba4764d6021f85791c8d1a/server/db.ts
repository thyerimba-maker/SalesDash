import { eq, and, desc, gte, lte, sql } from "drizzle-orm";
import { drizzle } from "drizzle-orm/mysql2";
import { InsertUser, users, leads, sales, contactHistory, dailyMetrics, inventory, cashRegister, leadProducts, leadHistory, suppliers, InsertLead, InsertSale, InsertContactHistory, InsertInventory, InsertCashRegister, InsertLeadProduct, InsertLeadHistory, InsertSupplier, Supplier } from "../drizzle/schema";
import { ENV } from './_core/env';

let _db: ReturnType<typeof drizzle> | null = null;

// Lazily create the drizzle instance so local tooling can run without a DB.
export async function getDb() {
  if (!_db && process.env.DATABASE_URL) {
    try {
      _db = drizzle(process.env.DATABASE_URL);
    } catch (error) {
      console.warn("[Database] Failed to connect:", error);
      _db = null;
    }
  }
  return _db;
}

export async function upsertUser(user: InsertUser): Promise<void> {
  if (!user.openId) {
    throw new Error("User openId is required for upsert");
  }

  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot upsert user: database not available");
    return;
  }

  try {
    const values: InsertUser = {
      openId: user.openId,
    };
    const updateSet: Record<string, unknown> = {};

    const textFields = ["name", "email", "loginMethod"] as const;
    type TextField = (typeof textFields)[number];

    const assignNullable = (field: TextField) => {
      const value = user[field];
      if (value === undefined) return;
      const normalized = value ?? null;
      values[field] = normalized;
      updateSet[field] = normalized;
    };

    textFields.forEach(assignNullable);

    if (user.lastSignedIn !== undefined) {
      values.lastSignedIn = user.lastSignedIn;
      updateSet.lastSignedIn = user.lastSignedIn;
    }
    if (user.role !== undefined) {
      values.role = user.role;
      updateSet.role = user.role;
    } else if (user.openId === ENV.ownerOpenId) {
      values.role = 'admin';
      updateSet.role = 'admin';
    }

    if (!values.lastSignedIn) {
      values.lastSignedIn = new Date();
    }

    if (Object.keys(updateSet).length === 0) {
      updateSet.lastSignedIn = new Date();
    }

    await db.insert(users).values(values).onDuplicateKeyUpdate({
      set: updateSet,
    });
  } catch (error) {
    console.error("[Database] Failed to upsert user:", error);
    throw error;
  }
}

export async function getUserByOpenId(openId: string) {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot get user: database not available");
    return undefined;
  }

  const result = await db.select().from(users).where(eq(users.openId, openId)).limit(1);

  return result.length > 0 ? result[0] : undefined;
}

// LEADS QUERIES
export async function createLead(userId: number, data: Omit<InsertLead, 'userId'>) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  const result = await db.insert(leads).values({
    ...data,
    userId,
  });

  return result;
}

export async function getUserLeads(userId: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  return db.select().from(leads).where(eq(leads.userId, userId)).orderBy(desc(leads.createdAt));
}

export async function getLead(leadId: number, userId: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  const result = await db.select().from(leads).where(and(eq(leads.id, leadId), eq(leads.userId, userId))).limit(1);
  return result.length > 0 ? result[0] : null;
}

export async function updateLead(leadId: number, userId: number, data: Partial<InsertLead>) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  return db.update(leads).set({ ...data, updatedAt: new Date() }).where(and(eq(leads.id, leadId), eq(leads.userId, userId)));
}

export async function deleteLead(leadId: number, userId: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  return db.delete(leads).where(and(eq(leads.id, leadId), eq(leads.userId, userId)));
}

// SALES QUERIES
export async function createSale(userId: number, data: Omit<InsertSale, 'userId'>) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  return db.insert(sales).values({
    ...data,
    userId,
  });
}

export async function getUserSales(userId: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  return db.select().from(sales).where(eq(sales.userId, userId)).orderBy(desc(sales.createdAt));
}

export async function getSalesByDateRange(userId: number, startDate: Date, endDate: Date) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  return db.select().from(sales).where(
    and(
      eq(sales.userId, userId),
      gte(sales.createdAt, startDate),
      lte(sales.createdAt, endDate)
    )
  ).orderBy(desc(sales.createdAt));
}

// CONTACT HISTORY QUERIES
export async function createContactHistory(userId: number, data: Omit<InsertContactHistory, 'userId'>) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  return db.insert(contactHistory).values({
    ...data,
    userId,
  });
}

export async function getLeadContactHistory(leadId: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  return db.select().from(contactHistory).where(eq(contactHistory.leadId, leadId)).orderBy(desc(contactHistory.createdAt));
}

// METRICS QUERIES
export async function getDailyMetrics(userId: number, date: string) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  const result = await db.select().from(dailyMetrics).where(
    and(eq(dailyMetrics.userId, userId), eq(dailyMetrics.date, date))
  ).limit(1);

  return result.length > 0 ? result[0] : null;
}

export async function updateOrCreateDailyMetrics(userId: number, date: string, updates: Partial<typeof dailyMetrics.$inferInsert>) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  const existing = await getDailyMetrics(userId, date);

  if (existing) {
    return db.update(dailyMetrics).set({ ...updates, updatedAt: new Date() }).where(eq(dailyMetrics.id, existing.id));
  } else {
    return db.insert(dailyMetrics).values({
      userId,
      date,
      ...updates,
    });
  }
}

export async function getUserMetricsRange(userId: number, startDate: string, endDate: string) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  return db.select().from(dailyMetrics).where(
    and(
      eq(dailyMetrics.userId, userId),
      gte(dailyMetrics.date, startDate),
      lte(dailyMetrics.date, endDate)
    )
  ).orderBy(desc(dailyMetrics.date));
}

// LEAD CLOSURE QUERIES
export async function closeLead(leadId: number, userId: number, status: 'venda_feita' | 'venda_perdida', reason: string, followUpDate?: Date, saleAmount?: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  // Get the lead to access saleAmount - check userId to ensure ownership
  const leadData = await db.select().from(leads).where(and(eq(leads.id, leadId), eq(leads.userId, userId))).limit(1);
  if (!leadData || leadData.length === 0) {
    throw new Error("Lead not found");
  }
  const lead = leadData[0];

  // Update lead with saleAmount if provided
  if (saleAmount && saleAmount > 0) {
    await db.update(leads).set({
      saleAmount: Math.round(saleAmount * 100), // Convert to cents
    }).where(eq(leads.id, leadId));
  }

  // If lead is being marked as sold, deduct inventory and create cash register entry
  if (status === 'venda_feita') {
    await deductInventoryFromLead(leadId, userId);
    
    // Get updated lead data with new saleAmount
    const updatedLeadData = await db.select().from(leads).where(eq(leads.id, leadId)).limit(1);
    const updatedLead = updatedLeadData[0];
    
    // Create automatic cash register entry for the sale
    const finalAmount = saleAmount ? Math.round(saleAmount * 100) : (lead.saleAmount || 0);
    if (finalAmount > 0) {
      // Set transaction time to end of day (23:59:59)
      const endOfDay = new Date();
      endOfDay.setHours(23, 59, 59, 999);
      
      await db.insert(cashRegister).values({
        userId,
        type: 'venda',
        description: `Venda - ${lead.name} (${lead.product})`,
        amount: finalAmount,
        paymentMethod: 'nao_especificado',
        relatedOrderId: null,
        notes: `Lead finalizado: ${reason}`,
        createdAt: endOfDay,
      });
    }
  }

  const result = await db.update(leads).set({
    status,
    closureReason: reason,
    closureDate: new Date(),
    followUpDate: followUpDate || null,
    updatedAt: new Date(),
  }).where(and(eq(leads.id, leadId), eq(leads.userId, userId)));
  
  return result;
}

export async function getClosedLeads(userId: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  return db.select().from(leads).where(
    and(
      eq(leads.userId, userId),
      gte(leads.closureDate, new Date('1970-01-01'))
    )
  ).orderBy(desc(leads.closureDate));
}

export async function getFollowUpLeads(userId: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  const now = new Date();
  return db.select().from(leads).where(
    and(
      eq(leads.userId, userId),
      lte(leads.followUpDate, now)
    )
  ).orderBy(desc(leads.followUpDate));
}

export async function getMonthlySales(userId: number, year?: number, month?: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  const now = new Date();
  const targetYear = year || now.getFullYear();
  const targetMonth = month !== undefined ? month : now.getMonth() + 1;

  const startDate = new Date(targetYear, targetMonth - 1, 1);
  const endDate = new Date(targetYear, targetMonth, 0, 23, 59, 59);

  const result = await db.select({
    id: leads.id,
    name: leads.name,
    phone: leads.phone,
    product: leads.product,
    saleAmount: leads.saleAmount,
    closureDate: leads.closureDate,
    status: leads.status,
    closureReason: leads.closureReason,
  }).from(leads).where(
    and(
      eq(leads.userId, userId),
      eq(leads.status, 'venda_feita'),
      gte(leads.closureDate, startDate),
      lte(leads.closureDate, endDate)
    )
  ).orderBy(desc(leads.closureDate));

  return result;
}

export async function getMonthlySalesStats(userId: number, year?: number, month?: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  const now = new Date();
  const targetYear = year || now.getFullYear();
  const targetMonth = month !== undefined ? month : now.getMonth() + 1;

  const startDate = new Date(targetYear, targetMonth - 1, 1);
  const endDate = new Date(targetYear, targetMonth, 0, 23, 59, 59);

  const completedSales = await db.select({
    count: sql<number>`COUNT(*)`,
    total: sql<number>`COALESCE(SUM(${leads.saleAmount}), 0)`,
  }).from(leads).where(
    and(
      eq(leads.userId, userId),
      eq(leads.status, 'venda_feita'),
      gte(leads.closureDate, startDate),
      lte(leads.closureDate, endDate)
    )
  );

  const lostSales = await db.select({
    count: sql<number>`COUNT(*)`,
  }).from(leads).where(
    and(
      eq(leads.userId, userId),
      eq(leads.status, 'venda_perdida'),
      gte(leads.closureDate, startDate),
      lte(leads.closureDate, endDate)
    )
  );

  return {
    completedCount: completedSales[0]?.count || 0,
    totalAmount: completedSales[0]?.total || 0,
    lostCount: lostSales[0]?.count || 0,
    year: targetYear,
    month: targetMonth,
  };
}


// ============ INVENTORY MANAGEMENT ============

export async function getUserInventory(userId: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  return db.select().from(inventory).where(eq(inventory.userId, userId)).orderBy(desc(inventory.updatedAt));
}

export async function createInventoryItem(userId: number, data: Omit<InsertInventory, 'userId'>) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  const totalQuantity = (data.sizeP || 0) + (data.sizeM || 0) + (data.sizeG || 0) + (data.sizeGG || 0);
  
  const result = await db.insert(inventory).values({
    ...data,
    userId,
    totalQuantity,
  });
  
  const created = await db.select().from(inventory).where(eq(inventory.userId, userId)).orderBy(desc(inventory.createdAt)).limit(1);
  return created[0];
}

export async function updateInventoryItem(itemId: number, userId: number, data: Partial<Omit<InsertInventory, 'userId'>>) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  // Calculate new total quantity if sizes are being updated
  let updateData = { ...data };
  if (data.sizeP !== undefined || data.sizeM !== undefined || data.sizeG !== undefined || data.sizeGG !== undefined) {
    const current = await db.select().from(inventory).where(eq(inventory.id, itemId)).limit(1);
    if (current.length === 0) throw new Error("Inventory item not found");
    
    const item = current[0];
    const totalQuantity = (data.sizeP ?? item.sizeP) + (data.sizeM ?? item.sizeM) + (data.sizeG ?? item.sizeG) + (data.sizeGG ?? item.sizeGG);
    updateData = { ...updateData, totalQuantity };
  }
  
  await db.update(inventory).set(updateData).where(and(eq(inventory.id, itemId), eq(inventory.userId, userId)));
  
  const updated = await db.select().from(inventory).where(eq(inventory.id, itemId)).limit(1);
  return updated[0];
}

export async function deleteInventoryItem(itemId: number, userId: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  return db.delete(inventory).where(and(eq(inventory.id, itemId), eq(inventory.userId, userId)));
}

export async function adjustInventoryQuantity(itemId: number, userId: number, size: 'P' | 'M' | 'G' | 'GG', quantity: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  const current = await db.select().from(inventory).where(eq(inventory.id, itemId)).limit(1);
  if (current.length === 0) throw new Error("Inventory item not found");
  
  const item = current[0];
  const sizeKey = `size${size}` as keyof typeof item;
  const currentQuantity = item[sizeKey] as number;
  const newQuantity = Math.max(0, currentQuantity + quantity);
  
  const totalQuantity = (size === 'P' ? newQuantity : item.sizeP) +
                       (size === 'M' ? newQuantity : item.sizeM) +
                       (size === 'G' ? newQuantity : item.sizeG) +
                       (size === 'GG' ? newQuantity : item.sizeGG);
  
  const updateData: any = { [sizeKey]: newQuantity, totalQuantity };
  
  return db.update(inventory).set(updateData).where(and(eq(inventory.id, itemId), eq(inventory.userId, userId)));
}

// ============ CASH REGISTER ============

export async function getCashRegisterTransactions(userId: number, limit: number = 100) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  return db.select().from(cashRegister).where(eq(cashRegister.userId, userId)).orderBy(desc(cashRegister.createdAt)).limit(limit);
}

export async function createCashTransaction(userId: number, data: Omit<InsertCashRegister, 'userId'>) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  // Set transaction time to end of day (23:59:59) if not already set
  const createdAt = data.createdAt || new Date();
  const endOfDay = new Date(createdAt);
  endOfDay.setHours(23, 59, 59, 999);
  
  return db.insert(cashRegister).values({
    ...data,
    createdAt: endOfDay,
    userId,
  });
}

export async function updateCashTransaction(transactionId: number, userId: number, data: Partial<Omit<InsertCashRegister, 'userId'>>) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  return db.update(cashRegister).set(data).where(and(eq(cashRegister.id, transactionId), eq(cashRegister.userId, userId)));
}

export async function deleteCashTransaction(transactionId: number, userId: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  return db.delete(cashRegister).where(and(eq(cashRegister.id, transactionId), eq(cashRegister.userId, userId)));
}

export async function getCashRegisterSummary(userId: number, startDate: Date, endDate: Date) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  const transactions = await db.select().from(cashRegister).where(
    and(
      eq(cashRegister.userId, userId),
      gte(cashRegister.createdAt, startDate),
      lte(cashRegister.createdAt, endDate)
    )
  );
  
  const summary = {
    totalVendas: 0,
    totalDespesas: 0,
    totalDevolucoes: 0,
    totalAjustes: 0,
    saldoFinal: 0,
  };
  
  transactions.forEach(t => {
    switch (t.type) {
      case 'venda':
        summary.totalVendas += t.amount;
        break;
      case 'despesa':
        summary.totalDespesas += t.amount;
        break;
      case 'devolucao':
        summary.totalDevolucoes += t.amount;
        break;
      case 'ajuste':
        summary.totalAjustes += t.amount;
        break;
    }
  });
  
  summary.saldoFinal = summary.totalVendas - summary.totalDespesas - summary.totalDevolucoes + summary.totalAjustes;
  
  return summary;
}


// ============================================
// Lead Products Functions
// ============================================

export async function linkProductToLead(
  leadId: number,
  userId: number,
  productData: Omit<InsertLeadProduct, 'leadId' | 'userId'>
): Promise<any> {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  const result = await db.insert(leadProducts).values({
    ...productData,
    leadId,
    userId,
  })

  // Log to lead history
  await addLeadHistory(leadId, userId, "product_added", undefined, productData.productName, `Produto adicionado: ${productData.productName}`);

  return result;
}

export async function getLeadProducts(leadId: number): Promise<any[]> {
  const db = await getDb();
  if (!db) return [];

  return db.select().from(leadProducts).where(eq(leadProducts.leadId, leadId));
}

export async function updateLeadProduct(
  productId: number,
  data: Partial<InsertLeadProduct>
): Promise<any> {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  return db.update(leadProducts).set(data).where(eq(leadProducts.id, productId));
}

export async function deleteLeadProduct(productId: number, leadId: number, userId: number): Promise<any> {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  const product = await db.select().from(leadProducts).where(eq(leadProducts.id, productId)).limit(1);
  
  if (product.length > 0) {
    const prod = product[0];
    
    // Restore inventory
    const inventoryItems = await db.select().from(inventory).where(eq(inventory.productName, prod.productName)).limit(1);
    if (inventoryItems.length > 0) {
      const item = inventoryItems[0];
      const newSizeP = (item.sizeP || 0) + (prod.sizeP || 0);
      const newSizeM = (item.sizeM || 0) + (prod.sizeM || 0);
      const newSizeG = (item.sizeG || 0) + (prod.sizeG || 0);
      const newSizeGG = (item.sizeGG || 0) + (prod.sizeGG || 0);
      const newTotal = newSizeP + newSizeM + newSizeG + newSizeGG;

      await db.update(inventory).set({
        sizeP: newSizeP,
        sizeM: newSizeM,
        sizeG: newSizeG,
        sizeGG: newSizeGG,
        totalQuantity: newTotal,
      }).where(eq(inventory.id, item.id));
    }
    
    await addLeadHistory(leadId, userId, "product_removed", prod.productName, undefined, `Produto removido e estoque restaurado: ${prod.productName}`);
  }

  return db.delete(leadProducts).where(eq(leadProducts.id, productId));
}

// ============================================
// Lead History Functions
// ============================================

export async function addLeadHistory(
  leadId: number,
  userId: number,
  action: string,
  oldValue?: string,
  newValue?: string,
  description?: string
): Promise<any> {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  return db.insert(leadHistory).values({
    leadId,
    userId,
    action,
    oldValue: oldValue || null,
    newValue: newValue || null,
    description: description || null,
  });
}

export async function getLeadHistory(leadId: number): Promise<any[]> {
  const db = await getDb();
  if (!db) return [];

  return db.select().from(leadHistory).where(eq(leadHistory.leadId, leadId)).orderBy(desc(leadHistory.createdAt));
}

export async function getLeadActivityTimeline(leadId: number): Promise<any[]> {
  const db = await getDb();
  if (!db) return [];

  const history = await db.select().from(leadHistory).where(eq(leadHistory.leadId, leadId)).orderBy(desc(leadHistory.createdAt));

  return history.map(h => ({
    id: h.id,
    action: h.action,
    description: h.description || getActionLabel(h.action, h.oldValue, h.newValue),
    timestamp: h.createdAt,
    oldValue: h.oldValue,
    newValue: h.newValue,
  }));
}

function getActionLabel(action: string, oldValue?: string | null, newValue?: string | null): string {
  switch (action) {
    case "created":
      return "Lead criado";
    case "status_changed":
      return `Status alterado de ${oldValue} para ${newValue}`;
    case "product_added":
      return `Produto adicionado: ${newValue}`;
    case "product_removed":
      return `Produto removido: ${oldValue}`;
    case "note_added":
      return "Nota adicionada";
    case "contact_made":
      return "Contato realizado";
    default:
      return action;
  }
}


// ============================================
// Inventory Deduction (for lead closure)
// ============================================

export async function deductInventoryFromLead(leadId: number, userId: number): Promise<void> {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  // Get all products linked to this lead
  const linkedProducts = await db.select().from(leadProducts).where(eq(leadProducts.leadId, leadId));

  // Deduct each product from inventory
  for (const product of linkedProducts) {
    const inventoryItem = await db.select().from(inventory).where(eq(inventory.id, product.id)).limit(1);
    
    if (inventoryItem.length > 0) {
      const item = inventoryItem[0];
      
      // Calculate new quantities
      const newSizeP = Math.max(0, item.sizeP - product.sizeP);
      const newSizeM = Math.max(0, item.sizeM - product.sizeM);
      const newSizeG = Math.max(0, item.sizeG - product.sizeG);
      const newSizeGG = Math.max(0, item.sizeGG - product.sizeGG);
      const newTotal = newSizeP + newSizeM + newSizeG + newSizeGG;

      // Update inventory
      await db.update(inventory).set({
        sizeP: newSizeP,
        sizeM: newSizeM,
        sizeG: newSizeG,
        sizeGG: newSizeGG,
        totalQuantity: newTotal,
      }).where(eq(inventory.id, item.id));
    }
  }
}


// ============================================
// Get Leads with Linked Products (for Orders)
// ============================================

export async function getLeadsWithProducts(userId: number): Promise<any[]> {
  const db = await getDb();
  if (!db) return [];

  // Get all leads with products linked
  const leadsWithProducts = await db
    .select({
      id: leads.id,
      name: leads.name,
      phone: leads.phone,
      email: leads.email,
      product: leads.product,
      status: leads.status,
      saleAmount: leads.saleAmount,
      closureDate: leads.closureDate,
      createdAt: leads.createdAt,
      products: leadProducts,
    })
    .from(leads)
    .leftJoin(leadProducts, eq(leads.id, leadProducts.leadId))
    .where(eq(leads.userId, userId));

  // Group by lead and collect products
  const grouped = new Map<number, any>();
  
  for (const row of leadsWithProducts) {
    const leadId = row.id;
    
    if (!grouped.has(leadId)) {
      grouped.set(leadId, {
        id: row.id,
        name: row.name,
        phone: row.phone,
        email: row.email,
        product: row.product,
        status: row.status,
        saleAmount: row.saleAmount,
        closureDate: row.closureDate,
        createdAt: row.createdAt,
        linkedProducts: [],
      });
    }
    
    if (row.products) {
      grouped.get(leadId)!.linkedProducts.push(row.products);
    }
  }

  // Return only leads that have linked products
  return Array.from(grouped.values()).filter(lead => lead.linkedProducts.length > 0);
}


export async function linkProductToLeadWithInventoryDeduction(
  leadId: number,
  userId: number,
  productData: Omit<InsertLeadProduct, 'leadId' | 'userId'>
): Promise<any> {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  // First, link the product to the lead
  const result = await db.insert(leadProducts).values({
    ...productData,
    leadId,
    userId,
  });

  // Then, deduct from inventory
  const inventoryItems = await db.select().from(inventory).where(eq(inventory.productName, productData.productName)).limit(1);
  
  if (inventoryItems.length > 0) {
    const item = inventoryItems[0];
    const newSizeP = Math.max(0, (item.sizeP || 0) - (productData.sizeP || 0));
    const newSizeM = Math.max(0, (item.sizeM || 0) - (productData.sizeM || 0));
    const newSizeG = Math.max(0, (item.sizeG || 0) - (productData.sizeG || 0));
    const newSizeGG = Math.max(0, (item.sizeGG || 0) - (productData.sizeGG || 0));
    const newTotal = newSizeP + newSizeM + newSizeG + newSizeGG;

    await db.update(inventory).set({
      sizeP: newSizeP,
      sizeM: newSizeM,
      sizeG: newSizeG,
      sizeGG: newSizeGG,
      totalQuantity: newTotal,
    }).where(eq(inventory.id, item.id));
  }

  // Log to lead history
  await addLeadHistory(leadId, userId, "product_added", undefined, productData.productName, `Produto adicionado: ${productData.productName} (Estoque descontado)`);

  return result;
}


// ============ SUPPLIERS FUNCTIONS ============

export async function getUserSuppliers(userId: number): Promise<Supplier[]> {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  return db.select().from(suppliers).where(eq(suppliers.userId, userId));
}

export async function createSupplier(userId: number, data: Omit<InsertSupplier, 'userId'>): Promise<Supplier> {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  await db.insert(suppliers).values({
    ...data,
    userId,
  });
  
  const created = await db.select().from(suppliers).where(
    and(eq(suppliers.userId, userId), eq(suppliers.name, data.name))
  ).orderBy(desc(suppliers.createdAt)).limit(1);
  
  if (!created.length) throw new Error("Failed to create supplier");
  return created[0];
}

export async function getSupplier(id: number, userId: number): Promise<Supplier | null> {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  const result = await db.select().from(suppliers).where(
    and(eq(suppliers.id, id), eq(suppliers.userId, userId))
  ).limit(1);
  
  return result.length > 0 ? result[0] : null;
}

export async function updateSupplier(id: number, userId: number, data: Partial<Omit<InsertSupplier, 'userId'>>): Promise<Supplier> {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  // Verify ownership
  const existing = await getSupplier(id, userId);
  if (!existing) throw new Error("Supplier not found");
  
  await db.update(suppliers).set(data).where(
    and(eq(suppliers.id, id), eq(suppliers.userId, userId))
  );
  
  const updated = await getSupplier(id, userId);
  if (!updated) throw new Error("Failed to update supplier");
  return updated;
}

export async function deleteSupplier(id: number, userId: number): Promise<boolean> {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  // Verify ownership
  const existing = await getSupplier(id, userId);
  if (!existing) throw new Error("Supplier not found");
  
  await db.delete(suppliers).where(
    and(eq(suppliers.id, id), eq(suppliers.userId, userId))
  );
  
  return true;
}
