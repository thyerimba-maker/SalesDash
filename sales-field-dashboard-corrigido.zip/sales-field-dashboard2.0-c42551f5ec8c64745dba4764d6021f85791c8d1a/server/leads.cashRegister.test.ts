import { describe, it, expect, beforeAll, afterAll } from 'vitest';
import { getDb } from './db';
import { leads, cashRegister, appUsers } from '../drizzle/schema';
import { eq } from 'drizzle-orm';

describe('Automatic Cash Register Accounting on Lead Closure', () => {
  let db: any;
  let testUserId: number;
  let testLeadId: number;

  beforeAll(async () => {
    db = await getDb();
    
    // Create test user
    const userResult = await db.insert(appUsers).values({
      username: `test_user_cash_${Date.now()}`,
      passwordHash: 'test_hash',
      status: 'active',
    });
    testUserId = userResult[0].insertId;
  });

  afterAll(async () => {
    // Cleanup
    if (testLeadId) {
      await db.delete(cashRegister).where(eq(cashRegister.relatedOrderId, testLeadId));
      await db.delete(leads).where(eq(leads.id, testLeadId));
    }
    if (testUserId) {
      await db.delete(appUsers).where(eq(appUsers.id, testUserId));
    }
  });

  it('should create cash register entry when lead is closed as venda_feita', async () => {
    // Create a lead with sale amount
    const leadResult = await db.insert(leads).values({
      userId: testUserId,
      name: 'Test Customer',
      phone: '11999999999',
      product: 'Test Product',
      status: 'leads',
      saleAmount: 50000, // R$ 500.00
    });
    testLeadId = leadResult[0].insertId;

    // Get initial cash register count
    const initialCashCount = await db.select().from(cashRegister).where(eq(cashRegister.userId, testUserId));
    const initialCount = initialCashCount.length;

    // Close lead as venda_feita
    const leadData = await db.select().from(leads).where(eq(leads.id, testLeadId)).limit(1);
    const lead = leadData[0];

    // Simulate the automatic cash register entry creation
    if (lead.saleAmount && lead.saleAmount > 0) {
      await db.insert(cashRegister).values({
        userId: testUserId,
        type: 'venda',
        description: `Venda - ${lead.name} (${lead.product})`,
        amount: lead.saleAmount,
        paymentMethod: 'nao_especificado',
        relatedOrderId: null,
        notes: `Lead finalizado: Venda realizada`,
      });
    }

    // Verify cash register entry was created
    const finalCashCount = await db.select().from(cashRegister).where(eq(cashRegister.userId, testUserId));
    expect(finalCashCount.length).toBe(initialCount + 1);

    // Verify the entry details
    const newEntry = finalCashCount[finalCashCount.length - 1];
    expect(newEntry.type).toBe('venda');
    expect(newEntry.amount).toBe(50000);
    expect(newEntry.description).toContain('Test Customer');
    expect(newEntry.description).toContain('Test Product');
  });

  it('should not create cash register entry if sale amount is zero or null', async () => {
    // Create a lead without sale amount
    const leadResult = await db.insert(leads).values({
      userId: testUserId,
      name: 'Test Customer 2',
      phone: '11999999998',
      product: 'Test Product 2',
      status: 'leads',
      saleAmount: null,
    });
    const leadId = leadResult[0].insertId;

    // Get initial cash register count
    const initialCashCount = await db.select().from(cashRegister).where(eq(cashRegister.userId, testUserId));
    const initialCount = initialCashCount.length;

    // Simulate closure without creating entry (because saleAmount is null)
    const leadData = await db.select().from(leads).where(eq(leads.id, leadId)).limit(1);
    const lead = leadData[0];

    // This should NOT create an entry because saleAmount is null
    if (lead.saleAmount && lead.saleAmount > 0) {
      await db.insert(cashRegister).values({
        userId: testUserId,
        type: 'venda',
        description: `Venda - ${lead.name}`,
        amount: lead.saleAmount,
        paymentMethod: 'nao_especificado',
      });
    }

    // Verify no new entry was created
    const finalCashCount = await db.select().from(cashRegister).where(eq(cashRegister.userId, testUserId));
    expect(finalCashCount.length).toBe(initialCount);

    // Cleanup
    await db.delete(leads).where(eq(leads.id, leadId));
  });

  it('should include correct description with customer name and product', async () => {
    // Create a lead with specific details
    const leadResult = await db.insert(leads).values({
      userId: testUserId,
      name: 'João Silva',
      phone: '11988887777',
      product: 'Brasil 26/27 Amarela',
      status: 'leads',
      saleAmount: 170000, // R$ 1.700.00
    });
    const leadId = leadResult[0].insertId;

    // Create cash register entry
    const leadData = await db.select().from(leads).where(eq(leads.id, leadId)).limit(1);
    const lead = leadData[0];

    await db.insert(cashRegister).values({
      userId: testUserId,
      type: 'venda',
      description: `Venda - ${lead.name} (${lead.product})`,
      amount: lead.saleAmount,
      paymentMethod: 'nao_especificado',
      notes: `Lead finalizado: Venda realizada`,
    });

    // Verify entry
    const entries = await db.select().from(cashRegister).where(eq(cashRegister.userId, testUserId));
    const newEntry = entries[entries.length - 1];

    expect(newEntry.description).toBe('Venda - João Silva (Brasil 26/27 Amarela)');
    expect(newEntry.amount).toBe(170000);
    expect(newEntry.type).toBe('venda');

    // Cleanup
    await db.delete(leads).where(eq(leads.id, leadId));
  });

  it('should store amount in cents correctly', async () => {
    // Create a lead with a specific amount
    const leadResult = await db.insert(leads).values({
      userId: testUserId,
      name: 'Test Amount',
      phone: '11977776666',
      product: 'Product',
      status: 'leads',
      saleAmount: 284500, // R$ 2.845.00
    });
    const leadId = leadResult[0].insertId;

    // Create cash register entry
    const leadData = await db.select().from(leads).where(eq(leads.id, leadId)).limit(1);
    const lead = leadData[0];

    await db.insert(cashRegister).values({
      userId: testUserId,
      type: 'venda',
      description: `Venda - ${lead.name}`,
      amount: lead.saleAmount,
      paymentMethod: 'nao_especificado',
    });

    // Verify amount is stored in cents
    const entries = await db.select().from(cashRegister).where(eq(cashRegister.userId, testUserId));
    const newEntry = entries[entries.length - 1];

    expect(newEntry.amount).toBe(284500);
    // When formatted: 284500 / 100 = 2845.00 = R$ 2.845,00

    // Cleanup
    await db.delete(leads).where(eq(leads.id, leadId));
  });
});
