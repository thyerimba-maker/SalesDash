import { getUserLeads, getUserSales, getLeadContactHistory } from './db';
import { Lead, Sale, ContactHistory } from '../drizzle/schema';

export interface BackupData {
  timestamp: string;
  leads: Lead[];
  sales: Sale[];
  contactHistory: ContactHistory[];
  metadata: {
    totalLeads: number;
    totalSales: number;
    totalContacts: number;
    exportDate: string;
  };
}

/**
 * Create a complete backup of user data
 */
export async function createUserBackup(userId: number): Promise<BackupData> {
  const leads = await getUserLeads(userId);
  const sales = await getUserSales(userId);

  // Get contact history for all leads
  const contactHistoryPromises = leads.map((lead) =>
    getLeadContactHistory(lead.id)
  );
  const allContactHistory = (await Promise.all(contactHistoryPromises)).flat();

  const backup: BackupData = {
    timestamp: new Date().toISOString(),
    leads,
    sales,
    contactHistory: allContactHistory,
    metadata: {
      totalLeads: leads.length,
      totalSales: sales.length,
      totalContacts: allContactHistory.length,
      exportDate: new Date().toLocaleDateString('pt-BR'),
    },
  };

  return backup;
}

/**
 * Export backup data as JSON string
 */
export function exportBackupAsJSON(backup: BackupData): string {
  return JSON.stringify(backup, null, 2);
}

/**
 * Export backup data as CSV format
 */
export function exportBackupAsCSV(backup: BackupData): string {
  let csv = 'BACKUP DE VENDAS\n';
  csv += `Data de Exportação: ${backup.metadata.exportDate}\n\n`;

  // Leads CSV
  csv += 'LEADS\n';
  csv += 'ID,Nome,Telefone,Email,Produto,Status,Origem,Data de Criação\n';
  backup.leads.forEach((lead) => {
    csv += `${lead.id},"${lead.name}","${lead.phone}","${lead.email || ''}","${lead.product}","${lead.status}","${lead.source || ''}","${new Date(lead.createdAt).toLocaleDateString('pt-BR')}"\n`;
  });

  csv += '\n\nVENDAS\n';
  csv += 'ID,Lead ID,Produto,Valor (R$),Método de Pagamento,Data\n';
  backup.sales.forEach((sale) => {
    const amount = (sale.amount / 100).toLocaleString('pt-BR', { minimumFractionDigits: 2 });
    csv += `${sale.id},${sale.leadId},"${sale.product}","${amount}","${sale.paymentMethod || ''}","${new Date(sale.createdAt).toLocaleDateString('pt-BR')}"\n`;
  });

  csv += '\n\nHISTÓRICO DE CONTATOS\n';
  csv += 'ID,Lead ID,Tipo,Descrição,Data\n';
  backup.contactHistory.forEach((contact) => {
    csv += `${contact.id},${contact.leadId},"${contact.type}","${(contact.description || '').replace(/"/g, '""')}","${new Date(contact.createdAt).toLocaleDateString('pt-BR')}"\n`;
  });

  csv += '\n\nRESUMO\n';
  csv += `Total de Leads: ${backup.metadata.totalLeads}\n`;
  csv += `Total de Vendas: ${backup.metadata.totalSales}\n`;
  csv += `Total de Contatos: ${backup.metadata.totalContacts}\n`;

  return csv;
}

/**
 * Calculate backup statistics
 */
export function calculateBackupStats(backup: BackupData) {
  const totalRevenue = backup.sales.reduce((sum, sale) => sum + sale.amount, 0) / 100;
  const averageSaleValue = backup.sales.length > 0 ? totalRevenue / backup.sales.length : 0;
  const conversionRate = backup.leads.length > 0 ? (backup.sales.length / backup.leads.length) * 100 : 0;

  const leadsByStatus = {
    leads: backup.leads.filter((l) => l.status === 'leads').length,
    atendimento: backup.leads.filter((l) => l.status === 'atendimento').length,
    aguardando: backup.leads.filter((l) => l.status === 'aguardando').length,
    confirmado: backup.leads.filter((l) => l.status === 'confirmado').length,
    em_rota: backup.leads.filter((l) => l.status === 'em_rota').length,
    concluido: backup.leads.filter((l) => l.status === 'concluido').length,
  };

  return {
    totalRevenue: totalRevenue.toFixed(2),
    averageSaleValue: averageSaleValue.toFixed(2),
    conversionRate: conversionRate.toFixed(1),
    leadsByStatus,
  };
}


/**
 * Export inventory data as CSV
 */
export async function exportInventoryAsCSV(): Promise<string> {
  const { getDb } = await import('./db');
  const { inventory: inventoryTable } = await import('../drizzle/schema');
  
  const db = await getDb();
  if (!db) throw new Error('Database connection failed');
  const inventory = await db.select().from(inventoryTable);

  let csv = 'BACKUP DE ESTOQUE\n';
  csv += `Data de Exportação: ${new Date().toLocaleDateString('pt-BR')}\n\n`;

  csv += 'PRODUTOS\n';
  csv += 'ID,Nome,Preço,Descrição,Imagem,P,M,G,GG,Total,Data de Criação\n';

  inventory.forEach((item: any) => {
    const total = (item.sizeP || 0) + (item.sizeM || 0) + (item.sizeG || 0) + (item.sizeGG || 0);
    const price = (item.price / 100).toLocaleString('pt-BR', { minimumFractionDigits: 2 });
    csv += `${item.id},"${item.name}","${price}","${(item.description || '').replace(/"/g, '""')}","${item.imageUrl || ''}",${item.sizeP || 0},${item.sizeM || 0},${item.sizeG || 0},${item.sizeGG || 0},${total},"${new Date(item.createdAt).toLocaleDateString('pt-BR')}"\n`;
  });

  csv += `\n\nRESUMO\n`;
  csv += `Total de Produtos: ${inventory.length}\n`;
  const totalItems = inventory.reduce((sum: number, item: any) => sum + (item.sizeP || 0) + (item.sizeM || 0) + (item.sizeG || 0) + (item.sizeGG || 0), 0);
  csv += `Total de Itens em Estoque: ${totalItems}\n`;

  return csv;
}

/**
 * Export inventory data as JSON
 */
export async function exportInventoryAsJSON(): Promise<string> {
  const { getDb } = await import('./db');
  const { inventory: inventoryTable } = await import('../drizzle/schema');
  
  const db = await getDb();
  if (!db) throw new Error('Database connection failed');
  const inventory = await db.select().from(inventoryTable);

  const data = {
    timestamp: new Date().toISOString(),
    inventory,
    metadata: {
      totalProducts: inventory.length,
      totalItems: inventory.reduce((sum: number, item: any) => sum + (item.sizeP || 0) + (item.sizeM || 0) + (item.sizeG || 0) + (item.sizeGG || 0), 0),
      exportDate: new Date().toLocaleDateString('pt-BR'),
    },
  };

  return JSON.stringify(data, null, 2);
}

/**
 * Get backup filename with current date
 */
export function getBackupFilename(type: 'inventory' | 'sales' | 'complete', format: 'csv' | 'json' = 'csv'): string {
  const date = new Date();
  const dateStr = date.toISOString().split('T')[0];
  return `backup_${type}_${dateStr}.${format}`;
}
