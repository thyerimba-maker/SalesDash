import bcrypt from 'bcrypt';
import { getDb } from './db';
import { appUsers } from '../drizzle/schema';
import { eq } from 'drizzle-orm';

const SALT_ROUNDS = 10;

/**
 * Hash a password using bcrypt
 */
export async function hashPassword(password: string): Promise<string> {
  return bcrypt.hash(password, SALT_ROUNDS);
}

/**
 * Verify a password against a hash
 */
export async function verifyPassword(password: string, hash: string): Promise<boolean> {
  return bcrypt.compare(password, hash);
}

/**
 * Create a new app user
 */
export async function createAppUser(username: string, password: string) {
  const db = await getDb();
  if (!db) throw new Error('Database not available');
  
  const passwordHash = await hashPassword(password);
  
  return db
    .insert(appUsers)
    .values({
      username,
      passwordHash,
      status: 'active',
    });
}

/**
 * Find user by username
 */
export async function findUserByUsername(username: string) {
  const db = await getDb();
  if (!db) throw new Error('Database not available');
  
  return db
    .select()
    .from(appUsers)
    .where(eq(appUsers.username, username))
    .limit(1);
}

/**
 * Authenticate user with username and password
 */
export async function authenticateUser(username: string, password: string) {
  const db = await getDb();
  if (!db) throw new Error('Database not available');
  
  const users = await db
    .select()
    .from(appUsers)
    .where(eq(appUsers.username, username))
    .limit(1);
  
  if (!users || users.length === 0) {
    return null;
  }

  const user = users[0];
  
  if (user.status !== 'active') {
    return null;
  }

  const isPasswordValid = await verifyPassword(password, user.passwordHash);
  
  if (!isPasswordValid) {
    return null;
  }

  return user;
}

/**
 * Get all app users
 */
export async function getAllAppUsers() {
  const db = await getDb();
  if (!db) throw new Error('Database not available');
  
  return db
    .select()
    .from(appUsers);
}

/**
 * Update user status
 */
export async function updateUserStatus(userId: number, status: 'active' | 'inactive') {
  const db = await getDb();
  if (!db) throw new Error('Database not available');
  
  return db
    .update(appUsers)
    .set({ status })
    .where(eq(appUsers.id, userId));
}

/**
 * Delete user
 */
export async function deleteAppUser(userId: number) {
  const db = await getDb();
  if (!db) throw new Error('Database not available');
  
  return db
    .delete(appUsers)
    .where(eq(appUsers.id, userId));
}

/**
 * Change user password
 */
export async function changeUserPassword(userId: number, newPassword: string) {
  const db = await getDb();
  if (!db) throw new Error('Database not available');
  
  const passwordHash = await hashPassword(newPassword);
  
  return db
    .update(appUsers)
    .set({ passwordHash })
    .where(eq(appUsers.id, userId));
}
