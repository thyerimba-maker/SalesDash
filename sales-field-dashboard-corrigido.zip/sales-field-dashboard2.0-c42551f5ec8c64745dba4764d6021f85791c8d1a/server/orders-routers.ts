import { z } from "zod";
import { protectedProcedure, router } from "./_core/trpc";
import * as ordersDb from "./orders-db";

export const ordersRouter = router({
  /**
   * CREATE - Create new order
   */
  create: protectedProcedure
    .input(
      z.object({
        leadId: z.number().optional(),
        customerName: z.string().min(1),
        customerPhone: z.string().min(1),
        customerEmail: z.string().email().optional(),
        orderNumber: z.string().min(1).optional(),
        description: z.string().min(1),
        totalAmount: z.number().min(0),
        customizationName: z.string().optional(),
        customizationNumber: z.string().optional(),
        customizationDetails: z.string().optional(),
        notes: z.string().optional(),
      })
    )
    .mutation(async ({ ctx, input }) => {
      return ordersDb.createOrder(ctx.user.id, input as any);
    }),

  /**
   * READ - Get all active orders
   */
  listActive: protectedProcedure.query(async ({ ctx }) => {
    return ordersDb.getUserActiveOrders(ctx.user.id);
  }),

  /**
   * READ - Get all orders
   */
  listAll: protectedProcedure.query(async ({ ctx }) => {
    return ordersDb.getUserAllOrders(ctx.user.id);
  }),

  /**
   * READ - Get completed orders
   */
  listCompleted: protectedProcedure.query(async ({ ctx }) => {
    return ordersDb.getUserCompletedOrders(ctx.user.id);
  }),

  /**
   * READ - Get single order
   */
  get: protectedProcedure
    .input(z.object({ id: z.number() }))
    .query(async ({ ctx, input }) => {
      return ordersDb.getOrder(input.id, ctx.user.id);
    }),

  /**
   * UPDATE - Update order status
   */
  updateStatus: protectedProcedure
    .input(
      z.object({
        id: z.number(),
        status: z.enum([
          "pendente",
          "confirmado",
          "preparando",
          "pronto",
          "saiu_entrega",
          "entregue",
          "cancelado",
          "devolvido",
        ]),
      })
    )
    .mutation(async ({ ctx, input }) => {
      return ordersDb.updateOrderStatus(input.id, ctx.user.id, input.status);
    }),

  /**
   * UPDATE - Update order notes
   */
  updateNotes: protectedProcedure
    .input(
      z.object({
        id: z.number(),
        notes: z.string().optional(),
        internalNotes: z.string().optional(),
      })
    )
    .mutation(async ({ ctx, input }) => {
      return ordersDb.updateOrderNotes(
        input.id,
        ctx.user.id,
        input.notes,
        input.internalNotes
      );
    }),

  /**
   * UPDATE - Update customization
   */
  updateCustomization: protectedProcedure
    .input(
      z.object({
        id: z.number(),
        customizationName: z.string().optional(),
        customizationNumber: z.string().optional(),
        customizationDetails: z.string().optional(),
      })
    )
    .mutation(async ({ ctx, input }) => {
      return ordersDb.updateOrderCustomization(
        input.id,
        ctx.user.id,
        input.customizationName,
        input.customizationNumber,
        input.customizationDetails
      );
    }),

  /**
   * UPDATE - Full order edit
   */
  update: protectedProcedure
    .input(
      z.object({
        id: z.number(),
        customerName: z.string().optional(),
        customerPhone: z.string().optional(),
        customerEmail: z.string().email().optional(),
        description: z.string().optional(),
        totalAmount: z.number().optional(),
        notes: z.string().optional(),
        internalNotes: z.string().optional(),
      })
    )
    .mutation(async ({ ctx, input }) => {
      const { id, ...data } = input;
      const updateData: any = {};
      Object.entries(data).forEach(([key, value]) => {
        if (value !== undefined) {
          updateData[key] = value;
        }
      });
      return ordersDb.updateOrder(id, ctx.user.id, updateData);
    }),

  /**
   * DELETE - Cancel order
   */
  cancel: protectedProcedure
    .input(z.object({ id: z.number() }))
    .mutation(async ({ ctx, input }) => {
      return ordersDb.cancelOrder(input.id, ctx.user.id);
    }),

  /**
   * READ - Get order history
   */
  getHistory: protectedProcedure
    .input(z.object({ orderId: z.number() }))
    .query(async ({ input }) => {
      return ordersDb.getOrderHistory(input.orderId);
    }),

  /**
   * READ - Get order statistics
   */
  getStats: protectedProcedure.query(async ({ ctx }) => {
    return ordersDb.getOrderStats(ctx.user.id);
  }),
});
