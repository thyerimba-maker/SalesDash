import { publicProcedure, protectedProcedure, router } from "../_core/trpc";
import { z } from "zod";
import { authenticateUser, createAppUser, getAllAppUsers, updateUserStatus, deleteAppUser, changeUserPassword } from "../auth-helpers";
import { TRPCError } from "@trpc/server";

export const authRouter = router({
  // Login with username and password
  login: publicProcedure
    .input(z.object({ username: z.string(), password: z.string() }))
    .mutation(async ({ input }) => {
      const user = await authenticateUser(input.username, input.password);
      
      if (!user) {
        throw new TRPCError({
          code: "UNAUTHORIZED",
          message: "Usuário ou senha inválidos",
        });
      }

      // Return user data (excluding password hash)
      return {
        id: user.id,
        username: user.username,
        status: user.status,
      };
    }),

  // Create a new user (admin only)
  createUser: protectedProcedure
    .input(z.object({ username: z.string(), password: z.string() }))
    .mutation(async ({ input, ctx }) => {
      // Check if user is admin (assuming first user or specific role)
      // For now, allow any authenticated user to create users
      
      try {
        await createAppUser(input.username, input.password);
        return { success: true, message: "Usuário criado com sucesso" };
      } catch (error: any) {
        if (error.message?.includes("Duplicate")) {
          throw new TRPCError({
            code: "BAD_REQUEST",
            message: "Usuário já existe",
          });
        }
        throw new TRPCError({
          code: "INTERNAL_SERVER_ERROR",
          message: "Erro ao criar usuário",
        });
      }
    }),

  // Get all users (admin only)
  getAllUsers: protectedProcedure.query(async () => {
    const users = await getAllAppUsers();
    // Return users without password hashes
    return users.map(u => ({
      id: u.id,
      username: u.username,
      status: u.status,
      createdAt: u.createdAt,
    }));
  }),

  // Update user status (admin only)
  updateUserStatus: protectedProcedure
    .input(z.object({ userId: z.number(), status: z.enum(["active", "inactive"]) }))
    .mutation(async ({ input }) => {
      await updateUserStatus(input.userId, input.status);
      return { success: true, message: "Status atualizado" };
    }),

  // Delete user (admin only)
  deleteUser: protectedProcedure
    .input(z.object({ userId: z.number() }))
    .mutation(async ({ input }) => {
      await deleteAppUser(input.userId);
      return { success: true, message: "Usuário deletado" };
    }),

  // Change password
  changePassword: protectedProcedure
    .input(z.object({ userId: z.number(), newPassword: z.string() }))
    .mutation(async ({ input }) => {
      await changeUserPassword(input.userId, input.newPassword);
      return { success: true, message: "Senha alterada com sucesso" };
    }),
});
