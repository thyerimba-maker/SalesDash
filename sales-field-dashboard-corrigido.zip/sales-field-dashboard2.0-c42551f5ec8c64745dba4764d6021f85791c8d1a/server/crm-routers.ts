import { z } from "zod";
import { protectedProcedure, router } from "./_core/trpc";
import {
  createTask,
  getTasksByUser,
  updateTaskStatus,
  logAction,
  getAuditLogs,
  calculateLeadScore,
  getLeadScore,
  getTopLeadsByScore,
  createWebhook,
  getWebhooks,
} from "./crm-features";

export const crmRouter = router({
  /**
   * TASKS
   */
  tasks: router({
    create: protectedProcedure
      .input(
        z.object({
          leadId: z.number().optional(),
          title: z.string().min(1),
          description: z.string().optional(),
          priority: z.enum(["low", "normal", "high", "urgent"]),
          dueDate: z.date(),
          assignedTo: z.number().optional(),
        })
      )
      .mutation(async ({ ctx, input }) => {
        const assignedTo = input.assignedTo || ctx.user.id;
        const result = await createTask({
          ...input,
          assignedTo,
          assignedBy: ctx.user.id,
        });

        await logAction({
          userId: ctx.user.id,
          action: "task_created",
          entityType: "task",
          details: input.title,
        });

        return result;
      }),

    list: protectedProcedure.query(async ({ ctx }) => {
      return getTasksByUser(ctx.user.id);
    }),

    updateStatus: protectedProcedure
      .input(
        z.object({
          taskId: z.number(),
          status: z.enum(["pending", "in_progress", "completed", "cancelled"]),
        })
      )
      .mutation(async ({ ctx, input }) => {
        const result = await updateTaskStatus(input.taskId, input.status);

        await logAction({
          userId: ctx.user.id,
          action: "task_updated",
          entityType: "task",
          entityId: input.taskId,
          details: `Status changed to ${input.status}`,
        });

        return result;
      }),
  }),

  /**
   * AUDIT LOGS
   */
  auditLogs: router({
    list: protectedProcedure
      .input(
        z.object({
          limit: z.number().default(100),
        })
      )
      .query(async ({ ctx, input }) => {
        return getAuditLogs(ctx.user.id, input.limit);
      }),
  }),

  /**
   * LEAD SCORING
   */
  leadScoring: router({
    calculateScore: protectedProcedure
      .input(z.object({ leadId: z.number() }))
      .mutation(async ({ input }) => {
        return calculateLeadScore(input.leadId);
      }),

    getScore: protectedProcedure
      .input(z.object({ leadId: z.number() }))
      .query(async ({ input }) => {
        return getLeadScore(input.leadId);
      }),

    getTopLeads: protectedProcedure
      .input(
        z.object({
          limit: z.number().default(10),
        })
      )
      .query(async ({ ctx, input }) => {
        return getTopLeadsByScore(ctx.user.id, input.limit);
      }),
  }),

  /**
   * WEBHOOKS
   */
  webhooks: router({
    create: protectedProcedure
      .input(
        z.object({
          name: z.string().min(1),
          url: z.string().url(),
          events: z.string(),
          secret: z.string().min(10),
        })
      )
      .mutation(async ({ ctx, input }) => {
        const result = await createWebhook({
          userId: ctx.user.id,
          ...input,
        });

        await logAction({
          userId: ctx.user.id,
          action: "webhook_created",
          entityType: "webhook",
          details: input.name,
        });

        return result;
      }),

    list: protectedProcedure.query(async ({ ctx }) => {
      return getWebhooks(ctx.user.id);
    }),
  }),
});
